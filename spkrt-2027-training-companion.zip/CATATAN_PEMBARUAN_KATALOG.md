# Catatan pembaruan katalog SPKRT 2027

- Memperbarui 7 ID kuesioner sesuai tautan yang diberikan.
- Menggabungkan entri HR dan HR + Cover menjadi satu entri VPKRT27-HR; memakai file HR + Cover sebagai versi yang dipertahankan.
- Memperbarui 6 ID bahan ajar PDF (Buku 1-4, FASIH, Metodologi).
- Menambahkan bahan ajar PDF Sistem Pengolahan Data SPKRT 2027.
- Tidak mengubah mekanisme unduh PDF, Apps Script, maupun katalog Google Sheets.

PENTING: Setelah ZIP ini dipakai, perbarui juga sheet MATERI di Google Sheets agar tidak menimpa katalog lokal dengan ID lama saat sinkronisasi. Pastikan baris HR duplikat dinonaktifkan/dihapus dan seluruh ID di sheet mengikuti katalog baru.
