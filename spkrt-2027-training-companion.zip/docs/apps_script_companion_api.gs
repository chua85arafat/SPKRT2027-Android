/**
 * ============================================================================
 * SPKRT 2027 Training Companion — Compatible Google Apps Script API Extension
 * ============================================================================
 * Target Existing Database: DATABASE_PORTAL_SPKRT_2027
 * Spreadsheet ID: 1cWqtlhG0cBHGPa2qA9Ku9fWTvhxCU1uctzC-YEUXftU
 * Script Property: DATABASE_ID
 *
 * PRINSIP KOMPATIBILITAS:
 * - TIDAK menghapus atau mengubah struktur sheet yang sudah ada.
 * - TIDAK menghapus akun admin/peserta atau data registrasi.
 * - Membaca kolom sheet MATERI yang sudah ada:
 *   ID_MATERI | KATEGORI | JUDUL | DESKRIPSI | DRIVE_FILE_ID | URL_MATERI | URUTAN | STATUS
 * - Tambahkan fungsi ini sebagai file baru di proyek Apps Script portal Anda
 *   (atau gabungkan secara hati-hati ke doGet / doPost yang sudah ada).
 */

function getPortalSpreadsheet_() {
  var props = PropertiesService.getScriptProperties();
  var dbId = props.getProperty('DATABASE_ID') || '1cWqtlhG0cBHGPa2qA9Ku9fWTvhxCU1uctzC-YEUXftU';
  return SpreadsheetApp.openById(dbId);
}

function jsonResponse_(payload) {
  return ContentService
    .createTextOutput(JSON.stringify(payload))
    .setMimeType(ContentService.MimeType.JSON);
}

/**
 * Router GET untuk aplikasi Android (ambil katalog & cek akses file).
 * Jika portal web Anda sudah memiliki doGet(e), panggil fungsi ini hanya saat e.parameter.action tersedia.
 */
function doGet(e) {
  var params = (e && e.parameter) ? e.parameter : {};
  var action = (params.action || '').trim();

  if (action === 'getMaterials') {
    return handleAndroidGetMaterials_(params.token || '');
  }
  if (action === 'getFileAccess' || action === 'getPptxPdf') {
    return handleAndroidGetFileAccess_(params.token || '', params.fileId || '', action === 'getPptxPdf');
  }
  if (action === 'getVideoStream') {
    return handleAndroidGetVideoStream_(params.token || '', params.fileId || '');
  }

  return jsonResponse_({
    success: true,
    service: 'SPKRT 2027 Training Companion API',
    message: 'Gunakan action=login (POST), getMaterials (GET), getFileAccess (GET), atau getVideoStream (GET).'
  });
}

/**
 * Router POST untuk autentikasi login peserta aplikasi Android.
 */
function doPost(e) {
  try {
    var body = JSON.parse((e && e.postData && e.postData.contents) ? e.postData.contents : '{}');
    if (body.action === 'login') {
      return handleAndroidLogin_(body.email || '', body.password || '');
    }
    return jsonResponse_({ success: false, message: 'Aksi POST tidak dikenali.' });
  } catch (err) {
    return jsonResponse_({ success: false, message: 'Payload JSON tidak valid: ' + err.message });
  }
}

/**
 * Verifikasi login terhadap sheet PENGGUNA (atau PESERTA) tanpa mengubah struktur sheet.
 * Sesuaikan nama kolom password/hash jika portal eksisting menggunakan mekanisme hash tertentu.
 */
function handleAndroidLogin_(email, password) {
  var cleanEmail = String(email || '').trim().toLowerCase();
  var cleanPassword = String(password || '');
  if (!cleanEmail || !cleanPassword) {
    return jsonResponse_({ success: false, message: 'Email dan kata sandi wajib diisi.' });
  }

  var ss = getPortalSpreadsheet_();
  var sheet = ss.getSheetByName('PENGGUNA') || ss.getSheetByName('PESERTA');
  if (!sheet) {
    return jsonResponse_({ success: false, message: 'Sheet PENGGUNA/PESERTA tidak ditemukan.' });
  }

  var values = sheet.getDataRange().getValues();
  if (values.length < 2) {
    return jsonResponse_({ success: false, message: 'Data pengguna belum tersedia.' });
  }

  var headers = values[0].map(function (h) { return String(h).trim().toUpperCase(); });
  var idxEmail = headers.indexOf('EMAIL');
  var idxPass = headers.indexOf('PASSWORD_HASH') >= 0 ? headers.indexOf('PASSWORD_HASH') : headers.indexOf('PASSWORD');
  var idxNama = headers.indexOf('NAMA') >= 0 ? headers.indexOf('NAMA') : headers.indexOf('NAMA_LENGKAP');
  var idxRole = headers.indexOf('ROLE') >= 0 ? headers.indexOf('ROLE') : headers.indexOf('PERAN');
  var idxKelas = headers.indexOf('KELAS');
  var idxStatus = headers.indexOf('STATUS');

  if (idxEmail < 0 || idxPass < 0) {
    return jsonResponse_({
      success: false,
      message: 'Kolom EMAIL atau PASSWORD belum sesuai pada sheet PENGGUNA. Sesuaikan pemetaan kolom pada Apps Script.'
    });
  }

  // Sesuaikan fungsi verifikasi hash apabila portal web Anda menggunakan SHA-256 / salt
  var sha256Hex = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, cleanPassword)
    .map(function (b) { return ('0' + ((b + 256) % 256).toString(16)).slice(-2); })
    .join('');

  for (var i = 1; i < values.length; i++) {
    var row = values[i];
    var rowEmail = String(row[idxEmail] || '').trim().toLowerCase();
    if (rowEmail !== cleanEmail) continue;

    if (idxStatus >= 0) {
      var st = String(row[idxStatus] || '').trim().toUpperCase();
      if (st && st !== 'AKTIF' && st !== 'ACTIVE') {
        return jsonResponse_({ success: false, message: 'Akun Anda belum aktif. Hubungi panitia.' });
      }
    }

    var storedPass = String(row[idxPass] || '').trim();
    var matched = (storedPass === cleanPassword) || (storedPass.toLowerCase() === sha256Hex);
    if (!matched) {
      return jsonResponse_({ success: false, message: 'Kata sandi yang Anda masukkan salah.' });
    }

    var token = Utilities.getUuid() + '-' + Date.now();
    var userObj = {
      email: rowEmail,
      nama: idxNama >= 0 ? String(row[idxNama] || '') : rowEmail,
      peran: idxRole >= 0 ? String(row[idxRole] || 'Peserta Pelatihan') : 'Peserta Pelatihan',
      kelas: idxKelas >= 0 ? String(row[idxKelas] || 'BPS Kabupaten Pinrang') : 'BPS Kabupaten Pinrang'
    };

    // Simpan sesi token sementara di CacheService (6 jam, aman, tidak mengubah sheet)
    CacheService.getScriptCache().put('android_token_' + token, JSON.stringify(userObj), 21600);

    return jsonResponse_({
      success: true,
      token: token,
      user: userObj
    });
  }

  return jsonResponse_({ success: false, message: 'Email tidak terdaftar pada portal SPKRT 2027.' });
}

function validateSessionToken_(token) {
  if (!token) return null;
  var cached = CacheService.getScriptCache().get('android_token_' + token);
  if (!cached) return null;
  try {
    return JSON.parse(cached);
  } catch (e) {
    return null;
  }
}

/**
 * Mengambil katalog materi langsung dari sheet MATERI eksisting.
 */
function handleAndroidGetMaterials_(token) {
  var session = validateSessionToken_(token);
  if (!session) {
    return jsonResponse_({ success: false, message: 'Sesi login tidak valid atau telah kedaluwarsa. Silakan login ulang.' });
  }

  // Jika fungsi getMaterials(token) portal eksisting tersedia dan mengembalikan array, Anda bisa memanggilnya di sini.
  var ss = getPortalSpreadsheet_();
  var sheet = ss.getSheetByName('MATERI');
  if (!sheet) {
    return jsonResponse_({ success: false, message: 'Sheet MATERI tidak ditemukan.' });
  }

  var values = sheet.getDataRange().getValues();
  if (values.length < 2) {
    return jsonResponse_({ success: true, data: [] });
  }

  var headers = values[0].map(function (h) { return String(h).trim().toUpperCase(); });
  var data = [];

  for (var i = 1; i < values.length; i++) {
    var row = values[i];
    var item = {};
    for (var c = 0; c < headers.length; c++) {
      item[headers[c]] = row[c];
    }
    var status = String(item.STATUS || 'AKTIF').trim().toUpperCase();
    if (item.DRIVE_FILE_ID && status === 'AKTIF') {
      data.push({
        ID_MATERI: String(item.ID_MATERI || item.DRIVE_FILE_ID),
        KATEGORI: String(item.KATEGORI || ''),
        JUDUL: String(item.JUDUL || ''),
        DESKRIPSI: String(item.DESKRIPSI || ''),
        DRIVE_FILE_ID: String(item.DRIVE_FILE_ID || '').trim(),
        URL_MATERI: String(item.URL_MATERI || ''),
        URUTAN: Number(item.URUTAN || i),
        STATUS: status
      });
    }
  }

  return jsonResponse_({ success: true, data: data });
}

/**
 * Memberikan akses file Google Drive secara terotorisasi untuk peserta yang valid.
 * Untuk file <= 12MB yang bersifat privat di Drive, Apps Script dapat mengembalikan base64Pdf
 * (termasuk konversi Google Docs / PPTX -> PDF bila Drive Advanced Service atau getAs('application/pdf') mendukung).
 */
function handleAndroidGetFileAccess_(token, fileId, convertToPdf) {
  var session = validateSessionToken_(token);
  if (!session) {
    return jsonResponse_({ success: false, message: 'Autentikasi diperlukan untuk mengakses dokumen.' });
  }
  if (!fileId || !/^[A-Za-z0-9_-]{8,100}$/.test(fileId)) {
    return jsonResponse_({ success: false, message: 'ID file Google Drive tidak valid.' });
  }

  try {
    var file = DriveApp.getFileById(fileId);
    var mime = file.getMimeType();
    var sizeBytes = file.getSize();

    // Jika file kecil (<= 10MB) dan merupakan PDF atau Google Docs, kirim blob PDF terotorisasi
    if (sizeBytes <= 10 * 1024 * 1024 && (mime === 'application/pdf' || mime === 'application/vnd.google-apps.document' || convertToPdf)) {
      var pdfBlob = (mime === 'application/pdf') ? file.getBlob() : file.getAs('application/pdf');
      return jsonResponse_({
        success: true,
        mimeType: 'application/pdf',
        base64Pdf: Utilities.base64Encode(pdfBlob.getBytes())
      });
    }

    return jsonResponse_({
      success: true,
      mimeType: mime,
      downloadUrl: 'https://drive.usercontent.google.com/download?id=' + fileId + '&export=download&confirm=t'
    });
  } catch (err) {
    return jsonResponse_({
      success: false,
      message: 'File tidak dapat diakses oleh server portal: ' + err.message
    });
  }
}

function handleAndroidGetVideoStream_(token, fileId) {
  var session = validateSessionToken_(token);
  if (!session) {
    return jsonResponse_({ success: false, message: 'Autentikasi diperlukan untuk memutar video.' });
  }
  if (!fileId || !/^[A-Za-z0-9_-]{8,100}$/.test(fileId)) {
    return jsonResponse_({ success: false, message: 'ID video tidak valid.' });
  }
  return jsonResponse_({
    success: true,
    streamUrl: 'https://drive.usercontent.google.com/download?id=' + fileId + '&export=download&confirm=t'
  });
}
