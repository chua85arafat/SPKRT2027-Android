# Panduan Integrasi, Konfigurasi Google Drive, Build APK & Pengujian
## SPKRT 2027 Training Companion — BPS Kabupaten Pinrang

### 1. Integrasi Backend Google Apps Script (Tanpa Merusak Database Portal)
- Database eksisting: `DATABASE_PORTAL_SPKRT_2027`
- Spreadsheet ID: `1cWqtlhG0cBHGPa2qA9Ku9fWTvhxCU1uctzC-YEUXftU`
- Script Properties: `DATABASE_ID`
- Skrip pendamping kompatibel tersedia di `docs/apps_script_companion_api.gs`.

**Langkah Deploy:**
1. Buka proyek Apps Script portal SPKRT 2027 Anda.
2. Tambahkan file baru (misalnya `AndroidCompanionApi.gs`) menggunakan referensi `docs/apps_script_companion_api.gs`.
3. Jika proyek sudah memiliki `doGet`/`doPost`, arahkan permintaan yang memiliki parameter `action=login`, `action=getMaterials`, `action=getFileAccess`, atau `action=getVideoStream` ke handler baru tersebut.
4. Klik **Deploy -> New Deployment -> Web App**, pilih *Execute as: Me*, dan atur akses sesuai kebijakan BPS Kabupaten Pinrang.
5. Salin URL Web App (`https://script.google.com/macros/s/.../exec`), lalu masukkan pada menu **Bantuan Login & Konfigurasi Portal** di aplikasi Android (atau tetapkan pada `DEFAULT_APPS_SCRIPT_URL` di `app/build.gradle.kts`).

### 2. Konfigurasi Izin Akses Google Drive
Semua 32 sumber materi tetap menggunakan ID Google Drive resmi (tanpa duplikasi):
- **Akses Publik Terbatas / Link-View** (*Anyone with the link - Viewer*):
  - PDF & Google Docs dapat diunduh on-demand dan dibaca langsung di **Pembaca PDF Native** dengan pencarian teks & penyorotan (*highlight*) penuh.
  - PPTX dapat dilihat pada tab **Visual Slide** maupun diekstrak ke **Teks Slide (Offline)**.
  - Video (<= 100 MB) dapat diputar langsung dengan **Media3 ExoPlayer** jika header `video/*` diizinkan; jika Drive mewajibkan transcoding/kuota, aplikasi otomatis menampilkan alasan yang jujur dan beralih ke pemutar **Pratinjau Google Drive** di dalam aplikasi.
- **Akses Privat / Terbatas Organisasi**:
  - Gunakan Apps Script backend terotorisasi (`handleAndroidGetFileAccess_`) agar peserta terautentikasi tetap bisa membaca file tanpa menjadikan seluruh folder Drive publik.
  - Jika izin file menolak akses, aplikasi tidak pernah menghapus file dari katalog dan melaporkan **File ID** secara spesifik.

### 3. Strategi OCR untuk PDF Hasil Scan
- `PdfDocumentEngine` secara otomatis mendeteksi apabila sebuah PDF tidak memiliki lapisan teks (*embedded text layer*).
- Aplikasi akan menampilkan banner pemberitahuan resmi kepada petugas.
- Pengembangan lanjutan terpisah yang direkomendasikan: proses OCR di sisi server/Google Drive (konversi PDF -> Google Docs OCR -> ekspor PDF searchable) atau integrasi **ML Kit Text Recognition** pada fase 2.

### 4. Panduan Build APK
- Melalui menu AI Studio: gunakan menu ekspor APK/AAB.
- Melalui Gradle lokal:
  ```bash
  gradle :app:assembleDebug
  gradle :app:testDebugUnitTest
  ```

### 5. Daftar Pengujian (Checklist Kriteria Keberhasilan v1)
- [ ] Splash Screen menampilkan logo SPKRT 2027 & memeriksa sesi login.
- [ ] Login terhubung ke Apps Script URL (dan menampilkan pesan error jelas bila gagal).
- [ ] Beranda menampilkan salam pengguna, status peserta, ringkasan 5 kategori (7, 8, 12, 1, 4 = 32 materi), materi terakhir dibuka, dan favorit.
- [ ] Perpustakaan Materi mendukung pencarian judul, filter kategori, filter jenis file (PDF/DOCS/PPTX/VIDEO), dan pengurutan.
- [ ] Pembaca PDF menampilkan halaman, navigasi halaman, input nomor halaman, zoom in/out, fit-to-width, simpan halaman terakhir, bookmark halaman, dan unduh offline manual.
- [ ] Pencarian teks PDF (contoh: `"pemeriksaan"` atau `"rumah tangga"`) menampilkan jumlah hasil, menyorot kata pada halaman, dan berpindah antarhasil `<` / `>`.
- [ ] Viewer PPTX menampilkan slide visual dan ekstraksi teks slide offline tanpa layar kosong.
- [ ] Video Pembelajaran memutar 4 video menggunakan Media3 ExoPlayer (play/pause, seek, volume, layar penuh, progres lokal) dengan fallback pratinjau Drive yang jujur.
- [ ] Profil menampilkan identitas peserta, daftar favorit, bookmark, riwayat, pengelolaan cache/offline, dan tombol Keluar.
- [ ] Tidak ada credential rahasia atau API key privat yang tertanam dalam APK.
