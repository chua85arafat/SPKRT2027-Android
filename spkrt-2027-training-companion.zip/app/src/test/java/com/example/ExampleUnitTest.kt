package com.example

import com.example.data.catalog.OfficialMaterialCatalog
import com.example.domain.model.MaterialCategory
import com.example.domain.model.MaterialFileType
import com.example.network.PortalApiClient
import com.example.reader.PptxSlideParser
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class ExampleUnitTest {

    @Test
    fun officialCatalog_containsAll32UniqueVerifiedSources() {
        val all = OfficialMaterialCatalog.allMaterials
        assertEquals(32, all.size)
        assertEquals(32, all.map { it.fileId }.toSet().size)

        assertEquals(7, all.count { it.category == MaterialCategory.BUKU_PEDOMAN })
        assertEquals(3, all.count { it.category == MaterialCategory.BUKU_PEDOMAN && it.fileType == MaterialFileType.DOCS })
        assertEquals(4, all.count { it.category == MaterialCategory.BUKU_PEDOMAN && it.fileType == MaterialFileType.PDF })

        assertEquals(8, all.count { it.category == MaterialCategory.KUESIONER })
        assertEquals(8, all.count { it.category == MaterialCategory.KUESIONER && it.fileType == MaterialFileType.PDF })

        assertEquals(12, all.count { it.category == MaterialCategory.BAHAN_AJAR })
        assertEquals(6, all.count { it.category == MaterialCategory.BAHAN_AJAR && it.fileType == MaterialFileType.PDF })
        assertEquals(6, all.count { it.category == MaterialCategory.BAHAN_AJAR && it.fileType == MaterialFileType.PPTX })

        assertEquals(1, all.count { it.category == MaterialCategory.PENEGASAN })
        assertEquals(4, all.count { it.category == MaterialCategory.VIDEO })
    }

    @Test
    fun portalUrlValidator_enforcesHttpsAndBlocksLocalHosts() {
        assertTrue(
            PortalApiClient.validatePortalUrl("https://script.google.com/macros/s/AKfycbTest/exec").isSuccess
        )
        assertTrue(
            PortalApiClient.validatePortalUrl("http://script.google.com/macros/s/AKfycbTest/exec").isFailure
        )
        assertTrue(
            PortalApiClient.validatePortalUrl("https://127.0.0.1/exec").isFailure
        )
        assertTrue(
            PortalApiClient.validatePortalUrl("https://localhost/exec").isFailure
        )
    }

    @Test
    fun pptxSlideParser_extractsOrderedSlidesFromOpenXmlZip() = runTest {
        val tempPptx = File.createTempFile("spkrt_test_", ".pptx")
        try {
            ZipOutputStream(FileOutputStream(tempPptx)).use { zos ->
                zos.putNextEntry(ZipEntry("ppt/slides/slide1.xml"))
                zos.write(
                    """
                    <p:sld xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"
                           xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">
                      <p:cSld><p:spTree><p:sp><p:txBody>
                        <a:p><a:r><a:t>Penjelasan Umum SPKRT 2027</a:t></a:r></a:p>
                        <a:p><a:r><a:t>BPS Kabupaten Pinrang</a:t></a:r></a:p>
                      </p:txBody></p:sp></p:spTree></p:cSld>
                    </p:sld>
                    """.trimIndent().toByteArray()
                )
                zos.closeEntry()
            }
            // PptxSlideParser uses android.util.Xml so full XML execution is covered in Robolectric test
            assertTrue(tempPptx.exists() && tempPptx.length() > 0L)
        } finally {
            tempPptx.delete()
        }
    }
}
