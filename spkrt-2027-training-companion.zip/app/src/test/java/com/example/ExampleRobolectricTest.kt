package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.reader.PptxSlideParser
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun appName_matchesSpkrt2027TrainingCompanion() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("SPKRT 2027 Training Companion", appName)
    }

    @Test
    fun pptxSlideParser_parsesOrderedSlidesAndBulletPoints() = runTest {
        val tempPptx = File.createTempFile("spkrt_robo_", ".pptx")
        try {
            ZipOutputStream(FileOutputStream(tempPptx)).use { zos ->
                zos.putNextEntry(ZipEntry("ppt/slides/slide2.xml"))
                zos.write(
                    """
                    <p:sld xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"
                           xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">
                      <p:cSld><p:spTree><p:sp><p:txBody>
                        <a:p><a:r><a:t>Pemeriksaan Dokumen</a:t></a:r></a:p>
                        <a:p><a:r><a:t>Cek konsistensi isian blok konsumsi</a:t></a:r></a:p>
                      </p:txBody></p:sp></p:spTree></p:cSld>
                    </p:sld>
                    """.trimIndent().toByteArray()
                )
                zos.closeEntry()

                zos.putNextEntry(ZipEntry("ppt/slides/slide1.xml"))
                zos.write(
                    """
                    <p:sld xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"
                           xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">
                      <p:cSld><p:spTree><p:sp><p:txBody>
                        <a:p><a:r><a:t>Penjelasan Umum SPKRT 2027</a:t></a:r></a:p>
                        <a:p><a:r><a:t>BPS Kabupaten Pinrang</a:t></a:r></a:p>
                      </p:txBody></p:sp></p:spTree></p:cSld>
                    </p:sld>
                    """.trimIndent().toByteArray()
                )
                zos.closeEntry()
            }

            val slides = PptxSlideParser.parseSlides(tempPptx)
            assertEquals(2, slides.size)
            assertEquals("Penjelasan Umum SPKRT 2027", slides[0].title)
            assertTrue(slides[0].bodyParagraphs.contains("BPS Kabupaten Pinrang"))
            assertEquals("Pemeriksaan Dokumen", slides[1].title)
        } finally {
            tempPptx.delete()
        }
    }
}
