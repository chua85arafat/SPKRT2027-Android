package com.example.video

import com.example.domain.model.MaterialItem
import com.example.network.PortalApiClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request

sealed class VideoStreamResolution {
    data class DirectExoPlayerStream(
        val streamUrl: String,
        val mimeType: String,
        val sourceLabel: String
    ) : VideoStreamResolution()

    data class DrivePreviewFallback(
        val previewUrl: String,
        val reason: String
    ) : VideoStreamResolution()

    data class Error(val message: String) : VideoStreamResolution()
}

/**
 * Resolves a genuine Media3 ExoPlayer stream URL instead of blindly assuming Google Drive /view or
 * /preview URLs are direct media streams.
 *
 * Strategy:
 * 1. If the Apps Script portal backend is configured, request an authorized streamUrl first.
 * 2. Probe the Google Drive direct download endpoint with a small Range request (`bytes=0-1023`)
 *    to verify the Content-Type is actual video/binary media rather than an HTML login/warning page.
 * 3. If Google Drive blocks direct streaming (e.g., restricted sharing or large-file quota), return
 *    an honest `DrivePreviewFallback` so the participant can still play via controlled in-app Drive embed.
 */
class VideoStreamResolver(
    private val okHttpClient: OkHttpClient,
    private val portalApiClient: PortalApiClient
) {

    suspend fun resolveStream(
        material: MaterialItem,
        portalBaseUrl: String,
        sessionToken: String
    ): VideoStreamResolution = withContext(Dispatchers.IO) {
        // 1. Check authorized Apps Script backend if connected
        if (portalBaseUrl.isNotBlank() && sessionToken.isNotBlank()) {
            val portalRes = portalApiClient.requestAuthorizedFileAccess(
                portalBaseUrl = portalBaseUrl,
                token = sessionToken,
                fileId = material.fileId,
                action = "getVideoStream"
            ).getOrNull()

            val authorizedUrl = portalRes?.streamUrl ?: portalRes?.downloadUrl
            if (portalRes?.success == true && !authorizedUrl.isNullOrBlank()) {
                val probe = probeDirectVideoUrl(authorizedUrl)
                if (probe != null) {
                    return@withContext VideoStreamResolution.DirectExoPlayerStream(
                        streamUrl = authorizedUrl,
                        mimeType = probe,
                        sourceLabel = "Streaming terotorisasi Portal SPKRT 2027 (Media3 ExoPlayer)"
                    )
                }
            }
        }

        // 2. Probe Google Drive direct download stream endpoint
        val candidateUrl = material.directDownloadUrl
        try {
            val mimeType = probeDirectVideoUrl(candidateUrl)
            if (mimeType != null) {
                return@withContext VideoStreamResolution.DirectExoPlayerStream(
                    streamUrl = candidateUrl,
                    mimeType = mimeType,
                    sourceLabel = "Streaming langsung Google Drive (Media3 ExoPlayer)"
                )
            }
            return@withContext VideoStreamResolution.DrivePreviewFallback(
                previewUrl = material.previewUrl,
                reason = "Google Drive tidak mengizinkan streaming langsung ExoPlayer untuk file ID ${material.fileId} " +
                    "(izin akses terbatas atau memerlukan transcoding Drive). Menggunakan pemutar pratinjau Google Drive terintegrasi."
            )
        } catch (e: Exception) {
            return@withContext VideoStreamResolution.Error(
                "Gagal memeriksa ketersediaan stream video: ${e.localizedMessage ?: "Periksa koneksi internet Anda."}"
            )
        }
    }

    private fun probeDirectVideoUrl(url: String): String? {
        val request = Request.Builder()
            .url(url)
            .header("Range", "bytes=0-1023")
            .header("User-Agent", "SPKRT2027-Android/1.0")
            .build()

        okHttpClient.newCall(request).execute().use { response ->
            if (!response.isSuccessful && response.code != 206) {
                return null
            }
            val contentType = response.header("Content-Type").orEmpty().lowercase()
            if (contentType.contains("text/html") || contentType.contains("application/json")) {
                return null
            }
            if (contentType.startsWith("video/") || contentType.contains("application/octet-stream")) {
                return contentType.substringBefore(';').ifBlank { "video/mp4" }
            }
            return null
        }
    }
}
