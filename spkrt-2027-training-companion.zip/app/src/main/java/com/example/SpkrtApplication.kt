package com.example

import android.app.Application
import android.content.Context
import com.example.auth.AuthRepository
import com.example.data.repository.MaterialRepository
import com.example.network.DriveFileFetcher
import com.example.network.PortalApiClient
import com.example.storage.LocalPreferencesStore
import com.example.storage.OfflineFileManager
import com.example.video.VideoStreamResolver
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader

class AppContainer(context: Context) {
    val preferencesStore = LocalPreferencesStore(context)
    val offlineFileManager = OfflineFileManager(context)
    val portalApiClient = PortalApiClient()
    val driveFileFetcher = DriveFileFetcher(
        okHttpClient = portalApiClient.okHttpClient,
        portalApiClient = portalApiClient,
        offlineFileManager = offlineFileManager
    )
    val authRepository = AuthRepository(
        preferencesStore = preferencesStore,
        portalApiClient = portalApiClient
    )
    val materialRepository = MaterialRepository(
        preferencesStore = preferencesStore,
        portalApiClient = portalApiClient,
        offlineFileManager = offlineFileManager
    )
    val videoStreamResolver = VideoStreamResolver(
        okHttpClient = portalApiClient.okHttpClient,
        portalApiClient = portalApiClient
    )
}

class SpkrtApplication : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        PDFBoxResourceLoader.init(applicationContext)
        container = AppContainer(applicationContext)
    }
}
