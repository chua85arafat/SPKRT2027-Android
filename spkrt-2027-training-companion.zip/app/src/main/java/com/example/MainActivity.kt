package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.example.navigation.SpkrtAppNavHost
import com.example.ui.theme.SpkrtTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val appContainer = (application as SpkrtApplication).container
        setContent {
            SpkrtTheme {
                SpkrtAppNavHost(appContainer = appContainer)
            }
        }
    }
}
