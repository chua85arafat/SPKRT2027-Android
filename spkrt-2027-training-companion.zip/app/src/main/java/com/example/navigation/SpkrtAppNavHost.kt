package com.example.navigation

import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LibraryBooks
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.LibraryBooks
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.PlayCircle
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import com.example.AppContainer
import com.example.R
import com.example.domain.model.MaterialCategory
import com.example.domain.model.MaterialFileType
import com.example.domain.model.MaterialItem
import com.example.ui.home.HomeScreen
import com.example.ui.home.HomeViewModel
import com.example.ui.login.LoginScreen
import com.example.ui.login.LoginViewModel
import com.example.ui.materials.MaterialsScreen
import com.example.ui.materials.MaterialsViewModel
import com.example.ui.profile.ProfileScreen
import com.example.ui.profile.ProfileViewModel
import com.example.ui.reader.PdfReaderScreen
import com.example.ui.reader.PdfReaderViewModel
import com.example.ui.reader.PptxViewerScreen
import com.example.ui.reader.PptxViewerViewModel
import com.example.ui.splash.SplashScreen
import com.example.ui.theme.BpsBlueContainer
import com.example.ui.theme.BpsBluePrimary
import com.example.ui.video.VideoScreen
import com.example.ui.video.VideoViewModel

private data class MainTabSpec(
    val route: Any,
    val labelRes: Int,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
)

@Composable
fun SpkrtAppNavHost(
    appContainer: AppContainer,
    navController: NavHostController = rememberNavController()
) {
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination

    var pendingCategoryFilter by remember { mutableStateOf<MaterialCategory?>(null) }
    var pendingVideoId by remember { mutableStateOf<String?>(null) }
    var isVideoFullscreen by remember { mutableStateOf(false) }

    val mainTabs = remember {
        listOf(
            MainTabSpec(
                route = HomeTabRoute,
                labelRes = R.string.nav_home,
                selectedIcon = Icons.Filled.Home,
                unselectedIcon = Icons.Outlined.Home,
                testTag = "nav_tab_home"
            ),
            MainTabSpec(
                route = MaterialsTabRoute,
                labelRes = R.string.nav_materials,
                selectedIcon = Icons.Filled.LibraryBooks,
                unselectedIcon = Icons.Outlined.LibraryBooks,
                testTag = "nav_tab_materials"
            ),
            MainTabSpec(
                route = VideoTabRoute,
                labelRes = R.string.nav_video,
                selectedIcon = Icons.Filled.PlayCircle,
                unselectedIcon = Icons.Outlined.PlayCircle,
                testTag = "nav_tab_video"
            ),
            MainTabSpec(
                route = ProfileTabRoute,
                labelRes = R.string.nav_profile,
                selectedIcon = Icons.Filled.Person,
                unselectedIcon = Icons.Outlined.Person,
                testTag = "nav_tab_profile"
            )
        )
    }

    val isOnMainTab = currentDestination != null && (
        currentDestination.hasRoute<HomeTabRoute>() ||
            currentDestination.hasRoute<MaterialsTabRoute>() ||
            currentDestination.hasRoute<VideoTabRoute>() ||
            currentDestination.hasRoute<ProfileTabRoute>()
        )

    fun navigateToTab(route: Any) {
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    fun openMaterial(material: MaterialItem) {
        when (material.fileType) {
            MaterialFileType.PDF, MaterialFileType.DOCS -> {
                navController.navigate(PdfReaderRoute(materialId = material.id, initialPage = -1))
            }
            MaterialFileType.PPTX -> {
                navController.navigate(PptxViewerRoute(materialId = material.id))
            }
            MaterialFileType.VIDEO -> {
                pendingVideoId = material.id
                navigateToTab(VideoTabRoute)
            }
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useNavigationRail = maxWidth >= 600.dp

        val showChrome = isOnMainTab && !isVideoFullscreen

        Row(modifier = Modifier.fillMaxSize()) {
            if (showChrome && useNavigationRail) {
                NavigationRail(
                    containerColor = MaterialTheme.colorScheme.surface
                ) {
                    mainTabs.forEach { tab ->
                        val selected = when (tab.route) {
                            is HomeTabRoute -> currentDestination?.hasRoute<HomeTabRoute>() == true
                            is MaterialsTabRoute -> currentDestination?.hasRoute<MaterialsTabRoute>() == true
                            is VideoTabRoute -> currentDestination?.hasRoute<VideoTabRoute>() == true
                            is ProfileTabRoute -> currentDestination?.hasRoute<ProfileTabRoute>() == true
                            else -> false
                        }
                        NavigationRailItem(
                            selected = selected,
                            onClick = { navigateToTab(tab.route) },
                            icon = {
                                Icon(
                                    imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                    contentDescription = stringResource(tab.labelRes)
                                )
                            },
                            label = { Text(stringResource(tab.labelRes)) },
                            colors = NavigationRailItemDefaults.colors(
                                selectedIconColor = BpsBluePrimary,
                                selectedTextColor = BpsBluePrimary,
                                indicatorColor = BpsBlueContainer
                            ),
                            modifier = Modifier.testTag(tab.testTag)
                        )
                    }
                }
            }

            Scaffold(
                bottomBar = {
                    if (showChrome && !useNavigationRail) {
                        NavigationBar(
                            containerColor = MaterialTheme.colorScheme.surface,
                            tonalElevation = 4.dp,
                            modifier = Modifier.navigationBarsPadding()
                        ) {
                            mainTabs.forEach { tab ->
                                val selected = when (tab.route) {
                                    is HomeTabRoute -> currentDestination?.hasRoute<HomeTabRoute>() == true
                                    is MaterialsTabRoute -> currentDestination?.hasRoute<MaterialsTabRoute>() == true
                                    is VideoTabRoute -> currentDestination?.hasRoute<VideoTabRoute>() == true
                                    is ProfileTabRoute -> currentDestination?.hasRoute<ProfileTabRoute>() == true
                                    else -> false
                                }
                                NavigationBarItem(
                                    selected = selected,
                                    onClick = { navigateToTab(tab.route) },
                                    icon = {
                                        Icon(
                                            imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                            contentDescription = stringResource(tab.labelRes)
                                        )
                                    },
                                    label = { Text(stringResource(tab.labelRes)) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = BpsBluePrimary,
                                        selectedTextColor = BpsBluePrimary,
                                        indicatorColor = BpsBlueContainer
                                    ),
                                    modifier = Modifier.testTag(tab.testTag)
                                )
                            }
                        }
                    }
                },
                containerColor = Color.Transparent
            ) { innerPadding ->
                val bottomPadding = PaddingValues(bottom = innerPadding.calculateBottomPadding())

                NavHost(
                    navController = navController,
                    startDestination = SplashRoute,
                    modifier = Modifier.fillMaxSize()
                ) {
                    composable<SplashRoute> {
                        SplashScreen(
                            authRepository = appContainer.authRepository,
                            onNavigateToLogin = {
                                navController.navigate(LoginRoute) {
                                    popUpTo(SplashRoute) { inclusive = true }
                                }
                            },
                            onNavigateToMain = {
                                navController.navigate(HomeTabRoute) {
                                    popUpTo(SplashRoute) { inclusive = true }
                                }
                            }
                        )
                    }

                    composable<LoginRoute> {
                        val vm: LoginViewModel = viewModel(
                            factory = LoginViewModel.Factory(appContainer.authRepository)
                        )
                        LoginScreen(
                            viewModel = vm,
                            onLoginSuccess = {
                                navController.navigate(HomeTabRoute) {
                                    popUpTo(LoginRoute) { inclusive = true }
                                }
                            }
                        )
                    }

                    composable<HomeTabRoute> {
                        val vm: HomeViewModel = viewModel(
                            factory = HomeViewModel.Factory(
                                authRepository = appContainer.authRepository,
                                materialRepository = appContainer.materialRepository
                            )
                        )
                        HomeScreen(
                            viewModel = vm,
                            onCategoryQuickAccess = { category ->
                                pendingCategoryFilter = category
                                navigateToTab(MaterialsTabRoute)
                            },
                            onVideoQuickAccess = {
                                navigateToTab(VideoTabRoute)
                            },
                            onOpenMaterial = ::openMaterial,
                            contentBottomPadding = bottomPadding
                        )
                    }

                    composable<MaterialsTabRoute> {
                        val vm: MaterialsViewModel = viewModel(
                            factory = MaterialsViewModel.Factory(appContainer.materialRepository)
                        )
                        MaterialsScreen(
                            viewModel = vm,
                            initialCategoryFilter = pendingCategoryFilter,
                            onClearInitialCategory = { pendingCategoryFilter = null },
                            onOpenMaterial = ::openMaterial,
                            contentBottomPadding = bottomPadding
                        )
                    }

                    composable<VideoTabRoute> {
                        val vm: VideoViewModel = viewModel(
                            factory = VideoViewModel.Factory(
                                materialRepository = appContainer.materialRepository,
                                authRepository = appContainer.authRepository,
                                videoStreamResolver = appContainer.videoStreamResolver
                            )
                        )
                        VideoScreen(
                            viewModel = vm,
                            okHttpClient = appContainer.portalApiClient.okHttpClient,
                            initialVideoId = pendingVideoId,
                            onClearInitialVideo = { pendingVideoId = null },
                            onFullscreenChanged = { isVideoFullscreen = it },
                            contentBottomPadding = bottomPadding
                        )
                    }

                    composable<ProfileTabRoute> {
                        val vm: ProfileViewModel = viewModel(
                            factory = ProfileViewModel.Factory(
                                authRepository = appContainer.authRepository,
                                materialRepository = appContainer.materialRepository,
                                offlineFileManager = appContainer.offlineFileManager
                            )
                        )
                        ProfileScreen(
                            viewModel = vm,
                            onOpenMaterial = ::openMaterial,
                            onOpenBookmark = { matId, pageIdx ->
                                navController.navigate(
                                    PdfReaderRoute(materialId = matId, initialPage = pageIdx)
                                )
                            },
                            onLoggedOut = {
                                navController.navigate(LoginRoute) {
                                    popUpTo(0) { inclusive = true }
                                }
                            },
                            contentBottomPadding = bottomPadding
                        )
                    }

                    composable<PdfReaderRoute> { entry ->
                        val args = entry.toRoute<PdfReaderRoute>()
                        val vm: PdfReaderViewModel = viewModel(
                            key = "pdf_${args.materialId}_${args.initialPage}",
                            factory = PdfReaderViewModel.Factory(
                                materialId = args.materialId,
                                initialPageArg = args.initialPage,
                                materialRepository = appContainer.materialRepository,
                                authRepository = appContainer.authRepository,
                                driveFileFetcher = appContainer.driveFileFetcher,
                                offlineFileManager = appContainer.offlineFileManager
                            )
                        )
                        PdfReaderScreen(
                            viewModel = vm,
                            onNavigateBack = { navController.popBackStack() }
                        )
                    }

                    composable<PptxViewerRoute> { entry ->
                        val args = entry.toRoute<PptxViewerRoute>()
                        val vm: PptxViewerViewModel = viewModel(
                            key = "pptx_${args.materialId}",
                            factory = PptxViewerViewModel.Factory(
                                materialId = args.materialId,
                                materialRepository = appContainer.materialRepository,
                                authRepository = appContainer.authRepository,
                                driveFileFetcher = appContainer.driveFileFetcher
                            )
                        )
                        PptxViewerScreen(
                            viewModel = vm,
                            onNavigateBack = { navController.popBackStack() }
                        )
                    }
                }
            }
        }
    }
}
