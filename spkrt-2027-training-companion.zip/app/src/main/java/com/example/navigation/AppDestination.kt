package com.example.navigation

import kotlinx.serialization.Serializable

@Serializable
data object SplashRoute

@Serializable
data object LoginRoute

@Serializable
data object HomeTabRoute

@Serializable
data object MaterialsTabRoute

@Serializable
data object VideoTabRoute

@Serializable
data object ProfileTabRoute

@Serializable
data class PdfReaderRoute(
    val materialId: String,
    val initialPage: Int = -1
)

@Serializable
data class PptxViewerRoute(
    val materialId: String
)
