package com.example.data.repository

import com.example.data.catalog.OfficialMaterialCatalog
import com.example.domain.model.CatalogSyncState
import com.example.domain.model.MaterialCategory
import com.example.domain.model.MaterialFileType
import com.example.domain.model.MaterialItem
import com.example.domain.model.PageBookmark
import com.example.domain.model.RecentMaterialEntry
import com.example.domain.model.SyncSource
import com.example.domain.model.VideoProgress
import com.example.network.PortalApiClient
import com.example.network.PortalMaterialDto
import com.example.storage.LocalPreferencesStore
import com.example.storage.OfflineFileManager
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first

class MaterialRepository(
    private val preferencesStore: LocalPreferencesStore,
    private val portalApiClient: PortalApiClient,
    private val offlineFileManager: OfflineFileManager
) {

    private val _syncState = MutableStateFlow(CatalogSyncState())
    val syncState: StateFlow<CatalogSyncState> = _syncState.asStateFlow()

    val favoriteIdsFlow: Flow<Set<String>> = preferencesStore.favoriteIdsFlow
    val recentEntriesFlow: Flow<List<RecentMaterialEntry>> = preferencesStore.recentMaterialsFlow
    val lastReadPagesFlow: Flow<Map<String, Int>> = preferencesStore.lastReadPagesFlow
    val bookmarksFlow: Flow<List<PageBookmark>> = preferencesStore.pageBookmarksFlow
    val videoProgressFlow: Flow<Map<String, VideoProgress>> = preferencesStore.videoProgressFlow
    val offlineFileIdsFlow: StateFlow<Set<String>> = offlineFileManager.offlineFileIds

    /**
     * Merges dynamically synced portal catalog items with the authoritative 32-source official catalog.
     * Official sources are never dropped even if the portal sheet has a subset, while new or updated
     * entries from sheet `MATERI` appear immediately without rebuilding the APK.
     */
    val materialsFlow: Flow<List<MaterialItem>> = combine(
        preferencesStore.cachedPortalCatalogFlow,
        preferencesStore.lastCatalogSyncMillisFlow
    ) { syncedItems, _ ->
        mergeCatalog(syncedItems)
    }

    private fun mergeCatalog(portalItems: List<MaterialItem>): List<MaterialItem> {
        if (portalItems.isEmpty()) {
            return OfficialMaterialCatalog.allMaterials.sortedBy { it.displayOrder }
        }
        val mergedByFileId = LinkedHashMap<String, MaterialItem>()
        OfficialMaterialCatalog.allMaterials.forEach { item ->
            mergedByFileId[item.fileId] = item
        }
        portalItems.filter { it.status.equals("AKTIF", ignoreCase = true) || it.status.isBlank() }
            .forEach { remote ->
                val existing = mergedByFileId[remote.fileId]
                mergedByFileId[remote.fileId] = if (existing != null) {
                    existing.copy(
                        title = remote.title.ifBlank { existing.title },
                        description = remote.description.ifBlank { existing.description },
                        displayOrder = if (remote.displayOrder > 0) remote.displayOrder else existing.displayOrder,
                        status = remote.status.ifBlank { existing.status },
                        updatedAt = remote.updatedAt.ifBlank { existing.updatedAt }
                    )
                } else {
                    remote
                }
            }
        return mergedByFileId.values.sortedBy { it.displayOrder }
    }

    suspend fun getMaterialById(materialId: String): MaterialItem? {
        val currentList = materialsFlow.first()
        return currentList.firstOrNull { it.id == materialId || it.fileId == materialId }
            ?: OfficialMaterialCatalog.findById(materialId)
    }

    suspend fun syncCatalogFromPortal() {
        val portalUrl = preferencesStore.portalUrlFlow.first()
        val session = preferencesStore.userSessionFlow.first()
        val lastSynced = preferencesStore.lastCatalogSyncMillisFlow.first()

        if (portalUrl.isBlank()) {
            _syncState.value = CatalogSyncState(
                source = SyncSource.LOCAL_CATALOG_PORTAL_UNCONFIGURED,
                lastSyncedAtMillis = lastSynced,
                message = "Katalog bawaan aktif (32 sumber Google Drive). Hubungkan URL Portal Apps Script untuk sinkronisasi dinamis sheet MATERI.",
                isSyncing = false
            )
            return
        }

        _syncState.value = _syncState.value.copy(
            isSyncing = true,
            message = "Menyinkronkan katalog dari DATABASE_PORTAL_SPKRT_2027…"
        )

        val token = session?.token.orEmpty()
        val result = portalApiClient.getMaterials(portalUrl, token)
        result.fold(
            onSuccess = { response ->
                val rawList = response.data ?: response.materials
                if (response.success && rawList != null) {
                    val mapped = rawList.mapIndexedNotNull { index, dto -> mapPortalDto(dto, index + 1) }
                    val now = System.currentTimeMillis()
                    preferencesStore.saveCachedPortalCatalog(mapped, now)
                    _syncState.value = CatalogSyncState(
                        source = SyncSource.PORTAL_SYNCED,
                        lastSyncedAtMillis = now,
                        message = "Tersinkronisasi dengan Portal SPKRT 2027 (${mergeCatalog(mapped).size} materi).",
                        isSyncing = false
                    )
                } else {
                    _syncState.value = CatalogSyncState(
                        source = SyncSource.LOCAL_FALLBACK_OFFLINE,
                        lastSyncedAtMillis = lastSynced,
                        message = response.message?.takeIf { it.isNotBlank() }
                            ?: "Portal tidak mengembalikan daftar materi. Menampilkan katalog lokal (32 materi).",
                        isSyncing = false
                    )
                }
            },
            onFailure = { error ->
                _syncState.value = CatalogSyncState(
                    source = SyncSource.LOCAL_FALLBACK_OFFLINE,
                    lastSyncedAtMillis = lastSynced,
                    message = "Gagal sinkronisasi (${error.localizedMessage ?: "offline"}). Menampilkan katalog lokal sebagai cadangan.",
                    isSyncing = false
                )
            }
        )
    }

    private fun mapPortalDto(dto: PortalMaterialDto, fallbackOrder: Int): MaterialItem? {
        val fileId = dto.driveFileId?.trim().takeIf { !it.isNullOrBlank() } ?: return null
        val title = dto.judul?.trim().takeIf { !it.isNullOrBlank() } ?: return null
        val category = MaterialCategory.fromPortalValue(dto.kategori)
        val fileType = MaterialFileType.infer(title, dto.urlMateri, dto.fileType)
        val driveUrl = dto.urlMateri?.trim()?.takeIf { it.startsWith("https://") }
            ?: if (fileType == MaterialFileType.DOCS) {
                "https://docs.google.com/document/d/$fileId/edit"
            } else {
                "https://drive.google.com/file/d/$fileId/view"
            }
        val previewUrl = if (fileType == MaterialFileType.DOCS) {
            "https://docs.google.com/document/d/$fileId/preview"
        } else {
            "https://drive.google.com/file/d/$fileId/preview"
        }

        return MaterialItem(
            id = dto.idMateri?.trim()?.takeIf { it.isNotBlank() } ?: fileId,
            category = category,
            title = title,
            description = dto.deskripsi?.trim().orEmpty(),
            fileId = fileId,
            fileType = fileType,
            driveUrl = driveUrl,
            previewUrl = previewUrl,
            displayOrder = dto.urutan ?: fallbackOrder,
            status = dto.status?.trim()?.ifBlank { "AKTIF" } ?: "AKTIF",
            createdAt = dto.createdAt ?: "",
            updatedAt = dto.updatedAt ?: ""
        )
    }

    suspend fun toggleFavorite(materialId: String) = preferencesStore.toggleFavorite(materialId)

    suspend fun recordMaterialOpened(materialId: String) = preferencesStore.recordRecentMaterial(materialId)

    suspend fun saveLastReadPage(materialId: String, pageIndex: Int) =
        preferencesStore.saveLastReadPage(materialId, pageIndex)

    suspend fun toggleBookmark(materialId: String, materialTitle: String, pageIndex: Int): Boolean =
        preferencesStore.togglePageBookmark(materialId, materialTitle, pageIndex)

    suspend fun removeBookmark(materialId: String, pageIndex: Int) =
        preferencesStore.removeBookmark(materialId, pageIndex)

    suspend fun saveVideoProgress(materialId: String, positionMs: Long, durationMs: Long) =
        preferencesStore.saveVideoProgress(materialId, positionMs, durationMs)
}
