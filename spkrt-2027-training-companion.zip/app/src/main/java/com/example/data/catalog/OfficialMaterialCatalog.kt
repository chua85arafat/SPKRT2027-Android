package com.example.data.catalog

import com.example.domain.model.MaterialCategory
import com.example.domain.model.MaterialFileType
import com.example.domain.model.MaterialItem

/**
 * Official SPKRT 2027 Google Drive Material Catalog (32 verified sources).
 *
 * Rules enforced:
 * - Every fileId is preserved verbatim as the primary material identity.
 * - Google Docs and PDF versions of the same title remain separate sources with their own IDs.
 * - Used as the authoritative initial catalog and offline fallback when Apps Script sync is unavailable.
 */
object OfficialMaterialCatalog {

    private fun docsUrl(fileId: String) = "https://docs.google.com/document/d/$fileId/edit"
    private fun docsPreviewUrl(fileId: String) = "https://docs.google.com/document/d/$fileId/preview"
    private fun driveViewUrl(fileId: String) = "https://drive.google.com/file/d/$fileId/view"
    private fun drivePreviewUrl(fileId: String) = "https://drive.google.com/file/d/$fileId/preview"

    val allMaterials: List<MaterialItem> = listOf(
        // =========================================================================
        // A. BUKU PEDOMAN — 7 SUMBER (3 Google Docs + 4 PDF)
        // =========================================================================
        MaterialItem(
            id = "1OnJo0Oe4tFYpQht-wDh5WqZ8EiiohdYVEuBzhwejFVY",
            category = MaterialCategory.BUKU_PEDOMAN,
            title = "Buku 3 Pedoman Pengisian Kuesioner HR, LK, KK, dan S",
            description = "Versi Google Docs resmi pedoman pengisian kuesioner VPKRT27-HR, LK, KK, dan S.",
            fileId = "1OnJo0Oe4tFYpQht-wDh5WqZ8EiiohdYVEuBzhwejFVY",
            fileType = MaterialFileType.DOCS,
            driveUrl = docsUrl("1OnJo0Oe4tFYpQht-wDh5WqZ8EiiohdYVEuBzhwejFVY"),
            previewUrl = docsPreviewUrl("1OnJo0Oe4tFYpQht-wDh5WqZ8EiiohdYVEuBzhwejFVY"),
            displayOrder = 1
        ),
        MaterialItem(
            id = "14F6gee_WAtW02mM9vAnYbR1nrmp-tlCaYO5fbMJAxso",
            category = MaterialCategory.BUKU_PEDOMAN,
            title = "Buku 4 Pemeriksaan Dokumen SPKRT 2027",
            description = "Versi Google Docs resmi tata cara pemeriksaan kelengkapan dan konsistensi dokumen SPKRT 2027.",
            fileId = "14F6gee_WAtW02mM9vAnYbR1nrmp-tlCaYO5fbMJAxso",
            fileType = MaterialFileType.DOCS,
            driveUrl = docsUrl("14F6gee_WAtW02mM9vAnYbR1nrmp-tlCaYO5fbMJAxso"),
            previewUrl = docsPreviewUrl("14F6gee_WAtW02mM9vAnYbR1nrmp-tlCaYO5fbMJAxso"),
            displayOrder = 2
        ),
        MaterialItem(
            id = "1Pem7kv3Q-rih1LMUtVCLnzyx9oI7glhEkeNkHX5ey7U",
            category = MaterialCategory.BUKU_PEDOMAN,
            title = "Buku 5 Master Kode Komoditas dan Kualitas SPKRT 2027 (Revisi Pelatihan Innas)",
            description = "Versi Google Docs daftar master kode komoditas dan kualitas hasil revisi pelatihan Innas.",
            fileId = "1Pem7kv3Q-rih1LMUtVCLnzyx9oI7glhEkeNkHX5ey7U",
            fileType = MaterialFileType.DOCS,
            driveUrl = docsUrl("1Pem7kv3Q-rih1LMUtVCLnzyx9oI7glhEkeNkHX5ey7U"),
            previewUrl = docsPreviewUrl("1Pem7kv3Q-rih1LMUtVCLnzyx9oI7glhEkeNkHX5ey7U"),
            displayOrder = 3
        ),
        MaterialItem(
            id = "1sdJqhaQ11aoQt26Appu84pIJJJjJLDEq",
            category = MaterialCategory.BUKU_PEDOMAN,
            title = "Buku 3 Pedoman Pengisian Kuesioner HR, LK, KK, dan S.pdf",
            description = "Versi PDF resmi pedoman pengisian kuesioner HR, LK, KK, dan S siap baca offline dan pencarian teks.",
            fileId = "1sdJqhaQ11aoQt26Appu84pIJJJjJLDEq",
            fileType = MaterialFileType.PDF,
            driveUrl = driveViewUrl("1sdJqhaQ11aoQt26Appu84pIJJJjJLDEq"),
            previewUrl = drivePreviewUrl("1sdJqhaQ11aoQt26Appu84pIJJJjJLDEq"),
            displayOrder = 4
        ),
        MaterialItem(
            id = "1i88RZGbUalifNc64ZulpFJa-OGWC7aQS",
            category = MaterialCategory.BUKU_PEDOMAN,
            title = "Buku 5 Master Kode Komoditas dan Kualitas SPKRT 2027 (Revisi Pelatihan Innas).pdf",
            description = "Versi PDF resmi master kode komoditas dan kualitas SPKRT 2027 untuk pencarian kode cepat di lapangan.",
            fileId = "1i88RZGbUalifNc64ZulpFJa-OGWC7aQS",
            fileType = MaterialFileType.PDF,
            driveUrl = driveViewUrl("1i88RZGbUalifNc64ZulpFJa-OGWC7aQS"),
            previewUrl = drivePreviewUrl("1i88RZGbUalifNc64ZulpFJa-OGWC7aQS"),
            displayOrder = 5
        ),
        MaterialItem(
            id = "190-fFU8BzZ2aiXjeSMDgKCYNXdDJf8iS",
            category = MaterialCategory.BUKU_PEDOMAN,
            title = "Buku 4 Pemeriksaan Dokumen SPKRT 2027.pdf",
            description = "Versi PDF resmi pedoman pemeriksaan dokumen hasil pencacahan SPKRT 2027.",
            fileId = "190-fFU8BzZ2aiXjeSMDgKCYNXdDJf8iS",
            fileType = MaterialFileType.PDF,
            driveUrl = driveViewUrl("190-fFU8BzZ2aiXjeSMDgKCYNXdDJf8iS"),
            previewUrl = drivePreviewUrl("190-fFU8BzZ2aiXjeSMDgKCYNXdDJf8iS"),
            displayOrder = 6
        ),
        MaterialItem(
            id = "1g6QqhKYSzPN23fOpihEjIPns0A57VCoQ",
            category = MaterialCategory.BUKU_PEDOMAN,
            title = "Buku 2 Pedoman Pemutakhiran Daftar Rumah Tangga (VPKRT27-P) dan Pengisian Kuesioner VPKRT27-BL dan VPKRT27-BLp.pdf",
            description = "Pedoman pemutakhiran daftar rumah tangga VPKRT27-P serta pengisian kuesioner VPKRT27-BL dan VPKRT27-BLp.",
            fileId = "1g6QqhKYSzPN23fOpihEjIPns0A57VCoQ",
            fileType = MaterialFileType.PDF,
            driveUrl = driveViewUrl("1g6QqhKYSzPN23fOpihEjIPns0A57VCoQ"),
            previewUrl = drivePreviewUrl("1g6QqhKYSzPN23fOpihEjIPns0A57VCoQ"),
            displayOrder = 7
        ),

        // =========================================================================
        // B. KUESIONER — 7 SUMBER (PDF)
        // =========================================================================
        MaterialItem(
            id = "1Z3s0u1iRERdWxqB8m9K2-k_GFyPKYHlf",
            category = MaterialCategory.KUESIONER,
            title = "Kuesioner VPKRT27-S.pdf",
            description = "Instrumen kuesioner VPKRT27-S resmi SPKRT 2027.",
            fileId = "1Z3s0u1iRERdWxqB8m9K2-k_GFyPKYHlf",
            fileType = MaterialFileType.PDF,
            driveUrl = driveViewUrl("1Z3s0u1iRERdWxqB8m9K2-k_GFyPKYHlf"),
            previewUrl = drivePreviewUrl("1Z3s0u1iRERdWxqB8m9K2-k_GFyPKYHlf"),
            displayOrder = 8
        ),
        MaterialItem(
            id = "1Xj8xW2F-16ubs9CJpVDMmYuS_QTojVKV",
            category = MaterialCategory.KUESIONER,
            title = "Kuesioner VPKRT27-LK.pdf",
            description = "Instrumen kuesioner VPKRT27-LK resmi SPKRT 2027.",
            fileId = "1Xj8xW2F-16ubs9CJpVDMmYuS_QTojVKV",
            fileType = MaterialFileType.PDF,
            driveUrl = driveViewUrl("1Xj8xW2F-16ubs9CJpVDMmYuS_QTojVKV"),
            previewUrl = drivePreviewUrl("1Xj8xW2F-16ubs9CJpVDMmYuS_QTojVKV"),
            displayOrder = 9
        ),
        MaterialItem(
            id = "1Jxm9T_4oA-MPQhr7-2A90zaRuon33MpI",
            category = MaterialCategory.KUESIONER,
            title = "Kuesioner VPKRT27-KK.pdf",
            description = "Instrumen kuesioner VPKRT27-KK resmi SPKRT 2027.",
            fileId = "1Jxm9T_4oA-MPQhr7-2A90zaRuon33MpI",
            fileType = MaterialFileType.PDF,
            driveUrl = driveViewUrl("1Jxm9T_4oA-MPQhr7-2A90zaRuon33MpI"),
            previewUrl = drivePreviewUrl("1Jxm9T_4oA-MPQhr7-2A90zaRuon33MpI"),
            displayOrder = 10
        ),
        MaterialItem(
            id = "1VIzaYdstPBQAj9jgsosQe9evIbeW4nQq",
            category = MaterialCategory.KUESIONER,
            title = "Kuesioner VPKRT27-HRp.pdf",
            description = "Instrumen kuesioner VPKRT27-HRp (Harian Pendamping) SPKRT 2027.",
            fileId = "1VIzaYdstPBQAj9jgsosQe9evIbeW4nQq",
            fileType = MaterialFileType.PDF,
            driveUrl = driveViewUrl("1VIzaYdstPBQAj9jgsosQe9evIbeW4nQq"),
            previewUrl = drivePreviewUrl("1VIzaYdstPBQAj9jgsosQe9evIbeW4nQq"),
            displayOrder = 11
        ),
        MaterialItem(
            id = "18o02NAvE8FzdWpX1ouHjLU35Ohh6yAvO",
            category = MaterialCategory.KUESIONER,
            title = "Kuesioner VPKRT27-HR.pdf",
            description = "Instrumen kuesioner VPKRT27-HR resmi SPKRT 2027 (versi dengan cover).",
            fileId = "18o02NAvE8FzdWpX1ouHjLU35Ohh6yAvO",
            fileType = MaterialFileType.PDF,
            driveUrl = driveViewUrl("18o02NAvE8FzdWpX1ouHjLU35Ohh6yAvO"),
            previewUrl = drivePreviewUrl("18o02NAvE8FzdWpX1ouHjLU35Ohh6yAvO"),
            displayOrder = 12
        ),
        MaterialItem(
            id = "1VKFMYWAD94kWCIff5tuRGZzlVxCq9bMx",
            category = MaterialCategory.KUESIONER,
            title = "Kuesioner VPKRT27-BLp.pdf",
            description = "Instrumen kuesioner VPKRT27-BLp resmi SPKRT 2027.",
            fileId = "1VKFMYWAD94kWCIff5tuRGZzlVxCq9bMx",
            fileType = MaterialFileType.PDF,
            driveUrl = driveViewUrl("1VKFMYWAD94kWCIff5tuRGZzlVxCq9bMx"),
            previewUrl = drivePreviewUrl("1VKFMYWAD94kWCIff5tuRGZzlVxCq9bMx"),
            displayOrder = 13
        ),
        MaterialItem(
            id = "1wFT1dglXviILDDc1DDSXIRq0OGnkgxW7",
            category = MaterialCategory.KUESIONER,
            title = "Kuesioner VPKRT27-BL.pdf",
            description = "Instrumen kuesioner VPKRT27-BL resmi SPKRT 2027.",
            fileId = "1wFT1dglXviILDDc1DDSXIRq0OGnkgxW7",
            fileType = MaterialFileType.PDF,
            driveUrl = driveViewUrl("1wFT1dglXviILDDc1DDSXIRq0OGnkgxW7"),
            previewUrl = drivePreviewUrl("1wFT1dglXviILDDc1DDSXIRq0OGnkgxW7"),
            displayOrder = 14
        ),

        // =========================================================================
        // C. BAHAN AJAR — 13 SUMBER (7 PDF + 6 PPTX)
        // =========================================================================
        MaterialItem(
            id = "1ZZ3WlOKl27zheCsgqzB5ZJFnOD6LPLHX",
            category = MaterialCategory.BAHAN_AJAR,
            title = "Buku 2 Pengisian VPKRT27-BL dan VPKRT27-BLp.pdf",
            description = "Bahan tayang format PDF untuk pengisian kuesioner VPKRT27-BL dan VPKRT27-BLp.",
            fileId = "1ZZ3WlOKl27zheCsgqzB5ZJFnOD6LPLHX",
            fileType = MaterialFileType.PDF,
            driveUrl = driveViewUrl("1ZZ3WlOKl27zheCsgqzB5ZJFnOD6LPLHX"),
            previewUrl = drivePreviewUrl("1ZZ3WlOKl27zheCsgqzB5ZJFnOD6LPLHX"),
            displayOrder = 15
        ),
        MaterialItem(
            id = "1josiMy1g0kCh0BA8ZOyNhtZJeWRB8Aww",
            category = MaterialCategory.BAHAN_AJAR,
            title = "Buku 1 Penjelasan Umum SPKRT 2027.pdf",
            description = "Bahan tayang format PDF penjelasan umum latar belakang, tujuan, dan jadwal SPKRT 2027.",
            fileId = "1josiMy1g0kCh0BA8ZOyNhtZJeWRB8Aww",
            fileType = MaterialFileType.PDF,
            driveUrl = driveViewUrl("1josiMy1g0kCh0BA8ZOyNhtZJeWRB8Aww"),
            previewUrl = drivePreviewUrl("1josiMy1g0kCh0BA8ZOyNhtZJeWRB8Aww"),
            displayOrder = 16
        ),
        MaterialItem(
            id = "1uopryX3leSN_7wlv0LYjB-WbNJNAIhWu",
            category = MaterialCategory.BAHAN_AJAR,
            title = "Buku 4 Pemeriksaan Dokumen SPKRT 2027.pdf",
            description = "Bahan tayang format PDF teknik pemeriksaan dokumen lapangan SPKRT 2027.",
            fileId = "1uopryX3leSN_7wlv0LYjB-WbNJNAIhWu",
            fileType = MaterialFileType.PDF,
            driveUrl = driveViewUrl("1uopryX3leSN_7wlv0LYjB-WbNJNAIhWu"),
            previewUrl = drivePreviewUrl("1uopryX3leSN_7wlv0LYjB-WbNJNAIhWu"),
            displayOrder = 17
        ),
        MaterialItem(
            id = "1WsRx-hOlT05ucfApdNjiOP4PufjqgcnM",
            category = MaterialCategory.BAHAN_AJAR,
            title = "FASIH SPKRT 2027.pdf",
            description = "Bahan tayang format PDF panduan penggunaan aplikasi pendataan FASIH SPKRT 2027.",
            fileId = "1WsRx-hOlT05ucfApdNjiOP4PufjqgcnM",
            fileType = MaterialFileType.PDF,
            driveUrl = driveViewUrl("1WsRx-hOlT05ucfApdNjiOP4PufjqgcnM"),
            previewUrl = drivePreviewUrl("1WsRx-hOlT05ucfApdNjiOP4PufjqgcnM"),
            displayOrder = 18
        ),
        MaterialItem(
            id = "142jIwtYxt9_IES8Vh2OC79fc5ExNHG0w",
            category = MaterialCategory.BAHAN_AJAR,
            title = "Metodologi dan Pemutakhiran SPKRT 2027.pdf",
            description = "Bahan tayang format PDF metodologi sampling dan pemutakhiran daftar rumah tangga.",
            fileId = "142jIwtYxt9_IES8Vh2OC79fc5ExNHG0w",
            fileType = MaterialFileType.PDF,
            driveUrl = driveViewUrl("142jIwtYxt9_IES8Vh2OC79fc5ExNHG0w"),
            previewUrl = drivePreviewUrl("142jIwtYxt9_IES8Vh2OC79fc5ExNHG0w"),
            displayOrder = 19
        ),
        MaterialItem(
            id = "1WOAUZr71X2FTSOC7PCNiR8IKALUCJ6Hf",
            category = MaterialCategory.BAHAN_AJAR,
            title = "Sistem Pengolahan Data SPKRT 2027.pdf",
            description = "Bahan ajar PDF sistem pengolahan data SPKRT 2027.",
            fileId = "1WOAUZr71X2FTSOC7PCNiR8IKALUCJ6Hf",
            fileType = MaterialFileType.PDF,
            driveUrl = driveViewUrl("1WOAUZr71X2FTSOC7PCNiR8IKALUCJ6Hf"),
            previewUrl = drivePreviewUrl("1WOAUZr71X2FTSOC7PCNiR8IKALUCJ6Hf"),
            displayOrder = 20
        ),
        MaterialItem(
            id = "1NoOn-_V9mVoqY_sdffgQx0TbBp6P1vbo",
            category = MaterialCategory.BAHAN_AJAR,
            title = "Buku 3 Pengisian VPKRT27-HR_HRp_KK_LK dan VPKRT27-S.pdf",
            description = "Bahan tayang format PDF pengisian kuesioner VPKRT27-HR, HRp, KK, LK, dan S.",
            fileId = "1NoOn-_V9mVoqY_sdffgQx0TbBp6P1vbo",
            fileType = MaterialFileType.PDF,
            driveUrl = driveViewUrl("1NoOn-_V9mVoqY_sdffgQx0TbBp6P1vbo"),
            previewUrl = drivePreviewUrl("1NoOn-_V9mVoqY_sdffgQx0TbBp6P1vbo"),
            displayOrder = 21
        ),
        MaterialItem(
            id = "1zCuBXcu3LeB9Ei54NmKQX91DiRiGVrjY",
            category = MaterialCategory.BAHAN_AJAR,
            title = "Buku 2 Pengisian VPKRT27-BL dan VPKRT27-BLp.pptx",
            description = "Slide presentasi PPTX pengisian kuesioner VPKRT27-BL dan VPKRT27-BLp.",
            fileId = "1zCuBXcu3LeB9Ei54NmKQX91DiRiGVrjY",
            fileType = MaterialFileType.PPTX,
            driveUrl = driveViewUrl("1zCuBXcu3LeB9Ei54NmKQX91DiRiGVrjY"),
            previewUrl = drivePreviewUrl("1zCuBXcu3LeB9Ei54NmKQX91DiRiGVrjY"),
            displayOrder = 22
        ),
        MaterialItem(
            id = "1vvuD-s2atF3RpNaB0-2obEu67ZelLkkB",
            category = MaterialCategory.BAHAN_AJAR,
            title = "Buku 1 Penjelasan Umum SPKRT 2027.pptx",
            description = "Slide presentasi PPTX penjelasan umum pelatihan SPKRT 2027.",
            fileId = "1vvuD-s2atF3RpNaB0-2obEu67ZelLkkB",
            fileType = MaterialFileType.PPTX,
            driveUrl = driveViewUrl("1vvuD-s2atF3RpNaB0-2obEu67ZelLkkB"),
            previewUrl = drivePreviewUrl("1vvuD-s2atF3RpNaB0-2obEu67ZelLkkB"),
            displayOrder = 23
        ),
        MaterialItem(
            id = "13cFvpaeGzdeoueZhXIhW08zUvitiQMdE",
            category = MaterialCategory.BAHAN_AJAR,
            title = "Buku 4 Pemeriksaan Dokumen SPKRT 2027.pptx",
            description = "Slide presentasi PPTX pemeriksaan dokumen SPKRT 2027.",
            fileId = "13cFvpaeGzdeoueZhXIhW08zUvitiQMdE",
            fileType = MaterialFileType.PPTX,
            driveUrl = driveViewUrl("13cFvpaeGzdeoueZhXIhW08zUvitiQMdE"),
            previewUrl = drivePreviewUrl("13cFvpaeGzdeoueZhXIhW08zUvitiQMdE"),
            displayOrder = 24
        ),
        MaterialItem(
            id = "1hv9QJ5v4iRgaKCgeljw7ZfZOBYM5FJyO",
            category = MaterialCategory.BAHAN_AJAR,
            title = "Buku 3 Pengisian VPKRT27-HR_HRp_KK_LK dan VPKRT27-S.pptx",
            description = "Slide presentasi PPTX pengisian kuesioner VPKRT27-HR, HRp, KK, LK, dan S.",
            fileId = "1hv9QJ5v4iRgaKCgeljw7ZfZOBYM5FJyO",
            fileType = MaterialFileType.PPTX,
            driveUrl = driveViewUrl("1hv9QJ5v4iRgaKCgeljw7ZfZOBYM5FJyO"),
            previewUrl = drivePreviewUrl("1hv9QJ5v4iRgaKCgeljw7ZfZOBYM5FJyO"),
            displayOrder = 25
        ),
        MaterialItem(
            id = "1k1tO-sMAUNjjKcOUgjiYfCvFTyc5xKVR",
            category = MaterialCategory.BAHAN_AJAR,
            title = "FASIH SPKRT 2027.pptx",
            description = "Slide presentasi PPTX penggunaan aplikasi FASIH untuk SPKRT 2027.",
            fileId = "1k1tO-sMAUNjjKcOUgjiYfCvFTyc5xKVR",
            fileType = MaterialFileType.PPTX,
            driveUrl = driveViewUrl("1k1tO-sMAUNjjKcOUgjiYfCvFTyc5xKVR"),
            previewUrl = drivePreviewUrl("1k1tO-sMAUNjjKcOUgjiYfCvFTyc5xKVR"),
            displayOrder = 26
        ),
        MaterialItem(
            id = "1SXiEqfS6UbB3-dJ0B7U6loV7f0t5aSp-",
            category = MaterialCategory.BAHAN_AJAR,
            title = "Metodologi dan Pemutakhiran SPKRT 2027.pptx",
            description = "Slide presentasi PPTX metodologi survei dan pemutakhiran rumah tangga SPKRT 2027.",
            fileId = "1SXiEqfS6UbB3-dJ0B7U6loV7f0t5aSp-",
            fileType = MaterialFileType.PPTX,
            driveUrl = driveViewUrl("1SXiEqfS6UbB3-dJ0B7U6loV7f0t5aSp-"),
            previewUrl = drivePreviewUrl("1SXiEqfS6UbB3-dJ0B7U6loV7f0t5aSp-"),
            displayOrder = 27
        ),

        // =========================================================================
        // D. PENEGASAN — 1 SUMBER (PDF)
        // =========================================================================
        MaterialItem(
            id = "1wch1GYYd4GBbDNWmgCrkokIL14YK5tdL",
            category = MaterialCategory.PENEGASAN,
            title = "Rekap Poin Penegasan Pelatihan Innas SPKRT 2027.docx.pdf",
            description = "Dokumen resmi rekap poin-poin penegasan penting hasil pelatihan Instruktur Nasional SPKRT 2027.",
            fileId = "1wch1GYYd4GBbDNWmgCrkokIL14YK5tdL",
            fileType = MaterialFileType.PDF,
            driveUrl = driveViewUrl("1wch1GYYd4GBbDNWmgCrkokIL14YK5tdL"),
            previewUrl = drivePreviewUrl("1wch1GYYd4GBbDNWmgCrkokIL14YK5tdL"),
            displayOrder = 28
        ),

        // =========================================================================
        // E. VIDEO PEMBELAJARAN — 4 SUMBER (VIDEO)
        // =========================================================================
        MaterialItem(
            id = "1RORIAA10dIA9A8dvYlfqhfBoRBQfEWIF",
            category = MaterialCategory.VIDEO,
            title = "Video Materi 1",
            description = "Video pembelajaran resmi sesi 1 pelatihan petugas lapangan SPKRT 2027.",
            fileId = "1RORIAA10dIA9A8dvYlfqhfBoRBQfEWIF",
            fileType = MaterialFileType.VIDEO,
            driveUrl = driveViewUrl("1RORIAA10dIA9A8dvYlfqhfBoRBQfEWIF"),
            previewUrl = drivePreviewUrl("1RORIAA10dIA9A8dvYlfqhfBoRBQfEWIF"),
            displayOrder = 29
        ),
        MaterialItem(
            id = "1dvdUzpLdI49U-f3APU5Vjp3UcR66i6XF",
            category = MaterialCategory.VIDEO,
            title = "Video Materi 2",
            description = "Video pembelajaran resmi sesi 2 pelatihan petugas lapangan SPKRT 2027.",
            fileId = "1dvdUzpLdI49U-f3APU5Vjp3UcR66i6XF",
            fileType = MaterialFileType.VIDEO,
            driveUrl = driveViewUrl("1dvdUzpLdI49U-f3APU5Vjp3UcR66i6XF"),
            previewUrl = drivePreviewUrl("1dvdUzpLdI49U-f3APU5Vjp3UcR66i6XF"),
            displayOrder = 30
        ),
        MaterialItem(
            id = "1ql16ntZ-OHxWtMoDPG6kFRGhfl-X_V31",
            category = MaterialCategory.VIDEO,
            title = "Video Materi 3",
            description = "Video pembelajaran resmi sesi 3 pelatihan petugas lapangan SPKRT 2027.",
            fileId = "1ql16ntZ-OHxWtMoDPG6kFRGhfl-X_V31",
            fileType = MaterialFileType.VIDEO,
            driveUrl = driveViewUrl("1ql16ntZ-OHxWtMoDPG6kFRGhfl-X_V31"),
            previewUrl = drivePreviewUrl("1ql16ntZ-OHxWtMoDPG6kFRGhfl-X_V31"),
            displayOrder = 31
        ),
        MaterialItem(
            id = "15r1mdP9QGBG9LeOX6fy3xMgj7xi2OMrg",
            category = MaterialCategory.VIDEO,
            title = "Video Materi 4",
            description = "Video pembelajaran resmi sesi 4 pelatihan petugas lapangan SPKRT 2027.",
            fileId = "15r1mdP9QGBG9LeOX6fy3xMgj7xi2OMrg",
            fileType = MaterialFileType.VIDEO,
            driveUrl = driveViewUrl("15r1mdP9QGBG9LeOX6fy3xMgj7xi2OMrg"),
            previewUrl = drivePreviewUrl("15r1mdP9QGBG9LeOX6fy3xMgj7xi2OMrg"),
            displayOrder = 32
        )
    )

    fun findById(id: String): MaterialItem? = allMaterials.firstOrNull { it.id == id || it.fileId == id }
}
