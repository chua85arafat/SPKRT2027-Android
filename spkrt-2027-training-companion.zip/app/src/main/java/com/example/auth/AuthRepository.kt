package com.example.auth

import android.util.Patterns
import com.example.domain.model.UserSession
import com.example.network.PortalApiClient
import com.example.storage.LocalPreferencesStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

sealed class AuthResult {
    data class Success(val session: UserSession) : AuthResult()
    data class Error(val message: String) : AuthResult()
}

class AuthRepository(
    private val preferencesStore: LocalPreferencesStore,
    private val portalApiClient: PortalApiClient
) {

    val sessionFlow: Flow<UserSession?> = preferencesStore.userSessionFlow
    val portalUrlFlow: Flow<String> = preferencesStore.portalUrlFlow

    suspend fun getCurrentSession(): UserSession? = sessionFlow.first()

    suspend fun getPortalUrl(): String = portalUrlFlow.first()

    suspend fun savePortalUrl(url: String): Result<String> {
        val trimmed = url.trim()
        if (trimmed.isEmpty()) {
            preferencesStore.savePortalUrl("")
            return Result.success("")
        }
        val validated = PortalApiClient.validatePortalUrl(trimmed)
        if (validated.isSuccess) {
            preferencesStore.savePortalUrl(validated.getOrThrow())
        }
        return validated
    }

    suspend fun loginWithPortal(email: String, password: String): AuthResult {
        val cleanEmail = email.trim()
        if (cleanEmail.isEmpty() || password.isBlank()) {
            return AuthResult.Error("Mohon isi email dan kata sandi terlebih dahulu.")
        }
        if (!Patterns.EMAIL_ADDRESS.matcher(cleanEmail).matches()) {
            return AuthResult.Error("Format alamat email tidak valid.")
        }

        val portalUrl = preferencesStore.portalUrlFlow.first()
        if (portalUrl.isBlank()) {
            return AuthResult.Error(
                "URL Web App Portal Apps Script belum dikonfigurasi. " +
                    "Ketuk 'Bantuan Login & Konfigurasi Portal' untuk memasukkan URL Web App portal BPS, " +
                    "atau gunakan Mode Pratinjau Lokal untuk mengakses katalog 32 materi Google Drive."
            )
        }

        val responseResult = portalApiClient.login(portalUrl, cleanEmail, password)
        return responseResult.fold(
            onSuccess = { response ->
                if (!response.success || response.token.isNullOrBlank()) {
                    AuthResult.Error(
                        response.message?.takeIf { it.isNotBlank() }
                            ?: "Email atau kata sandi tidak sesuai dengan data peserta di portal."
                    )
                } else {
                    val user = response.user
                    val resolvedName = user?.nama?.takeIf { it.isNotBlank() }
                        ?: user?.name?.takeIf { it.isNotBlank() }
                        ?: cleanEmail.substringBefore("@").replaceFirstChar { it.uppercase() }
                    val resolvedRole = user?.peran?.takeIf { it.isNotBlank() }
                        ?: user?.role?.takeIf { it.isNotBlank() }
                        ?: "Peserta Pelatihan"
                    val resolvedClass = user?.kelas?.takeIf { it.isNotBlank() }
                        ?: user?.className?.takeIf { it.isNotBlank() }
                        ?: "SPKRT 2027 — BPS Kab. Pinrang"

                    val session = UserSession(
                        email = user?.email?.takeIf { it.isNotBlank() } ?: cleanEmail,
                        name = resolvedName,
                        role = resolvedRole,
                        className = resolvedClass,
                        token = response.token,
                        isLocalPreview = false
                    )
                    preferencesStore.saveSession(session)
                    AuthResult.Success(session)
                }
            },
            onFailure = { error ->
                AuthResult.Error(
                    error.localizedMessage
                        ?: "Gagal terhubung ke server portal SPKRT 2027. Periksa koneksi internet Anda."
                )
            }
        )
    }

    /**
     * Explicit local preview session for accessing the 32 official Google Drive catalog items
     * before the Apps Script Web App endpoint is connected. Clearly marked in UI as local mode.
     */
    suspend fun enterLocalPreviewMode(displayName: String, email: String): UserSession {
        val cleanName = displayName.trim().ifBlank { "Petugas SPKRT 2027" }
        val cleanEmail = email.trim().ifBlank { "petugas.pinrang@bps.go.id" }
        val session = UserSession(
            email = cleanEmail,
            name = cleanName,
            role = "Peserta Pelatihan (Mode Lokal)",
            className = "BPS Kabupaten Pinrang",
            token = "",
            isLocalPreview = true
        )
        preferencesStore.saveSession(session)
        return session
    }

    suspend fun logout() {
        preferencesStore.clearSession()
    }
}
