package com.example.domain.model

import kotlinx.serialization.Serializable

@Serializable
enum class MaterialCategory(val label: String, val shortLabel: String) {
    BUKU_PEDOMAN("Buku Pedoman", "Pedoman"),
    KUESIONER("Kuesioner", "Kuesioner"),
    BAHAN_AJAR("Bahan Ajar", "Bahan Ajar"),
    PENEGASAN("Penegasan", "Penegasan"),
    VIDEO("Video Pembelajaran", "Video");

    companion object {
        fun fromPortalValue(raw: String?): MaterialCategory {
            val normalized = raw.orEmpty().trim().uppercase().replace(" ", "_")
            return when {
                normalized.contains("PEDOMAN") -> BUKU_PEDOMAN
                normalized.contains("KUESIONER") -> KUESIONER
                normalized.contains("BAHAN") || normalized.contains("AJAR") || normalized.contains("SLIDE") -> BAHAN_AJAR
                normalized.contains("PENEGASAN") -> PENEGASAN
                normalized.contains("VIDEO") -> VIDEO
                else -> BAHAN_AJAR
            }
        }
    }
}

@Serializable
enum class MaterialFileType(val badgeLabel: String) {
    PDF("PDF"),
    DOCS("DOCS"),
    PPTX("PPTX"),
    VIDEO("VIDEO");

    companion object {
        fun infer(title: String, url: String?, explicitType: String? = null): MaterialFileType {
            val hint = explicitType.orEmpty().trim().uppercase()
            when {
                hint == "PDF" -> return PDF
                hint == "DOCS" || hint == "DOC" || hint == "GOOGLE_DOCS" -> return DOCS
                hint == "PPTX" || hint == "PPT" || hint == "SLIDES" -> return PPTX
                hint == "VIDEO" || hint == "MP4" -> return VIDEO
            }
            val lowerTitle = title.lowercase()
            val lowerUrl = url.orEmpty().lowercase()
            return when {
                lowerTitle.endsWith(".pdf") -> PDF
                lowerTitle.endsWith(".pptx") || lowerTitle.endsWith(".ppt") -> PPTX
                lowerUrl.contains("docs.google.com/document") -> DOCS
                lowerTitle.startsWith("video") || lowerTitle.endsWith(".mp4") -> VIDEO
                else -> PDF
            }
        }
    }
}

@Serializable
data class MaterialItem(
    val id: String,
    val category: MaterialCategory,
    val title: String,
    val description: String,
    val fileId: String,
    val fileType: MaterialFileType,
    val driveUrl: String,
    val previewUrl: String,
    val displayOrder: Int,
    val status: String = "AKTIF",
    val createdAt: String = "2027-01-01T00:00:00Z",
    val updatedAt: String = "2027-01-01T00:00:00Z"
) {
    /**
     * Direct binary download or PDF export URL for Google Drive items.
     * - Google Docs are exported to PDF so they can be read with full text search inside the PDF Reader.
     * - Regular Drive files (PDF, PPTX, MP4) use drive.usercontent.google.com with confirm=t to avoid
     *   large-file virus-scan HTML interstitials when permissions permit direct access.
     */
    val directDownloadUrl: String
        get() = when (fileType) {
            MaterialFileType.DOCS ->
                "https://docs.google.com/document/d/$fileId/export?format=pdf"
            else ->
                "https://drive.usercontent.google.com/download?id=$fileId&export=download&confirm=t"
        }

    val safeDisplayTitle: String
        get() = title.removeSuffix(".docx.pdf").removeSuffix(".pdf").removeSuffix(".pptx")
}

@Serializable
data class UserSession(
    val email: String,
    val name: String,
    val role: String,
    val className: String,
    val token: String,
    val isLocalPreview: Boolean = false,
    val loggedInAtMillis: Long = System.currentTimeMillis()
)

@Serializable
data class PageBookmark(
    val materialId: String,
    val materialTitle: String,
    val pageIndex: Int,
    val label: String,
    val createdAtMillis: Long = System.currentTimeMillis()
)

@Serializable
data class RecentMaterialEntry(
    val materialId: String,
    val openedAtMillis: Long
)

@Serializable
data class VideoProgress(
    val materialId: String,
    val positionMs: Long,
    val durationMs: Long,
    val updatedAtMillis: Long = System.currentTimeMillis()
) {
    val progressFraction: Float
        get() = if (durationMs > 0L) (positionMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f) else 0f
}

enum class SyncSource {
    PORTAL_SYNCED,
    LOCAL_FALLBACK_OFFLINE,
    LOCAL_CATALOG_PORTAL_UNCONFIGURED
}

data class CatalogSyncState(
    val source: SyncSource = SyncSource.LOCAL_CATALOG_PORTAL_UNCONFIGURED,
    val lastSyncedAtMillis: Long? = null,
    val message: String = "Menggunakan katalog resmi bawaan (32 materi). Portal Apps Script belum dihubungkan.",
    val isSyncing: Boolean = false
)
