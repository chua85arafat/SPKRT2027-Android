package com.example.ui.reader

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Bookmarks
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.DownloadDone
import androidx.compose.material.icons.filled.FitScreen
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material.icons.filled.ZoomOut
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.ui.theme.BpsBluePrimary
import com.example.ui.theme.BpsGreenSuccess
import com.example.ui.theme.BpsOrangeAccent
import com.example.ui.theme.BpsOrangeContainer
import com.example.ui.theme.BpsOutlineSubtle
import com.example.ui.theme.PdfHighlightActiveOrange
import com.example.ui.theme.PdfHighlightYellow

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PdfReaderScreen(
    viewModel: PdfReaderViewModel,
    onNavigateBack: () -> Unit
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    var showJumpPageDialog by remember { mutableStateOf(false) }
    var showBookmarksSheet by remember { mutableStateOf(false) }

    LaunchedEffect(state.snackbarMessage) {
        state.snackbarMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearSnackbar()
        }
    }

    if (showJumpPageDialog) {
        JumpToPageDialog(
            currentPage = state.currentPage + 1,
            totalPages = state.pageCount,
            onJump = { oneBased ->
                viewModel.goToPage(oneBased - 1)
                showJumpPageDialog = false
            },
            onDismiss = { showJumpPageDialog = false }
        )
    }

    if (showBookmarksSheet) {
        ModalBottomSheet(
            onDismissRequest = { showBookmarksSheet = false }
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 8.dp)
                    .navigationBarsPadding()
            ) {
                Text(
                    text = "Bookmark Dokumen (${state.bookmarksForDocument.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(10.dp))
                if (state.bookmarksForDocument.isEmpty()) {
                    Text(
                        text = "Belum ada halaman yang ditandai pada dokumen ini. Ketuk ikon bookmark di bar atas untuk menandai halaman.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 16.dp)
                    )
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.padding(bottom = 16.dp)
                    ) {
                        items(state.bookmarksForDocument, key = { "${it.materialId}_${it.pageIndex}" }) { bm ->
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(1.dp, BpsOutlineSubtle),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        viewModel.goToPage(bm.pageIndex)
                                        showBookmarksSheet = false
                                    }
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Bookmark,
                                        contentDescription = null,
                                        tint = BpsOrangeAccent
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text(
                                        text = "Halaman ${bm.pageIndex + 1}",
                                        style = MaterialTheme.typography.titleSmall,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Text(
                                        text = "Buka",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = BpsBluePrimary,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("pdf_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.cd_navigate_back),
                            tint = Color.White
                        )
                    }
                },
                title = {
                    Column {
                        Text(
                            text = state.material?.safeDisplayTitle ?: "Pembaca PDF",
                            style = MaterialTheme.typography.titleMedium,
                            color = Color.White,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = state.material?.category?.label.orEmpty(),
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White.copy(alpha = 0.85f)
                        )
                    }
                },
                actions = {
                    if (state.loadState is PdfLoadState.Ready && !state.useDrivePreviewFallback) {
                        IconButton(
                            onClick = viewModel::toggleSearchBar,
                            modifier = Modifier.testTag("pdf_toggle_search_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Search,
                                contentDescription = stringResource(R.string.cd_search),
                                tint = Color.White
                            )
                        }
                        IconButton(
                            onClick = viewModel::toggleCurrentPageBookmark,
                            modifier = Modifier.testTag("pdf_bookmark_button")
                        ) {
                            Icon(
                                imageVector = if (state.isCurrentPageBookmarked) {
                                    Icons.Filled.Bookmark
                                } else {
                                    Icons.Filled.BookmarkBorder
                                },
                                contentDescription = stringResource(R.string.cd_bookmark),
                                tint = if (state.isCurrentPageBookmarked) BpsOrangeAccent else Color.White
                            )
                        }
                        IconButton(
                            onClick = { showBookmarksSheet = true },
                            modifier = Modifier.testTag("pdf_bookmarks_list_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Bookmarks,
                                contentDescription = "Daftar bookmark",
                                tint = Color.White
                            )
                        }
                        IconButton(
                            onClick = viewModel::toggleOfflineSave,
                            enabled = !state.isSavingOffline,
                            modifier = Modifier.testTag("pdf_offline_toggle_button")
                        ) {
                            Icon(
                                imageVector = if (state.isOfflineSaved) {
                                    Icons.Filled.DownloadDone
                                } else {
                                    Icons.Filled.CloudDownload
                                },
                                contentDescription = if (state.isOfflineSaved) {
                                    stringResource(R.string.pdf_saved_offline)
                                } else {
                                    stringResource(R.string.pdf_download_offline)
                                },
                                tint = if (state.isOfflineSaved) Color(0xFF9DF5BD) else Color.White
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BpsBluePrimary)
            )
        },
        bottomBar = {
            if (state.loadState is PdfLoadState.Ready && !state.useDrivePreviewFallback) {
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    shadowElevation = 6.dp
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .navigationBarsPadding()
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        // Page navigation controls
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(
                                onClick = viewModel::previousPage,
                                enabled = state.currentPage > 0,
                                modifier = Modifier.testTag("pdf_prev_page_button")
                            ) {
                                Icon(Icons.Filled.ChevronLeft, contentDescription = "Halaman sebelumnya")
                            }
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f),
                                modifier = Modifier
                                    .testTag("pdf_page_jump_chip")
                                    .clickable { showJumpPageDialog = true }
                            ) {
                                Text(
                                    text = "${state.currentPage + 1} / ${state.pageCount}",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
                                )
                            }
                            IconButton(
                                onClick = viewModel::nextPage,
                                enabled = state.currentPage < state.pageCount - 1,
                                modifier = Modifier.testTag("pdf_next_page_button")
                            ) {
                                Icon(Icons.Filled.ChevronRight, contentDescription = "Halaman berikutnya")
                            }
                        }

                        // Zoom & Fit-width controls
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(
                                onClick = viewModel::zoomOut,
                                enabled = state.zoomScale > 1.0f,
                                modifier = Modifier.testTag("pdf_zoom_out_button")
                            ) {
                                Icon(
                                    Icons.Filled.ZoomOut,
                                    contentDescription = stringResource(R.string.cd_zoom_out)
                                )
                            }
                            IconButton(
                                onClick = viewModel::zoomIn,
                                enabled = state.zoomScale < 3.0f,
                                modifier = Modifier.testTag("pdf_zoom_in_button")
                            ) {
                                Icon(
                                    Icons.Filled.ZoomIn,
                                    contentDescription = stringResource(R.string.cd_zoom_in)
                                )
                            }
                            IconButton(
                                onClick = viewModel::fitToWidth,
                                modifier = Modifier.testTag("pdf_fit_width_button")
                            ) {
                                Icon(
                                    Icons.Filled.FitScreen,
                                    contentDescription = stringResource(R.string.cd_fit_width)
                                )
                            }
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(Color(0xFFE6ECF3))
                .testTag("pdf_reader_screen")
        ) {
            // In-Document PDF Text Search Bar (matching Storyboard screen 5)
            if (state.isSearchBarVisible && state.loadState is PdfLoadState.Ready && !state.useDrivePreviewFallback) {
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    shadowElevation = 3.dp
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            OutlinedTextField(
                                value = state.searchQuery,
                                onValueChange = viewModel::onSearchQueryChange,
                                placeholder = { Text(stringResource(R.string.pdf_search_placeholder)) },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                                keyboardActions = KeyboardActions(onSearch = { viewModel.executeSearch() }),
                                trailingIcon = {
                                    if (state.searchQuery.isNotEmpty()) {
                                        IconButton(onClick = { viewModel.onSearchQueryChange("") }) {
                                            Icon(Icons.Filled.Close, contentDescription = "Bersihkan")
                                        }
                                    }
                                },
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("pdf_search_input")
                            )
                            Button(
                                onClick = viewModel::executeSearch,
                                enabled = state.searchQuery.isNotBlank() && !state.isSearching,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.testTag("pdf_search_submit_button")
                            ) {
                                Text("Cari")
                            }
                        }

                        if (state.isSearching || state.indexingProgressText != null) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(16.dp),
                                    strokeWidth = 2.dp
                                )
                                Text(
                                    text = state.indexingProgressText ?: "Mencari teks…",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        } else if (state.searchQuery.isNotBlank() && !state.isScannedWithoutTextLayer) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                val countLabel = if (state.searchMatches.isEmpty()) {
                                    "0 hasil ditemukan"
                                } else {
                                    "Hasil ${state.activeMatchIndex + 1} / ${state.searchMatches.size}"
                                }
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = countLabel,
                                        style = MaterialTheme.typography.labelMedium,
                                        color = BpsBluePrimary,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.testTag("pdf_search_count_label")
                                    )
                                    state.activeMatch?.let { match ->
                                        Text(
                                            text = "Hal. ${match.pageIndex + 1}: …${match.snippet}…",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                                Row {
                                    IconButton(
                                        onClick = viewModel::previousSearchMatch,
                                        enabled = state.searchMatches.isNotEmpty(),
                                        modifier = Modifier.testTag("pdf_search_prev_button")
                                    ) {
                                        Icon(Icons.Filled.ChevronLeft, contentDescription = "Hasil sebelumnya")
                                    }
                                    IconButton(
                                        onClick = viewModel::nextSearchMatch,
                                        enabled = state.searchMatches.isNotEmpty(),
                                        modifier = Modifier.testTag("pdf_search_next_button")
                                    ) {
                                        Icon(Icons.Filled.ChevronRight, contentDescription = "Hasil berikutnya")
                                    }
                                }
                            }
                        }
                    }
                }
                HorizontalDivider(color = BpsOutlineSubtle)
            }

            // Scanned PDF honest notice banner
            if (state.isScannedWithoutTextLayer && state.loadState is PdfLoadState.Ready && !state.useDrivePreviewFallback) {
                Surface(
                    color = BpsOrangeContainer,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Info,
                            contentDescription = null,
                            tint = BpsOrangeAccent,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = stringResource(R.string.pdf_scanned_notice),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }

            // Main Content Area
            if (state.useDrivePreviewFallback) {
                val previewUrl = state.material?.previewUrl.orEmpty()
                ControlledDriveWebView(
                    previewUrl = previewUrl,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                when (val load = state.loadState) {
                    is PdfLoadState.Downloading -> {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            Card(
                                shape = RoundedCornerShape(20.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(24.dp)
                            ) {
                                Column(
                                    modifier = Modifier.padding(24.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(14.dp)
                                ) {
                                    CircularProgressIndicator(color = BpsBluePrimary)
                                    Text(
                                        text = load.statusText,
                                        style = MaterialTheme.typography.titleSmall
                                    )
                                    LinearProgressIndicator(
                                        progress = { load.progress.coerceIn(0.05f, 1f) },
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                    Text(
                                        text = "File diambil on-demand dari Google Drive (ID: ${state.material?.fileId.orEmpty()})",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }

                    is PdfLoadState.AccessRestricted -> {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(20.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Card(
                                shape = RoundedCornerShape(20.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                border = BorderStroke(1.dp, BpsOutlineSubtle)
                            ) {
                                Column(
                                    modifier = Modifier.padding(22.dp),
                                    verticalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Filled.Lock,
                                            contentDescription = null,
                                            tint = BpsOrangeAccent,
                                            modifier = Modifier.size(26.dp)
                                        )
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Text(
                                            text = "Izin Akses Google Drive Diperlukan",
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                    Text(
                                        text = load.reason,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Surface(
                                        color = MaterialTheme.colorScheme.surfaceVariant,
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(
                                            text = "File ID: ${load.fileId}",
                                            style = MaterialTheme.typography.labelSmall,
                                            modifier = Modifier.padding(10.dp)
                                        )
                                    }
                                    Button(
                                        onClick = viewModel::switchToDrivePreviewFallback,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(48.dp)
                                            .testTag("pdf_open_drive_preview_button")
                                    ) {
                                        Text("Buka Pratinjau Google Drive (In-App)")
                                    }
                                    OutlinedButton(
                                        onClick = { viewModel.loadDocument(forceRetry = true) },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(48.dp)
                                    ) {
                                        Icon(Icons.Filled.Refresh, contentDescription = null)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(stringResource(R.string.action_retry))
                                    }
                                }
                            }
                        }
                    }

                    is PdfLoadState.Error -> {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(20.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Card(
                                shape = RoundedCornerShape(20.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Column(
                                    modifier = Modifier.padding(22.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.WarningAmber,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.error,
                                        modifier = Modifier.size(36.dp)
                                    )
                                    Text(
                                        text = "Dokumen Gagal Dimuat",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = load.message,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Button(
                                        onClick = { viewModel.loadDocument(forceRetry = true) },
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(stringResource(R.string.action_retry))
                                    }
                                    OutlinedButton(
                                        onClick = viewModel::switchToDrivePreviewFallback,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text("Coba Pratinjau Google Drive")
                                    }
                                }
                            }
                        }
                    }

                    is PdfLoadState.Ready -> {
                        val density = LocalDensity.current
                        BoxWithConstraints(
                            modifier = Modifier.fillMaxSize()
                        ) {
                            val viewportWidthPx = with(density) { maxWidth.toPx().toInt() }
                            LaunchedEffect(viewportWidthPx) {
                                viewModel.updateViewportWidth(viewportWidthPx)
                            }

                            val scaledPageWidth = (maxWidth * state.zoomScale - 24.dp).coerceAtLeast(240.dp)
                            val bitmap = state.renderedBitmap

                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .verticalScroll(rememberScrollState())
                                    .horizontalScroll(rememberScrollState())
                                    .padding(12.dp),
                                contentAlignment = Alignment.TopCenter
                            ) {
                                if (bitmap != null) {
                                    val aspectRatio = bitmap.width.toFloat() / bitmap.height.toFloat().coerceAtLeast(1f)
                                    Surface(
                                        shadowElevation = 4.dp,
                                        color = Color.White,
                                        modifier = Modifier
                                            .width(scaledPageWidth)
                                            .aspectRatio(aspectRatio)
                                    ) {
                                        Box(modifier = Modifier.fillMaxSize()) {
                                            Image(
                                                bitmap = bitmap.asImageBitmap(),
                                                contentDescription = "Halaman ${state.currentPage + 1}",
                                                contentScale = ContentScale.FillBounds,
                                                modifier = Modifier.fillMaxSize()
                                            )

                                            // Exact coordinate highlight overlay for PDFBox search matches
                                            val pageMatches = state.currentPageMatches
                                            val activeMatchIdx = state.activeMatchIndex
                                            if (pageMatches.isNotEmpty()) {
                                                Canvas(modifier = Modifier.fillMaxSize()) {
                                                    pageMatches.forEach { match ->
                                                        val color = if (match.matchIndex == activeMatchIdx) {
                                                            PdfHighlightActiveOrange
                                                        } else {
                                                            PdfHighlightYellow
                                                        }
                                                        match.rects.forEach { r ->
                                                            val left = (r.left * size.width).coerceIn(0f, size.width)
                                                            val top = (r.top * size.height).coerceIn(0f, size.height)
                                                            val w = ((r.right - r.left) * size.width).coerceAtLeast(6f)
                                                            val h = ((r.bottom - r.top) * size.height).coerceAtLeast(10f)
                                                            drawRoundRect(
                                                                color = color,
                                                                topLeft = Offset(left - 2f, top - 2f),
                                                                size = Size(w + 4f, h + 4f),
                                                                cornerRadius = CornerRadius(4f, 4f)
                                                            )
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                } else {
                                    CircularProgressIndicator(
                                        color = BpsBluePrimary,
                                        modifier = Modifier.padding(top = 64.dp)
                                    )
                                }
                            }

                            if (state.isRenderingPage) {
                                LinearProgressIndicator(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .align(Alignment.TopCenter)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun JumpToPageDialog(
    currentPage: Int,
    totalPages: Int,
    onJump: (Int) -> Unit,
    onDismiss: () -> Unit
) {
    var input by remember(currentPage) { mutableStateOf(currentPage.toString()) }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Lompat ke Halaman") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Masukkan nomor halaman antara 1 sampai $totalPages.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedTextField(
                    value = input,
                    onValueChange = {
                        input = it.filter { ch -> ch.isDigit() }
                        error = null
                    },
                    label = { Text("Nomor Halaman") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("pdf_jump_page_input")
                )
                error?.let {
                    Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val pageNum = input.toIntOrNull()
                    if (pageNum == null || pageNum !in 1..totalPages) {
                        error = "Masukkan angka valid antara 1 hingga $totalPages."
                    } else {
                        onJump(pageNum)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = BpsBluePrimary)
            ) {
                Text("Buka Halaman")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.action_cancel))
            }
        }
    )
}
