package com.example.ui.reader

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.auth.AuthRepository
import com.example.data.repository.MaterialRepository
import com.example.domain.model.MaterialItem
import com.example.network.DriveFetchResult
import com.example.network.DriveFileFetcher
import com.example.reader.PptxSlideContent
import com.example.reader.PptxSlideParser
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class PptxViewMode(val label: String) {
    DRIVE_VISUAL("Visual Slide"),
    NATIVE_OFFLINE("Teks Slide (Offline)")
}

data class PptxViewerUiState(
    val material: MaterialItem? = null,
    val viewMode: PptxViewMode = PptxViewMode.DRIVE_VISUAL,
    val isLoadingNative: Boolean = false,
    val nativeSlides: List<PptxSlideContent> = emptyList(),
    val currentSlideIndex: Int = 0,
    val textZoomScale: Float = 1.0f,
    val nativeErrorMessage: String? = null,
    val driveWebError: String? = null,
    val isFavorite: Boolean = false
)

class PptxViewerViewModel(
    private val materialId: String,
    private val materialRepository: MaterialRepository,
    private val authRepository: AuthRepository,
    private val driveFileFetcher: DriveFileFetcher
) : ViewModel() {

    private val _uiState = MutableStateFlow(PptxViewerUiState())
    val uiState: StateFlow<PptxViewerUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            materialRepository.favoriteIdsFlow.collect { favs ->
                _uiState.update { it.copy(isFavorite = materialId in favs) }
            }
        }
        viewModelScope.launch {
            val mat = materialRepository.getMaterialById(materialId)
            if (mat != null) {
                materialRepository.recordMaterialOpened(mat.id)
                _uiState.update { it.copy(material = mat) }
            }
        }
    }

    fun selectMode(mode: PptxViewMode) {
        _uiState.update { it.copy(viewMode = mode, driveWebError = null) }
        if (mode == PptxViewMode.NATIVE_OFFLINE && _uiState.value.nativeSlides.isEmpty()) {
            loadNativeSlides()
        }
    }

    fun loadNativeSlides() {
        val mat = _uiState.value.material ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isLoadingNative = true, nativeErrorMessage = null) }
            val portalUrl = authRepository.getPortalUrl()
            val token = authRepository.getCurrentSession()?.token.orEmpty()

            when (
                val fetch = driveFileFetcher.fetchDocumentFile(
                    material = mat,
                    portalBaseUrl = portalUrl,
                    sessionToken = token,
                    saveForOffline = false
                )
            ) {
                is DriveFetchResult.Success -> {
                    runCatching {
                        val slides = PptxSlideParser.parseSlides(fetch.file)
                        if (slides.isEmpty()) {
                            _uiState.update {
                                it.copy(
                                    isLoadingNative = false,
                                    nativeErrorMessage = "Slide PPTX ini sebagian besar berisi gambar/objek grafis tanpa teks XML. Gunakan tab 'Visual Slide' untuk melihat tampilan penuh."
                                )
                            }
                        } else {
                            _uiState.update {
                                it.copy(
                                    isLoadingNative = false,
                                    nativeSlides = slides,
                                    currentSlideIndex = 0
                                )
                            }
                        }
                    }.onFailure { err ->
                        _uiState.update {
                            it.copy(
                                isLoadingNative = false,
                                nativeErrorMessage = "Gagal membaca berkas PPTX secara native: ${err.localizedMessage ?: "format tidak didukung"}. Gunakan tab Visual Slide."
                            )
                        }
                    }
                }
                is DriveFetchResult.AccessDenied -> {
                    _uiState.update {
                        it.copy(
                            isLoadingNative = false,
                            nativeErrorMessage = fetch.reason
                        )
                    }
                }
                is DriveFetchResult.NetworkError -> {
                    _uiState.update {
                        it.copy(
                            isLoadingNative = false,
                            nativeErrorMessage = fetch.message
                        )
                    }
                }
            }
        }
    }

    fun nextSlide() {
        val total = _uiState.value.nativeSlides.size
        if (total == 0) return
        _uiState.update { it.copy(currentSlideIndex = (it.currentSlideIndex + 1).coerceAtMost(total - 1)) }
    }

    fun previousSlide() {
        _uiState.update { it.copy(currentSlideIndex = (it.currentSlideIndex - 1).coerceAtLeast(0)) }
    }

    fun zoomIn() {
        _uiState.update { it.copy(textZoomScale = (it.textZoomScale + 0.15f).coerceAtMost(1.8f)) }
    }

    fun zoomOut() {
        _uiState.update { it.copy(textZoomScale = (it.textZoomScale - 0.15f).coerceAtLeast(0.85f)) }
    }

    fun onDriveWebError(msg: String) {
        _uiState.update { it.copy(driveWebError = msg) }
    }

    fun toggleFavorite() {
        viewModelScope.launch { materialRepository.toggleFavorite(materialId) }
    }

    class Factory(
        private val materialId: String,
        private val materialRepository: MaterialRepository,
        private val authRepository: AuthRepository,
        private val driveFileFetcher: DriveFileFetcher
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return PptxViewerViewModel(materialId, materialRepository, authRepository, driveFileFetcher) as T
        }
    }
}
