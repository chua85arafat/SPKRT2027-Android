package com.example.ui.login

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.auth.AuthRepository
import com.example.auth.AuthResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class LoginUiState(
    val email: String = "",
    val password: String = "",
    val portalUrl: String = "",
    val isLoading: Boolean = false,
    val errorMessage: String? = null,
    val showPortalDialog: Boolean = false,
    val portalDialogError: String? = null,
    val loginSuccess: Boolean = false
)

class LoginViewModel(
    private val authRepository: AuthRepository
) : ViewModel() {

    private val _email = MutableStateFlow("")
    private val _password = MutableStateFlow("")
    private val _isLoading = MutableStateFlow(false)
    private val _errorMessage = MutableStateFlow<String?>(null)
    private val _showPortalDialog = MutableStateFlow(false)
    private val _portalDialogError = MutableStateFlow<String?>(null)
    private val _loginSuccess = MutableStateFlow(false)

    val uiState: StateFlow<LoginUiState> = combine<Any?, LoginUiState>(
        _email,
        _password,
        authRepository.portalUrlFlow,
        _isLoading,
        _errorMessage,
        _showPortalDialog,
        _portalDialogError,
        _loginSuccess
    ) { values ->
        LoginUiState(
            email = values[0] as String,
            password = values[1] as String,
            portalUrl = values[2] as String,
            isLoading = values[3] as Boolean,
            errorMessage = values[4] as String?,
            showPortalDialog = values[5] as Boolean,
            portalDialogError = values[6] as String?,
            loginSuccess = values[7] as Boolean
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = LoginUiState()
    )

    fun onEmailChange(value: String) {
        _email.value = value
        _errorMessage.value = null
    }

    fun onPasswordChange(value: String) {
        _password.value = value
        _errorMessage.value = null
    }

    fun openPortalConfigDialog() {
        _portalDialogError.value = null
        _showPortalDialog.value = true
    }

    fun dismissPortalConfigDialog() {
        _showPortalDialog.value = false
        _portalDialogError.value = null
    }

    fun savePortalUrl(url: String) {
        viewModelScope.launch {
            val result = authRepository.savePortalUrl(url)
            if (result.isSuccess) {
                _showPortalDialog.value = false
                _portalDialogError.value = null
                _errorMessage.value = null
            } else {
                _portalDialogError.value = result.exceptionOrNull()?.localizedMessage
                    ?: "URL Portal tidak valid."
            }
        }
    }

    fun submitLogin() {
        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null
            when (val res = authRepository.loginWithPortal(_email.value, _password.value)) {
                is AuthResult.Success -> {
                    _isLoading.value = false
                    _loginSuccess.value = true
                }
                is AuthResult.Error -> {
                    _isLoading.value = false
                    _errorMessage.value = res.message
                }
            }
        }
    }

    fun continueLocalPreviewMode() {
        viewModelScope.launch {
            _isLoading.value = true
            val emailVal = _email.value.trim().ifBlank { "petugas.pinrang@bps.go.id" }
            val derivedName = emailVal.substringBefore("@")
                .replace('.', ' ')
                .split(' ')
                .filter { it.isNotBlank() }
                .joinToString(" ") { part -> part.replaceFirstChar { it.uppercase() } }
                .ifBlank { "Peserta SPKRT 2027" }
            authRepository.enterLocalPreviewMode(displayName = derivedName, email = emailVal)
            _isLoading.value = false
            _loginSuccess.value = true
        }
    }

    class Factory(private val authRepository: AuthRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return LoginViewModel(authRepository) as T
        }
    }
}
