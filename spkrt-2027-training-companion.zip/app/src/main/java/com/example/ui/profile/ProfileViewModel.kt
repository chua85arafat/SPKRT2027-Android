package com.example.ui.profile

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.auth.AuthRepository
import com.example.data.repository.MaterialRepository
import com.example.domain.model.CatalogSyncState
import com.example.domain.model.MaterialItem
import com.example.domain.model.PageBookmark
import com.example.domain.model.UserSession
import com.example.storage.OfflineFileManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class ProfileUiState(
    val userSession: UserSession? = null,
    val portalUrl: String = "",
    val syncState: CatalogSyncState = CatalogSyncState(),
    val favoriteMaterials: List<MaterialItem> = emptyList(),
    val recentMaterials: List<MaterialItem> = emptyList(),
    val bookmarks: List<PageBookmark> = emptyList(),
    val offlineBytes: Long = 0L,
    val cacheBytes: Long = 0L,
    val offlineCount: Int = 0,
    val showPortalDialog: Boolean = false,
    val portalDialogError: String? = null,
    val loggedOut: Boolean = false
)

class ProfileViewModel(
    private val authRepository: AuthRepository,
    private val materialRepository: MaterialRepository,
    private val offlineFileManager: OfflineFileManager
) : ViewModel() {

    private val _storageBytes = MutableStateFlow(0L to 0L)
    private val _showPortalDialog = MutableStateFlow(false)
    private val _portalDialogError = MutableStateFlow<String?>(null)
    private val _loggedOut = MutableStateFlow(false)

    val uiState: StateFlow<ProfileUiState> = combine<Any?, ProfileUiState>(
        authRepository.sessionFlow,
        authRepository.portalUrlFlow,
        materialRepository.syncState,
        materialRepository.materialsFlow,
        materialRepository.favoriteIdsFlow,
        materialRepository.recentEntriesFlow,
        materialRepository.bookmarksFlow,
        materialRepository.offlineFileIdsFlow,
        _storageBytes,
        _showPortalDialog,
        _portalDialogError,
        _loggedOut
    ) { values ->
        val session = values[0] as UserSession?
        val portalUrl = values[1] as String
        val syncState = values[2] as CatalogSyncState
        @Suppress("UNCHECKED_CAST")
        val materials = values[3] as List<MaterialItem>
        @Suppress("UNCHECKED_CAST")
        val favIds = values[4] as Set<String>
        @Suppress("UNCHECKED_CAST")
        val recentEntries = values[5] as List<com.example.domain.model.RecentMaterialEntry>
        @Suppress("UNCHECKED_CAST")
        val bookmarks = values[6] as List<PageBookmark>
        @Suppress("UNCHECKED_CAST")
        val offlineIds = values[7] as Set<String>
        @Suppress("UNCHECKED_CAST")
        val storagePair = values[8] as Pair<Long, Long>
        val showDialog = values[9] as Boolean
        val dialogErr = values[10] as String?
        val loggedOut = values[11] as Boolean

        val byId = materials.associateBy { it.id }

        ProfileUiState(
            userSession = session,
            portalUrl = portalUrl,
            syncState = syncState,
            favoriteMaterials = materials.filter { it.id in favIds },
            recentMaterials = recentEntries.mapNotNull { byId[it.materialId] },
            bookmarks = bookmarks,
            offlineBytes = storagePair.first,
            cacheBytes = storagePair.second,
            offlineCount = offlineIds.size,
            showPortalDialog = showDialog,
            portalDialogError = dialogErr,
            loggedOut = loggedOut
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = ProfileUiState()
    )

    init {
        refreshStorageInfo()
    }

    fun refreshStorageInfo() {
        viewModelScope.launch {
            _storageBytes.value = offlineFileManager.getTotalStorageBytes()
        }
    }

    fun syncCatalog() {
        viewModelScope.launch {
            materialRepository.syncCatalogFromPortal()
        }
    }

    fun openPortalConfigDialog() {
        _portalDialogError.value = null
        _showPortalDialog.value = true
    }

    fun dismissPortalConfigDialog() {
        _showPortalDialog.value = false
        _portalDialogError.value = null
    }

    fun savePortalUrl(url: String) {
        viewModelScope.launch {
            val res = authRepository.savePortalUrl(url)
            if (res.isSuccess) {
                _showPortalDialog.value = false
                _portalDialogError.value = null
                materialRepository.syncCatalogFromPortal()
            } else {
                _portalDialogError.value = res.exceptionOrNull()?.localizedMessage ?: "URL tidak valid."
            }
        }
    }

    fun removeBookmark(materialId: String, pageIndex: Int) {
        viewModelScope.launch {
            materialRepository.removeBookmark(materialId, pageIndex)
        }
    }

    fun clearTemporaryCache() {
        viewModelScope.launch {
            offlineFileManager.clearTemporaryCache()
            refreshStorageInfo()
        }
    }

    fun clearOfflineFiles() {
        viewModelScope.launch {
            offlineFileManager.clearAllOfflineFiles()
            refreshStorageInfo()
        }
    }

    fun logout() {
        viewModelScope.launch {
            authRepository.logout()
            _loggedOut.value = true
        }
    }

    class Factory(
        private val authRepository: AuthRepository,
        private val materialRepository: MaterialRepository,
        private val offlineFileManager: OfflineFileManager
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return ProfileViewModel(authRepository, materialRepository, offlineFileManager) as T
        }
    }
}
