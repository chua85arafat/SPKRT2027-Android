package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.DownloadDone
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Slideshow
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.outlined.StarOutline
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.BuildConfig
import com.example.R
import com.example.domain.model.CatalogSyncState
import com.example.domain.model.MaterialFileType
import com.example.domain.model.MaterialItem
import com.example.domain.model.SyncSource
import com.example.ui.theme.BadgeDocsBlue
import com.example.ui.theme.BadgeDocsContainer
import com.example.ui.theme.BadgePdfContainer
import com.example.ui.theme.BadgePdfRed
import com.example.ui.theme.BadgePptxContainer
import com.example.ui.theme.BadgePptxOrange
import com.example.ui.theme.BadgeVideoContainer
import com.example.ui.theme.BadgeVideoRed
import com.example.ui.theme.BpsBlueDark
import com.example.ui.theme.BpsBluePrimary
import com.example.ui.theme.BpsGreenContainer
import com.example.ui.theme.BpsGreenSuccess
import com.example.ui.theme.BpsOrangeAccent
import com.example.ui.theme.BpsOrangeContainer
import com.example.ui.theme.BpsOutlineSubtle

@Composable
fun FileTypeBadge(
    fileType: MaterialFileType,
    modifier: Modifier = Modifier
) {
    val (bg, fg, icon) = when (fileType) {
        MaterialFileType.PDF -> Triple(BadgePdfContainer, BadgePdfRed, Icons.Filled.PictureAsPdf)
        MaterialFileType.DOCS -> Triple(BadgeDocsContainer, BadgeDocsBlue, Icons.Filled.Description)
        MaterialFileType.PPTX -> Triple(BadgePptxContainer, BadgePptxOrange, Icons.Filled.Slideshow)
        MaterialFileType.VIDEO -> Triple(BadgeVideoContainer, BadgeVideoRed, Icons.Filled.PlayCircle)
    }
    Column(
        modifier = modifier
            .size(width = 48.dp, height = 52.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(bg),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = fileType.badgeLabel,
            tint = fg,
            modifier = Modifier.size(22.dp)
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = fileType.badgeLabel,
            style = MaterialTheme.typography.labelSmall,
            color = fg,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun MaterialItemCard(
    material: MaterialItem,
    isFavorite: Boolean,
    isOfflineAvailable: Boolean,
    lastReadPageIndex: Int?,
    onOpenClick: () -> Unit,
    onToggleFavorite: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("material_card_${material.fileId}")
            .clickable(onClick = onOpenClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, BpsOutlineSubtle),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            FileTypeBadge(fileType = material.fileType)

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.65f),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = material.category.shortLabel,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                    if (isOfflineAvailable) {
                        Surface(
                            color = BpsGreenContainer,
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.DownloadDone,
                                    contentDescription = "Tersimpan offline",
                                    tint = BpsGreenSuccess,
                                    modifier = Modifier.size(12.dp)
                                )
                                Spacer(modifier = Modifier.width(3.dp))
                                Text(
                                    text = "Offline",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = BpsGreenSuccess
                                )
                            }
                        }
                    }
                    if (lastReadPageIndex != null && material.fileType != MaterialFileType.VIDEO) {
                        Text(
                            text = "Hal. ${lastReadPageIndex + 1}",
                            style = MaterialTheme.typography.labelSmall,
                            color = BpsOrangeAccent
                        )
                    }
                }

                Spacer(modifier = Modifier.height(5.dp))

                Text(
                    text = material.title,
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )

                if (material.description.isNotBlank()) {
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = material.description,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(
                    onClick = onToggleFavorite,
                    modifier = Modifier.testTag("favorite_button_${material.fileId}")
                ) {
                    Icon(
                        imageVector = if (isFavorite) Icons.Filled.Star else Icons.Outlined.StarOutline,
                        contentDescription = stringResource(R.string.cd_favorite),
                        tint = if (isFavorite) BpsOrangeAccent else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                TextButton(
                    onClick = onOpenClick,
                    modifier = Modifier.testTag("open_material_button_${material.fileId}")
                ) {
                    Text(
                        text = stringResource(R.string.materials_open_action),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun SyncStatusBanner(
    syncState: CatalogSyncState,
    onSyncClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val (bg, fg, icon) = when (syncState.source) {
        SyncSource.PORTAL_SYNCED -> Triple(BpsGreenContainer, BpsGreenSuccess, Icons.Filled.CloudDone)
        SyncSource.LOCAL_FALLBACK_OFFLINE -> Triple(BpsOrangeContainer, BpsOrangeAccent, Icons.Filled.CloudOff)
        SyncSource.LOCAL_CATALOG_PORTAL_UNCONFIGURED -> Triple(
            MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f),
            BpsBluePrimary,
            Icons.Filled.Sync
        )
    }

    Surface(
        modifier = modifier.fillMaxWidth(),
        color = bg,
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (syncState.isSyncing) {
                CircularProgressIndicator(
                    modifier = Modifier.size(18.dp),
                    strokeWidth = 2.dp,
                    color = fg
                )
            } else {
                Icon(
                    imageVector = icon,
                    contentDescription = "Status sinkronisasi",
                    tint = fg,
                    modifier = Modifier.size(18.dp)
                )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = syncState.message,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.weight(1f)
            )
            TextButton(
                onClick = onSyncClick,
                enabled = !syncState.isSyncing,
                modifier = Modifier.testTag("sync_catalog_button")
            ) {
                Text(
                    text = "Segarkan",
                    style = MaterialTheme.typography.labelMedium,
                    color = fg,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun EmptyStateCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    modifier: Modifier = Modifier,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, BpsOutlineSubtle)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(28.dp)
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (actionLabel != null && onAction != null) {
                Spacer(modifier = Modifier.height(14.dp))
                OutlinedButton(onClick = onAction) {
                    Text(actionLabel)
                }
            }
        }
    }
}

@Composable
fun BpsCurvedWaveBanner(
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier.fillMaxWidth()) {
        val w = size.width
        val h = size.height

        val bluePath = Path().apply {
            moveTo(0f, 0f)
            lineTo(w, 0f)
            lineTo(w, h * 0.72f)
            cubicTo(w * 0.72f, h * 1.05f, w * 0.28f, h * 0.45f, 0f, h * 0.85f)
            close()
        }
        drawPath(
            path = bluePath,
            brush = Brush.linearGradient(
                colors = listOf(BpsBlueDark, BpsBluePrimary)
            )
        )

        val accentPath = Path().apply {
            moveTo(w * 0.52f, h * 0.78f)
            cubicTo(w * 0.74f, h * 0.96f, w * 0.88f, h * 0.82f, w, h * 0.68f)
            lineTo(w, h * 0.76f)
            cubicTo(w * 0.86f, h * 0.92f, w * 0.70f, h * 1.02f, w * 0.48f, h * 0.82f)
            close()
        }
        drawPath(
            path = accentPath,
            color = BpsOrangeAccent
        )
    }
}

@Composable
fun PortalUrlConfigDialog(
    currentUrl: String,
    errorMessage: String?,
    onSave: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var urlInput by remember(currentUrl) { mutableStateOf(currentUrl) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Konfigurasi Portal Apps Script",
                style = MaterialTheme.typography.titleLarge
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Masukkan URL Web App Google Apps Script yang terhubung ke spreadsheet DATABASE_PORTAL_SPKRT_2027 (ID: ${BuildConfig.PORTAL_SPREADSHEET_ID}).",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedTextField(
                    value = urlInput,
                    onValueChange = { urlInput = it },
                    label = { Text("URL Web App (HTTPS)") },
                    placeholder = { Text("https://script.google.com/macros/s/…/exec") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("portal_url_input")
                )
                if (!errorMessage.isNullOrBlank()) {
                    Text(
                        text = errorMessage,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error
                    )
                }
                Text(
                    text = "Tips bantuan login: Gunakan akun peserta yang terdaftar di sheet PENGGUNA/PESERTA. Jika lupa kata sandi, hubungi panitia pelatihan BPS Kabupaten Pinrang.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(urlInput) },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                modifier = Modifier.testTag("save_portal_url_button")
            ) {
                Text(stringResource(R.string.action_save))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.action_cancel))
            }
        }
    )
}
