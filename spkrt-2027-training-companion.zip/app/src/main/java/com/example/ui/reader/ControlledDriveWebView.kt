package com.example.ui.reader

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.view.View
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.ui.theme.BpsOrangeAccent
import com.example.ui.theme.BpsOutlineSubtle

private val ALLOWED_DRIVE_HOSTS = setOf(
    "drive.google.com",
    "docs.google.com",
    "accounts.google.com",
    "drive.usercontent.google.com",
    "script.google.com",
    "script.googleusercontent.com"
)

fun isAllowedDrivePreviewUri(uri: Uri?): Boolean {
    if (uri == null) return false
    if (!uri.scheme.equals("https", ignoreCase = true)) return false
    val host = uri.host?.lowercase() ?: return false
    return host in ALLOWED_DRIVE_HOSTS ||
        host.endsWith(".googleusercontent.com") ||
        host.endsWith(".google.com")
}

/**
 * Hardened in-app Google Drive Preview WebView with full Chromium renderer-crash protection.
 *
 * Reliability & Security safeguards:
 * - Implements `onRenderProcessGone` returning `true` so renderer process failures NEVER kill the app.
 * - Uses software layer fallback (`LAYER_TYPE_SOFTWARE`) to prevent GPU rendernode crashes on
 *   software-rendered devices/emulators and cleans up via `AndroidView.onRelease`.
 * - Strictly restricts navigation to HTTPS Google Drive/Docs allowlisted hosts.
 * - Disables local file/content access and mixed content.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun ControlledDriveWebView(
    previewUrl: String,
    modifier: Modifier = Modifier,
    preferSoftwareLayer: Boolean = true,
    onError: (String) -> Unit = {},
    onRendererCrashed: () -> Unit = {}
) {
    val context = LocalContext.current
    var progress by remember { mutableIntStateOf(0) }
    var isLoading by remember { mutableStateOf(true) }
    var rendererCrashed by remember(previewUrl) { mutableStateOf(false) }
    var reloadKey by remember(previewUrl) { mutableIntStateOf(0) }
    var forceSoftwareOnRetry by remember(previewUrl) { mutableStateOf(preferSoftwareLayer) }

    if (rendererCrashed) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, BpsOutlineSubtle),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Filled.WarningAmber,
                            contentDescription = null,
                            tint = BpsOrangeAccent,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Pratinjau Web Terhenti Sementara",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Text(
                        text = "Proses renderer pratinjau Google Drive mengalami gangguan grafis pada perangkat ini. Muat ulang dalam mode stabil atau buka di browser perangkat.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                forceSoftwareOnRetry = true
                                rendererCrashed = false
                                isLoading = true
                                progress = 0
                                reloadKey++
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Muat Ulang")
                        }
                        OutlinedButton(
                            onClick = {
                                val parsed = Uri.parse(previewUrl)
                                if (isAllowedDrivePreviewUri(parsed)) {
                                    runCatching {
                                        context.startActivity(Intent(Intent.ACTION_VIEW, parsed))
                                    }
                                }
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.AutoMirrored.Filled.OpenInNew, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Buka Drive")
                        }
                    }
                }
            }
        }
        return
    }

    Box(modifier = modifier) {
        key(previewUrl, reloadKey) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { ctx ->
                    WebView(ctx).apply {
                        if (forceSoftwareOnRetry) {
                            setLayerType(View.LAYER_TYPE_SOFTWARE, null)
                        }
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_BOUND, true)
                        }
                        settings.apply {
                            javaScriptEnabled = true
                            domStorageEnabled = true
                            builtInZoomControls = true
                            displayZoomControls = false
                            useWideViewPort = true
                            loadWithOverviewMode = true
                            allowFileAccess = false
                            allowContentAccess = false
                            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                            mediaPlaybackRequiresUserGesture = false
                            cacheMode = WebSettings.LOAD_DEFAULT
                        }
                        webChromeClient = object : WebChromeClient() {
                            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                                progress = newProgress
                                isLoading = newProgress < 100
                            }
                        }
                        webViewClient = object : WebViewClient() {
                            override fun shouldOverrideUrlLoading(
                                view: WebView?,
                                request: WebResourceRequest?
                            ): Boolean {
                                return !isAllowedDrivePreviewUri(request?.url)
                            }

                            override fun onReceivedError(
                                view: WebView?,
                                request: WebResourceRequest?,
                                error: WebResourceError?
                            ) {
                                if (request?.isForMainFrame == true) {
                                    onError(
                                        error?.description?.toString()
                                            ?: "Gagal memuat pratinjau Google Drive."
                                    )
                                }
                            }

                            override fun onRenderProcessGone(
                                view: WebView?,
                                detail: RenderProcessGoneDetail?
                            ): Boolean {
                                // Gracefully handle Chromium renderer crash so the app process is NOT killed
                                runCatching {
                                    view?.stopLoading()
                                    view?.destroy()
                                }
                                rendererCrashed = true
                                isLoading = false
                                onRendererCrashed()
                                return true
                            }
                        }
                        val parsed = Uri.parse(previewUrl)
                        if (isAllowedDrivePreviewUri(parsed)) {
                            loadUrl(previewUrl)
                        } else {
                            onError("URL pratinjau tidak valid atau tidak berasal dari Google Drive HTTPS.")
                        }
                    }
                },
                update = { webView ->
                    if (!rendererCrashed && webView.url != previewUrl) {
                        val parsed = Uri.parse(previewUrl)
                        if (isAllowedDrivePreviewUri(parsed)) {
                            webView.loadUrl(previewUrl)
                        }
                    }
                },
                onRelease = { webView ->
                    runCatching {
                        webView.stopLoading()
                        webView.onPause()
                        webView.removeAllViews()
                        webView.destroy()
                    }
                }
            )
        }

        if (isLoading) {
            LinearProgressIndicator(
                progress = { (progress / 100f).coerceIn(0.05f, 1f) },
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.TopCenter)
            )
        }
    }
}
