package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// BPS Kabupaten Pinrang Official Inspired Palette
val BpsBluePrimary = Color(0xFF0B5CAB)
val BpsBlueDark = Color(0xFF174A7E)
val BpsBlueDeep = Color(0xFF0A3461)
val BpsBlueContainer = Color(0xFFD6E8FA)
val BpsBlueSurfaceTint = Color(0xFFEAF3FC)

val BpsOrangeAccent = Color(0xFFF58220)
val BpsOrangeDark = Color(0xFFD96B0F)
val BpsOrangeContainer = Color(0xFFFFECD9)

val BpsGreenSuccess = Color(0xFF1E874B)
val BpsGreenContainer = Color(0xFFE1F5E9)

val BpsRedError = Color(0xFFC62828)
val BpsRedContainer = Color(0xFFFFE5E5)

val BpsBackground = Color(0xFFF4F7FB)
val BpsSurface = Color(0xFFFFFFFF)
val BpsSurfaceVariant = Color(0xFFE8EFF7)
val BpsOutline = Color(0xFFCBD5E1)
val BpsOutlineSubtle = Color(0xFFE2E8F0)

val BpsTextPrimary = Color(0xFF263445)
val BpsTextSecondary = Color(0xFF718096)

// File-Type Badge Semantic Colors
val BadgePdfRed = Color(0xFFD93025)
val BadgePdfContainer = Color(0xFFFDECEA)
val BadgeDocsBlue = Color(0xFF1A73E8)
val BadgeDocsContainer = Color(0xFFE8F0FE)
val BadgePptxOrange = Color(0xFFE37400)
val BadgePptxContainer = Color(0xFFFEF3E2)
val BadgeVideoRed = Color(0xFFD93025)
val BadgeVideoContainer = Color(0xFFFCE8E6)

// Search Highlight Colors
val PdfHighlightYellow = Color(0x88FFEB3B)
val PdfHighlightActiveOrange = Color(0xAAF58220)

// Dark Theme Companion Tokens (Accessible Navy)
val BpsDarkBackground = Color(0xFF0F1722)
val BpsDarkSurface = Color(0xFF182230)
val BpsDarkSurfaceVariant = Color(0xFF223044)
val BpsDarkPrimary = Color(0xFF6BB2FF)
val BpsDarkTextPrimary = Color(0xFFF1F5F9)
val BpsDarkTextSecondary = Color(0xFF94A3B8)
