package com.example.ui.video

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import androidx.activity.compose.BackHandler
import androidx.annotation.OptIn
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material.icons.outlined.StarOutline
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import com.example.R
import com.example.ui.reader.ControlledDriveWebView
import com.example.ui.theme.BpsBlueDark
import com.example.ui.theme.BpsBluePrimary
import com.example.ui.theme.BpsOrangeAccent
import com.example.ui.theme.BpsOrangeContainer
import com.example.ui.theme.BpsOutlineSubtle
import kotlinx.coroutines.delay
import okhttp3.OkHttpClient

private fun Context.findActivity(): Activity? {
    var ctx = this
    while (ctx is ContextWrapper) {
        if (ctx is Activity) return ctx
        ctx = ctx.baseContext
    }
    return null
}

@kotlin.OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VideoScreen(
    viewModel: VideoViewModel,
    okHttpClient: OkHttpClient,
    initialVideoId: String?,
    onClearInitialVideo: () -> Unit,
    onFullscreenChanged: (Boolean) -> Unit,
    contentBottomPadding: PaddingValues
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val activity = remember(context) { context.findActivity() }

    LaunchedEffect(initialVideoId) {
        if (!initialVideoId.isNullOrBlank()) {
            viewModel.selectVideoById(initialVideoId)
            onClearInitialVideo()
        }
    }

    LaunchedEffect(state.isFullscreen) {
        onFullscreenChanged(state.isFullscreen)
        activity?.requestedOrientation = if (state.isFullscreen) {
            ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        } else {
            ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            onFullscreenChanged(false)
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    BackHandler(enabled = state.isFullscreen) {
        viewModel.setFullscreen(false)
    }

    if (state.isFullscreen) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
                .statusBarsPadding()
        ) {
            VideoPlayerRegion(
                state = state,
                okHttpClient = okHttpClient,
                isFullscreen = true,
                onToggleFullscreen = { viewModel.setFullscreen(false) },
                onSaveProgress = viewModel::saveWatchProgress,
                onFallbackToDrive = viewModel::fallbackToDrivePreview,
                onRetry = viewModel::retryCurrentVideo,
                modifier = Modifier.fillMaxSize()
            )
        }
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = stringResource(R.string.video_title),
                            style = MaterialTheme.typography.titleLarge,
                            color = Color.White
                        )
                        Text(
                            text = "Media3 ExoPlayer • 4 Video Resmi SPKRT 2027",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White.copy(alpha = 0.85f)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BpsBluePrimary)
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = innerPadding.calculateTopPadding())
                .testTag("video_screen"),
            contentAlignment = Alignment.TopCenter
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 720.dp),
                contentPadding = PaddingValues(
                    start = 16.dp,
                    end = 16.dp,
                    top = 14.dp,
                    bottom = contentBottomPadding.calculateBottomPadding() + 24.dp
                ),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Video Player Container (16:9)
                item {
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.Black),
                        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        VideoPlayerRegion(
                            state = state,
                            okHttpClient = okHttpClient,
                            isFullscreen = false,
                            onToggleFullscreen = { viewModel.setFullscreen(true) },
                            onSaveProgress = viewModel::saveWatchProgress,
                            onFallbackToDrive = viewModel::fallbackToDrivePreview,
                            onRetry = viewModel::retryCurrentVideo,
                            modifier = Modifier
                                .fillMaxWidth()
                                .aspectRatio(16f / 9f)
                        )
                    }
                }

                // Active Video Info & Honest Stream Status
                state.selectedVideo?.let { activeVideo ->
                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                text = activeVideo.title,
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                            Text(
                                text = activeVideo.description,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            when (val ps = state.playerState) {
                                is VideoPlayerState.ReadyExoPlayer -> {
                                    Surface(
                                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text(
                                            text = ps.sourceLabel,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                                        )
                                    }
                                }
                                is VideoPlayerState.DriveEmbedFallback -> {
                                    Surface(
                                        color = BpsOrangeContainer,
                                        shape = RoundedCornerShape(10.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(10.dp),
                                            verticalAlignment = Alignment.Top
                                        ) {
                                            Icon(
                                                imageVector = Icons.Filled.Info,
                                                contentDescription = null,
                                                tint = BpsOrangeAccent,
                                                modifier = Modifier.size(16.dp)
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(
                                                text = ps.reason,
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                        }
                                    }
                                }
                                else -> Unit
                            }
                        }
                    }
                }

                // Playlist header
                item {
                    Text(
                        text = stringResource(R.string.video_playlist_header),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }

                items(state.videos, key = { it.id }) { video ->
                    val isSelected = state.selectedVideo?.id == video.id
                    val prog = state.progressByMaterialId[video.id]
                    val isFav = video.id in state.favoriteIds

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("video_item_${video.fileId}")
                            .clickable { viewModel.selectVideo(video) },
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) {
                                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
                            } else {
                                MaterialTheme.colorScheme.surface
                            }
                        ),
                        border = BorderStroke(
                            width = if (isSelected) 1.5.dp else 1.dp,
                            color = if (isSelected) BpsBluePrimary else BpsOutlineSubtle
                        )
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(44.dp)
                                        .clip(CircleShape)
                                        .background(if (isSelected) BpsBluePrimary else BpsBlueDark.copy(alpha = 0.12f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.PlayArrow,
                                        contentDescription = "Putar ${video.title}",
                                        tint = if (isSelected) Color.White else BpsBluePrimary
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = video.title,
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = if (isSelected) "Sedang dipilih" else "Drive ID: ${video.fileId.take(14)}…",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = if (isSelected) BpsBluePrimary else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                IconButton(onClick = { viewModel.toggleFavorite(video.id) }) {
                                    Icon(
                                        imageVector = if (isFav) Icons.Filled.Star else Icons.Outlined.StarOutline,
                                        contentDescription = stringResource(R.string.cd_favorite),
                                        tint = if (isFav) BpsOrangeAccent else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            if (prog != null && prog.durationMs > 0L) {
                                Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                    LinearProgressIndicator(
                                        progress = { prog.progressFraction },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(4.dp)
                                            .clip(RoundedCornerShape(4.dp)),
                                        color = BpsOrangeAccent
                                    )
                                    Text(
                                        text = "Terakhir ditonton: ${formatMillis(prog.positionMs)} / ${formatMillis(prog.durationMs)}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(UnstableApi::class)
@Composable
private fun VideoPlayerRegion(
    state: VideoScreenUiState,
    okHttpClient: OkHttpClient,
    isFullscreen: Boolean,
    onToggleFullscreen: () -> Unit,
    onSaveProgress: (Long, Long) -> Unit,
    onFallbackToDrive: (String) -> Unit,
    onRetry: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier.background(Color.Black),
        contentAlignment = Alignment.Center
    ) {
        when (val ps = state.playerState) {
            is VideoPlayerState.Idle,
            is VideoPlayerState.Resolving -> {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.padding(16.dp)
                ) {
                    CircularProgressIndicator(color = BpsOrangeAccent)
                    Text(
                        text = "Memeriksa izin & stream video Google Drive…",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White
                    )
                }
            }

            is VideoPlayerState.ReadyExoPlayer -> {
                ExoPlayerSurface(
                    streamUrl = ps.streamUrl,
                    startPositionMs = ps.startPositionMs,
                    okHttpClient = okHttpClient,
                    isFullscreen = isFullscreen,
                    onToggleFullscreen = onToggleFullscreen,
                    onSaveProgress = onSaveProgress,
                    onPlaybackFailed = onFallbackToDrive,
                    modifier = Modifier.fillMaxSize()
                )
            }

            is VideoPlayerState.DriveEmbedFallback -> {
                Box(modifier = Modifier.fillMaxSize()) {
                    ControlledDriveWebView(
                        previewUrl = ps.previewUrl,
                        preferSoftwareLayer = true,
                        modifier = Modifier.fillMaxSize()
                    )
                    IconButton(
                        onClick = onToggleFullscreen,
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(8.dp)
                            .clip(CircleShape)
                            .background(Color.Black.copy(alpha = 0.55f))
                    ) {
                        Icon(
                            imageVector = if (isFullscreen) Icons.Filled.FullscreenExit else Icons.Filled.Fullscreen,
                            contentDescription = "Mode layar penuh",
                            tint = Color.White
                        )
                    }
                }
            }

            is VideoPlayerState.Error -> {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.padding(16.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.WarningAmber,
                        contentDescription = null,
                        tint = BpsOrangeAccent,
                        modifier = Modifier.size(32.dp)
                    )
                    Text(
                        text = ps.message,
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = onRetry) {
                            Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(stringResource(R.string.action_retry))
                        }
                        OutlinedButton(
                            onClick = {
                                onFallbackToDrive("Memuat pemutar pratinjau Google Drive sebagai alternatif.")
                            }
                        ) {
                            Text("Pratinjau Drive", color = Color.White)
                        }
                    }
                }
            }
        }
    }
}

@OptIn(UnstableApi::class)
@Composable
private fun ExoPlayerSurface(
    streamUrl: String,
    startPositionMs: Long,
    okHttpClient: OkHttpClient,
    isFullscreen: Boolean,
    onToggleFullscreen: () -> Unit,
    onSaveProgress: (Long, Long) -> Unit,
    onPlaybackFailed: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var isBuffering by remember { mutableStateOf(true) }
    var isSlowNetwork by remember { mutableStateOf(false) }
    var volume by remember { mutableFloatStateOf(1f) }
    var isMuted by remember { mutableStateOf(false) }

    val exoPlayer = remember(streamUrl) {
        val dataSourceFactory = OkHttpDataSource.Factory(okHttpClient)
        ExoPlayer.Builder(context)
            .setMediaSourceFactory(DefaultMediaSourceFactory(dataSourceFactory))
            .build()
            .apply {
                setMediaItem(MediaItem.fromUri(streamUrl))
                prepare()
                if (startPositionMs > 0L) {
                    seekTo(startPositionMs)
                }
                playWhenReady = true
            }
    }

    DisposableEffect(exoPlayer) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                isBuffering = playbackState == Player.STATE_BUFFERING
                if (playbackState == Player.STATE_READY) {
                    isSlowNetwork = false
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                onPlaybackFailed(
                    "ExoPlayer tidak dapat memutar stream langsung (${error.errorCodeName}). " +
                        "Beralih ke pemutar pratinjau Google Drive terintegrasi."
                )
            }
        }
        exoPlayer.addListener(listener)
        onDispose {
            onSaveProgress(exoPlayer.currentPosition, exoPlayer.duration)
            exoPlayer.removeListener(listener)
            exoPlayer.release()
        }
    }

    // Periodically persist watch progress & detect slow buffering
    LaunchedEffect(exoPlayer, isBuffering) {
        var bufferingTicks = 0
        while (true) {
            delay(2_000L)
            if (exoPlayer.duration > 0L) {
                onSaveProgress(exoPlayer.currentPosition, exoPlayer.duration)
            }
            if (isBuffering) {
                bufferingTicks++
                if (bufferingTicks >= 3) isSlowNetwork = true
            } else {
                bufferingTicks = 0
                isSlowNetwork = false
            }
        }
    }

    LaunchedEffect(volume, isMuted) {
        exoPlayer.volume = if (isMuted) 0f else volume
    }

    Box(modifier = modifier) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                PlayerView(ctx).apply {
                    player = exoPlayer
                    useController = true
                    setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
                }
            },
            update = { view ->
                if (view.player != exoPlayer) {
                    view.player = exoPlayer
                }
            }
        )

        // Volume & Fullscreen overlay bar at top right
        Row(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(8.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(Color.Black.copy(alpha = 0.55f))
                .padding(horizontal = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = { isMuted = !isMuted },
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    imageVector = if (isMuted || volume == 0f) Icons.AutoMirrored.Filled.VolumeOff else Icons.AutoMirrored.Filled.VolumeUp,
                    contentDescription = "Pengaturan volume",
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
            }
            Slider(
                value = if (isMuted) 0f else volume,
                onValueChange = {
                    isMuted = false
                    volume = it
                },
                colors = SliderDefaults.colors(
                    thumbColor = BpsOrangeAccent,
                    activeTrackColor = BpsOrangeAccent
                ),
                modifier = Modifier.width(72.dp)
            )
            IconButton(
                onClick = onToggleFullscreen,
                modifier = Modifier
                    .size(36.dp)
                    .testTag("video_fullscreen_button")
            ) {
                Icon(
                    imageVector = if (isFullscreen) Icons.Filled.FullscreenExit else Icons.Filled.Fullscreen,
                    contentDescription = "Layar penuh",
                    tint = Color.White,
                    modifier = Modifier.size(20.dp)
                )
            }
        }

        if (isSlowNetwork) {
            Surface(
                color = Color.Black.copy(alpha = 0.78f),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(10.dp)
            ) {
                Text(
                    text = "Koneksi lambat terdeteksi… sedang buffering",
                    style = MaterialTheme.typography.labelSmall,
                    color = BpsOrangeAccent,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                )
            }
        }
    }
}

private fun formatMillis(ms: Long): String {
    val totalSeconds = (ms / 1000L).coerceAtLeast(0L)
    val minutes = totalSeconds / 60L
    val seconds = totalSeconds % 60L
    return "%02d:%02d".format(minutes, seconds)
}
