package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val SpkrtLightColorScheme = lightColorScheme(
    primary = BpsBluePrimary,
    onPrimary = Color.White,
    primaryContainer = BpsBlueContainer,
    onPrimaryContainer = BpsBlueDeep,
    secondary = BpsOrangeAccent,
    onSecondary = Color.White,
    secondaryContainer = BpsOrangeContainer,
    onSecondaryContainer = Color(0xFF5A2B00),
    tertiary = BpsBlueDark,
    onTertiary = Color.White,
    tertiaryContainer = BpsBlueSurfaceTint,
    onTertiaryContainer = BpsBlueDeep,
    background = BpsBackground,
    onBackground = BpsTextPrimary,
    surface = BpsSurface,
    onSurface = BpsTextPrimary,
    surfaceVariant = BpsSurfaceVariant,
    onSurfaceVariant = BpsTextSecondary,
    outline = BpsOutline,
    outlineVariant = BpsOutlineSubtle,
    error = BpsRedError,
    onError = Color.White,
    errorContainer = BpsRedContainer,
    onErrorContainer = Color(0xFF7F1D1D)
)

private val SpkrtDarkColorScheme = darkColorScheme(
    primary = BpsDarkPrimary,
    onPrimary = BpsBlueDeep,
    primaryContainer = BpsBlueDark,
    onPrimaryContainer = Color.White,
    secondary = BpsOrangeAccent,
    onSecondary = Color.Black,
    secondaryContainer = Color(0xFF5C3107),
    onSecondaryContainer = BpsOrangeContainer,
    tertiary = Color(0xFF93C5FD),
    onTertiary = BpsBlueDeep,
    background = BpsDarkBackground,
    onBackground = BpsDarkTextPrimary,
    surface = BpsDarkSurface,
    onSurface = BpsDarkTextPrimary,
    surfaceVariant = BpsDarkSurfaceVariant,
    onSurfaceVariant = BpsDarkTextSecondary,
    outline = Color(0xFF3B4C63),
    outlineVariant = Color(0xFF28364A),
    error = Color(0xFFF87171),
    onError = Color(0xFF450A0A)
)

val SpkrtShapes = Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun SpkrtTheme(
    darkTheme: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) SpkrtDarkColorScheme else SpkrtLightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = SpkrtTypography,
        shapes = SpkrtShapes,
        content = content
    )
}
