package com.example.ui.materials

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Sort
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SearchOff
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.domain.model.MaterialCategory
import com.example.domain.model.MaterialFileType
import com.example.domain.model.MaterialItem
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.MaterialItemCard
import com.example.ui.theme.BpsBluePrimary
import com.example.ui.theme.BpsOrangeAccent

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MaterialsScreen(
    viewModel: MaterialsViewModel,
    initialCategoryFilter: MaterialCategory?,
    onClearInitialCategory: () -> Unit,
    onOpenMaterial: (MaterialItem) -> Unit,
    contentBottomPadding: PaddingValues
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    LaunchedEffect(initialCategoryFilter) {
        if (initialCategoryFilter != null) {
            viewModel.selectCategory(initialCategoryFilter)
            onClearInitialCategory()
        }
    }

    val documentCategories = listOf(
        MaterialCategory.BUKU_PEDOMAN,
        MaterialCategory.KUESIONER,
        MaterialCategory.BAHAN_AJAR,
        MaterialCategory.PENEGASAN
    )

    val fileTypes = listOf(
        MaterialFileType.PDF,
        MaterialFileType.DOCS,
        MaterialFileType.PPTX,
        MaterialFileType.VIDEO
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = stringResource(R.string.materials_title),
                            style = MaterialTheme.typography.titleLarge,
                            color = Color.White
                        )
                        Text(
                            text = "${state.filteredMaterials.size} materi ditampilkan",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White.copy(alpha = 0.85f)
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = viewModel::toggleSortOrder,
                        modifier = Modifier.testTag("materials_sort_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Sort,
                            contentDescription = "Ubah urutan materi",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = BpsBluePrimary
                )
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = innerPadding.calculateTopPadding())
                .testTag("materials_screen"),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 720.dp)
            ) {
                // Sticky Search & Filter Panel
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    shadowElevation = 2.dp
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = state.searchQuery,
                            onValueChange = viewModel::onSearchQueryChange,
                            placeholder = { Text(stringResource(R.string.materials_search_placeholder)) },
                            leadingIcon = {
                                Icon(Icons.Filled.Search, contentDescription = stringResource(R.string.cd_search))
                            },
                            trailingIcon = {
                                if (state.searchQuery.isNotEmpty()) {
                                    IconButton(
                                        onClick = { viewModel.onSearchQueryChange("") },
                                        modifier = Modifier.testTag("clear_search_button")
                                    ) {
                                        Icon(Icons.Filled.Close, contentDescription = "Hapus pencarian")
                                    }
                                }
                            },
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                unfocusedContainerColor = MaterialTheme.colorScheme.background,
                                focusedContainerColor = MaterialTheme.colorScheme.surface
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("materials_search_input")
                        )

                        // Category filter row
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            item {
                                FilterChip(
                                    selected = state.selectedCategory == null,
                                    onClick = { viewModel.selectCategory(null) },
                                    label = { Text(stringResource(R.string.cat_all)) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = BpsBluePrimary,
                                        selectedLabelColor = Color.White
                                    ),
                                    modifier = Modifier.testTag("filter_cat_all")
                                )
                            }
                            items(documentCategories) { cat ->
                                FilterChip(
                                    selected = state.selectedCategory == cat,
                                    onClick = {
                                        viewModel.selectCategory(
                                            if (state.selectedCategory == cat) null else cat
                                        )
                                    },
                                    label = { Text(cat.label) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = BpsBluePrimary,
                                        selectedLabelColor = Color.White
                                    ),
                                    modifier = Modifier.testTag("filter_cat_${cat.name.lowercase()}")
                                )
                            }
                        }

                        // File type filter + active sort badge
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            LazyRow(
                                modifier = Modifier.weight(1f),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                item {
                                    FilterChip(
                                        selected = state.selectedFileType == null,
                                        onClick = { viewModel.selectFileType(null) },
                                        label = { Text("Semua Tipe", style = MaterialTheme.typography.labelSmall) },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = BpsOrangeAccent,
                                            selectedLabelColor = Color.White
                                        )
                                    )
                                }
                                items(fileTypes) { type ->
                                    FilterChip(
                                        selected = state.selectedFileType == type,
                                        onClick = {
                                            viewModel.selectFileType(
                                                if (state.selectedFileType == type) null else type
                                            )
                                        },
                                        label = { Text(type.badgeLabel, style = MaterialTheme.typography.labelSmall) },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = BpsOrangeAccent,
                                            selectedLabelColor = Color.White
                                        ),
                                        modifier = Modifier.testTag("filter_type_${type.name.lowercase()}")
                                    )
                                }
                            }
                        }

                        Text(
                            text = "Urutan: ${state.sortOrder.label}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                // Materials LazyColumn
                if (state.filteredMaterials.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp)
                    ) {
                        EmptyStateCard(
                            icon = Icons.Filled.SearchOff,
                            title = stringResource(R.string.materials_empty_title),
                            subtitle = stringResource(R.string.materials_empty_subtitle),
                            actionLabel = "Reset Filter",
                            onAction = viewModel::resetFilters
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(
                            start = 16.dp,
                            end = 16.dp,
                            top = 12.dp,
                            bottom = contentBottomPadding.calculateBottomPadding() + 24.dp
                        ),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(state.filteredMaterials, key = { it.id }) { item ->
                            MaterialItemCard(
                                material = item,
                                isFavorite = item.id in state.favoriteIds,
                                isOfflineAvailable = item.fileId in state.offlineFileIds,
                                lastReadPageIndex = state.lastReadPages[item.id],
                                onOpenClick = { onOpenMaterial(item) },
                                onToggleFavorite = { viewModel.toggleFavorite(item.id) }
                            )
                        }
                        item { Spacer(modifier = Modifier.height(8.dp)) }
                    }
                }
            }
        }
    }
}
