package com.example.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.auth.AuthRepository
import com.example.data.repository.MaterialRepository
import com.example.domain.model.CatalogSyncState
import com.example.domain.model.MaterialCategory
import com.example.domain.model.MaterialItem
import com.example.domain.model.UserSession
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class HomeUiState(
    val userSession: UserSession? = null,
    val syncState: CatalogSyncState = CatalogSyncState(),
    val categoryCounts: Map<MaterialCategory, Int> = emptyMap(),
    val totalMaterials: Int = 32,
    val recentMaterials: List<MaterialItem> = emptyList(),
    val favoriteMaterials: List<MaterialItem> = emptyList(),
    val favoriteIds: Set<String> = emptySet(),
    val lastReadPages: Map<String, Int> = emptyMap(),
    val offlineFileIds: Set<String> = emptySet()
)

class HomeViewModel(
    private val authRepository: AuthRepository,
    private val materialRepository: MaterialRepository
) : ViewModel() {

    val uiState: StateFlow<HomeUiState> = combine<Any?, HomeUiState>(
        authRepository.sessionFlow,
        materialRepository.syncState,
        materialRepository.materialsFlow,
        materialRepository.recentEntriesFlow,
        materialRepository.favoriteIdsFlow,
        materialRepository.lastReadPagesFlow,
        materialRepository.offlineFileIdsFlow
    ) { values ->
        val session = values[0] as UserSession?
        val syncState = values[1] as CatalogSyncState
        @Suppress("UNCHECKED_CAST")
        val materials = values[2] as List<MaterialItem>
        @Suppress("UNCHECKED_CAST")
        val recents = values[3] as List<com.example.domain.model.RecentMaterialEntry>
        @Suppress("UNCHECKED_CAST")
        val favIds = values[4] as Set<String>
        @Suppress("UNCHECKED_CAST")
        val lastPages = values[5] as Map<String, Int>
        @Suppress("UNCHECKED_CAST")
        val offlineIds = values[6] as Set<String>

        val byId = materials.associateBy { it.id }
        val counts = MaterialCategory.entries.associateWith { cat ->
            materials.count { it.category == cat }
        }

        HomeUiState(
            userSession = session,
            syncState = syncState,
            categoryCounts = counts,
            totalMaterials = materials.size,
            recentMaterials = recents.mapNotNull { byId[it.materialId] }.take(4),
            favoriteMaterials = materials.filter { it.id in favIds }.take(6),
            favoriteIds = favIds,
            lastReadPages = lastPages,
            offlineFileIds = offlineIds
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = HomeUiState()
    )

    init {
        syncCatalog()
    }

    fun syncCatalog() {
        viewModelScope.launch {
            materialRepository.syncCatalogFromPortal()
        }
    }

    fun toggleFavorite(materialId: String) {
        viewModelScope.launch {
            materialRepository.toggleFavorite(materialId)
        }
    }

    class Factory(
        private val authRepository: AuthRepository,
        private val materialRepository: MaterialRepository
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return HomeViewModel(authRepository, materialRepository) as T
        }
    }
}
