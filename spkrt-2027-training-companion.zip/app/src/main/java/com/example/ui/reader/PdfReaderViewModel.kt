package com.example.ui.reader

import android.graphics.Bitmap
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.auth.AuthRepository
import com.example.data.repository.MaterialRepository
import com.example.domain.model.MaterialItem
import com.example.domain.model.PageBookmark
import com.example.network.DriveFetchResult
import com.example.network.DriveFileFetcher
import com.example.reader.PdfDocumentEngine
import com.example.reader.PdfSearchMatch
import com.example.storage.OfflineFileManager
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

sealed class PdfLoadState {
    data class Downloading(val progress: Float, val statusText: String) : PdfLoadState()
    data object Ready : PdfLoadState()
    data class AccessRestricted(
        val fileId: String,
        val title: String,
        val reason: String,
        val previewUrl: String
    ) : PdfLoadState()
    data class Error(val message: String) : PdfLoadState()
}

data class PdfReaderUiState(
    val material: MaterialItem? = null,
    val loadState: PdfLoadState = PdfLoadState.Downloading(0f, "Menyiapkan dokumen…"),
    val currentPage: Int = 0,
    val pageCount: Int = 0,
    val renderedBitmap: Bitmap? = null,
    val isRenderingPage: Boolean = false,
    val zoomScale: Float = 1f,
    val isSearchBarVisible: Boolean = false,
    val searchQuery: String = "",
    val isSearching: Boolean = false,
    val indexingProgressText: String? = null,
    val searchMatches: List<PdfSearchMatch> = emptyList(),
    val activeMatchIndex: Int = -1,
    val isScannedWithoutTextLayer: Boolean = false,
    val isOfflineSaved: Boolean = false,
    val isSavingOffline: Boolean = false,
    val isFavorite: Boolean = false,
    val bookmarksForDocument: List<PageBookmark> = emptyList(),
    val useDrivePreviewFallback: Boolean = false,
    val snackbarMessage: String? = null
) {
    val currentPageMatches: List<PdfSearchMatch>
        get() = searchMatches.filter { it.pageIndex == currentPage }

    val activeMatch: PdfSearchMatch?
        get() = searchMatches.getOrNull(activeMatchIndex)

    val isCurrentPageBookmarked: Boolean
        get() = bookmarksForDocument.any { it.pageIndex == currentPage }
}

class PdfReaderViewModel(
    private val materialId: String,
    private val initialPageArg: Int,
    private val materialRepository: MaterialRepository,
    private val authRepository: AuthRepository,
    private val driveFileFetcher: DriveFileFetcher,
    private val offlineFileManager: OfflineFileManager
) : ViewModel() {

    private val engine = PdfDocumentEngine()
    private val _uiState = MutableStateFlow(PdfReaderUiState())
    val uiState: StateFlow<PdfReaderUiState> = _uiState.asStateFlow()

    private var searchJob: Job? = null
    private var renderJob: Job? = null
    private var currentRenderBaseWidthPx: Int = 1080

    init {
        observePreferences()
        loadDocument()
    }

    private fun observePreferences() {
        viewModelScope.launch {
            materialRepository.favoriteIdsFlow.collect { favs ->
                _uiState.update { it.copy(isFavorite = materialId in favs) }
            }
        }
        viewModelScope.launch {
            materialRepository.bookmarksFlow.collect { allBookmarks ->
                val forDoc = allBookmarks
                    .filter { it.materialId == materialId }
                    .sortedBy { it.pageIndex }
                _uiState.update { it.copy(bookmarksForDocument = forDoc) }
            }
        }
        viewModelScope.launch {
            materialRepository.offlineFileIdsFlow.collect { offlineIds ->
                val mat = _uiState.value.material
                if (mat != null) {
                    _uiState.update { it.copy(isOfflineSaved = mat.fileId in offlineIds) }
                }
            }
        }
    }

    fun loadDocument(forceRetry: Boolean = false) {
        viewModelScope.launch {
            val material = materialRepository.getMaterialById(materialId)
            if (material == null) {
                _uiState.update {
                    it.copy(loadState = PdfLoadState.Error("Materi tidak ditemukan di katalog."))
                }
                return@launch
            }

            materialRepository.recordMaterialOpened(material.id)
            _uiState.update {
                it.copy(
                    material = material,
                    useDrivePreviewFallback = false,
                    loadState = PdfLoadState.Downloading(
                        0.05f,
                        if (material.fileType == com.example.domain.model.MaterialFileType.DOCS) {
                            "Mengekspor Google Docs ke PDF untuk pencarian teks…"
                        } else {
                            "Mengunduh dokumen PDF dari Google Drive…"
                        }
                    )
                )
            }

            val portalUrl = authRepository.getPortalUrl()
            val token = authRepository.getCurrentSession()?.token.orEmpty()

            when (
                val result = driveFileFetcher.fetchDocumentFile(
                    material = material,
                    portalBaseUrl = portalUrl,
                    sessionToken = token,
                    saveForOffline = false,
                    onProgress = { prog ->
                        _uiState.update { state ->
                            if (state.loadState is PdfLoadState.Downloading) {
                                state.copy(
                                    loadState = PdfLoadState.Downloading(
                                        progress = prog,
                                        statusText = "Mengunduh dokumen (${(prog * 100).toInt()}%)…"
                                    )
                                )
                            } else state
                        }
                    }
                )
            ) {
                is DriveFetchResult.Success -> {
                    runCatching {
                        val summary = engine.open(result.file)
                        val savedLastPage = materialRepository.lastReadPagesFlow.first()[material.id] ?: 0
                        val startPage = when {
                            initialPageArg >= 0 -> initialPageArg
                            else -> savedLastPage
                        }.coerceIn(0, (summary.pageCount - 1).coerceAtLeast(0))

                        _uiState.update {
                            it.copy(
                                loadState = PdfLoadState.Ready,
                                pageCount = summary.pageCount,
                                currentPage = startPage,
                                isOfflineSaved = result.isOfflineSaved ||
                                    (material.fileId in offlineFileManager.offlineFileIds.value)
                            )
                        }
                        renderPageAt(startPage)
                        // Background-index text layer so search is instant & scanned PDFs are detected
                        preIndexTextInBackground()
                    }.onFailure { err ->
                        _uiState.update {
                            it.copy(
                                loadState = PdfLoadState.Error(
                                    "Gagal membuka berkas PDF: ${err.localizedMessage ?: "Format rusak"}"
                                )
                            )
                        }
                    }
                }
                is DriveFetchResult.AccessDenied -> {
                    _uiState.update {
                        it.copy(
                            loadState = PdfLoadState.AccessRestricted(
                                fileId = result.fileId,
                                title = result.title,
                                reason = result.reason,
                                previewUrl = result.previewUrl
                            )
                        )
                    }
                }
                is DriveFetchResult.NetworkError -> {
                    _uiState.update {
                        it.copy(loadState = PdfLoadState.Error(result.message))
                    }
                }
            }
        }
    }

    private fun preIndexTextInBackground() {
        viewModelScope.launch {
            val isScanned = engine.ensureTextIndexed { done, total ->
                if (_uiState.value.isSearchBarVisible) {
                    _uiState.update {
                        it.copy(indexingProgressText = "Mengindeks teks halaman $done/$total…")
                    }
                }
            }
            _uiState.update {
                it.copy(
                    isScannedWithoutTextLayer = isScanned,
                    indexingProgressText = null
                )
            }
        }
    }

    fun updateViewportWidth(widthPx: Int) {
        if (widthPx > 300 && kotlin.math.abs(widthPx - currentRenderBaseWidthPx) > 120) {
            currentRenderBaseWidthPx = widthPx
            if (_uiState.value.loadState is PdfLoadState.Ready) {
                renderPageAt(_uiState.value.currentPage)
            }
        }
    }

    fun goToPage(targetPageIndex: Int) {
        val total = _uiState.value.pageCount
        if (total <= 0) return
        val clamped = targetPageIndex.coerceIn(0, total - 1)
        _uiState.update { it.copy(currentPage = clamped) }
        renderPageAt(clamped)
        viewModelScope.launch {
            materialRepository.saveLastReadPage(materialId, clamped)
        }
    }

    fun nextPage() = goToPage(_uiState.value.currentPage + 1)
    fun previousPage() = goToPage(_uiState.value.currentPage - 1)

    fun zoomIn() {
        val next = (_uiState.value.zoomScale + 0.35f).coerceAtMost(3.0f)
        _uiState.update { it.copy(zoomScale = next) }
        renderPageAt(_uiState.value.currentPage)
    }

    fun zoomOut() {
        val next = (_uiState.value.zoomScale - 0.35f).coerceAtLeast(1.0f)
        _uiState.update { it.copy(zoomScale = next) }
        renderPageAt(_uiState.value.currentPage)
    }

    fun fitToWidth() {
        _uiState.update { it.copy(zoomScale = 1.0f) }
        renderPageAt(_uiState.value.currentPage)
    }

    fun setZoomScale(scale: Float) {
        val clamped = scale.coerceIn(1.0f, 3.0f)
        _uiState.update { it.copy(zoomScale = clamped) }
    }

    private fun renderPageAt(pageIndex: Int) {
        renderJob?.cancel()
        renderJob = viewModelScope.launch {
            _uiState.update { it.copy(isRenderingPage = true) }
            val renderWidth = (currentRenderBaseWidthPx * _uiState.value.zoomScale.coerceAtMost(2.2f)).toInt()
            val bmp = engine.renderPage(pageIndex, renderWidth)
            _uiState.update {
                it.copy(
                    renderedBitmap = bmp,
                    isRenderingPage = false
                )
            }
        }
    }

    fun toggleSearchBar() {
        _uiState.update { state ->
            val nextVisible = !state.isSearchBarVisible
            if (!nextVisible) {
                state.copy(
                    isSearchBarVisible = false,
                    searchQuery = "",
                    searchMatches = emptyList(),
                    activeMatchIndex = -1,
                    isSearching = false
                )
            } else {
                state.copy(isSearchBarVisible = true)
            }
        }
    }

    fun onSearchQueryChange(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
        if (query.isBlank()) {
            searchJob?.cancel()
            _uiState.update {
                it.copy(searchMatches = emptyList(), activeMatchIndex = -1, isSearching = false)
            }
        }
    }

    fun executeSearch() {
        val query = _uiState.value.searchQuery.trim()
        if (query.isEmpty()) return

        searchJob?.cancel()
        searchJob = viewModelScope.launch {
            _uiState.update { it.copy(isSearching = true, indexingProgressText = "Mencari \"$query\"…") }
            val (matches, isScanned) = engine.search(query)
            val firstIdx = if (matches.isNotEmpty()) 0 else -1
            _uiState.update {
                it.copy(
                    isSearching = false,
                    indexingProgressText = null,
                    isScannedWithoutTextLayer = isScanned,
                    searchMatches = matches,
                    activeMatchIndex = firstIdx
                )
            }
            if (matches.isNotEmpty()) {
                goToPage(matches[0].pageIndex)
            }
        }
    }

    fun nextSearchMatch() {
        val matches = _uiState.value.searchMatches
        if (matches.isEmpty()) return
        val nextIdx = (_uiState.value.activeMatchIndex + 1) % matches.size
        _uiState.update { it.copy(activeMatchIndex = nextIdx) }
        goToPage(matches[nextIdx].pageIndex)
    }

    fun previousSearchMatch() {
        val matches = _uiState.value.searchMatches
        if (matches.isEmpty()) return
        val prevIdx = if (_uiState.value.activeMatchIndex <= 0) matches.lastIndex else _uiState.value.activeMatchIndex - 1
        _uiState.update { it.copy(activeMatchIndex = prevIdx) }
        goToPage(matches[prevIdx].pageIndex)
    }

    fun toggleCurrentPageBookmark() {
        val mat = _uiState.value.material ?: return
        val page = _uiState.value.currentPage
        viewModelScope.launch {
            val added = materialRepository.toggleBookmark(mat.id, mat.title, page)
            _uiState.update {
                it.copy(
                    snackbarMessage = if (added) {
                        "Halaman ${page + 1} ditambahkan ke bookmark."
                    } else {
                        "Bookmark halaman ${page + 1} dihapus."
                    }
                )
            }
        }
    }

    fun toggleFavorite() {
        viewModelScope.launch {
            materialRepository.toggleFavorite(materialId)
        }
    }

    fun toggleOfflineSave() {
        val mat = _uiState.value.material ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isSavingOffline = true) }
            if (_uiState.value.isOfflineSaved) {
                offlineFileManager.deleteOfflineFile(mat.fileId, "pdf")
                _uiState.update {
                    it.copy(
                        isSavingOffline = false,
                        isOfflineSaved = false,
                        snackbarMessage = "Salinan offline dihapus dari perangkat."
                    )
                }
            } else {
                val promoted = offlineFileManager.promoteCacheToOffline(mat.fileId, "pdf")
                if (promoted) {
                    _uiState.update {
                        it.copy(
                            isSavingOffline = false,
                            isOfflineSaved = true,
                            snackbarMessage = "PDF tersimpan untuk dibaca offline."
                        )
                    }
                } else {
                    val portalUrl = authRepository.getPortalUrl()
                    val token = authRepository.getCurrentSession()?.token.orEmpty()
                    val res = driveFileFetcher.fetchDocumentFile(
                        material = mat,
                        portalBaseUrl = portalUrl,
                        sessionToken = token,
                        saveForOffline = true
                    )
                    val ok = res is DriveFetchResult.Success
                    _uiState.update {
                        it.copy(
                            isSavingOffline = false,
                            isOfflineSaved = ok,
                            snackbarMessage = if (ok) {
                                "PDF berhasil diunduh untuk baca offline."
                            } else {
                                "Gagal menyimpan offline. Pastikan dokumen dapat diakses."
                            }
                        )
                    }
                }
            }
        }
    }

    fun switchToDrivePreviewFallback() {
        _uiState.update { it.copy(useDrivePreviewFallback = true) }
    }

    fun clearSnackbar() {
        _uiState.update { it.copy(snackbarMessage = null) }
    }

    override fun onCleared() {
        super.onCleared()
        viewModelScope.launch { engine.close() }
    }

    class Factory(
        private val materialId: String,
        private val initialPageArg: Int,
        private val materialRepository: MaterialRepository,
        private val authRepository: AuthRepository,
        private val driveFileFetcher: DriveFileFetcher,
        private val offlineFileManager: OfflineFileManager
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return PdfReaderViewModel(
                materialId = materialId,
                initialPageArg = initialPageArg,
                materialRepository = materialRepository,
                authRepository = authRepository,
                driveFileFetcher = driveFileFetcher,
                offlineFileManager = offlineFileManager
            ) as T
        }
    }
}
