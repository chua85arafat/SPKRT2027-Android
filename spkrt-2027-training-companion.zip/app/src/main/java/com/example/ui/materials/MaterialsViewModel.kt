package com.example.ui.materials

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.repository.MaterialRepository
import com.example.domain.model.MaterialCategory
import com.example.domain.model.MaterialFileType
import com.example.domain.model.MaterialItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class MaterialSortOrder(val label: String) {
    DISPLAY_ORDER("Urutan Materi"),
    TITLE_ASC("Judul A-Z")
}

data class MaterialsUiState(
    val searchQuery: String = "",
    val selectedCategory: MaterialCategory? = null, // null = Semua (dokumen)
    val selectedFileType: MaterialFileType? = null, // null = Semua tipe
    val sortOrder: MaterialSortOrder = MaterialSortOrder.DISPLAY_ORDER,
    val filteredMaterials: List<MaterialItem> = emptyList(),
    val totalDocumentCount: Int = 28,
    val favoriteIds: Set<String> = emptySet(),
    val lastReadPages: Map<String, Int> = emptyMap(),
    val offlineFileIds: Set<String> = emptySet()
)

class MaterialsViewModel(
    private val materialRepository: MaterialRepository
) : ViewModel() {

    private val _searchQuery = MutableStateFlow("")
    private val _selectedCategory = MutableStateFlow<MaterialCategory?>(null)
    private val _selectedFileType = MutableStateFlow<MaterialFileType?>(null)
    private val _sortOrder = MutableStateFlow(MaterialSortOrder.DISPLAY_ORDER)

    val uiState: StateFlow<MaterialsUiState> = combine<Any?, MaterialsUiState>(
        materialRepository.materialsFlow,
        _searchQuery,
        _selectedCategory,
        _selectedFileType,
        _sortOrder,
        materialRepository.favoriteIdsFlow,
        materialRepository.lastReadPagesFlow,
        materialRepository.offlineFileIdsFlow
    ) { values ->
        @Suppress("UNCHECKED_CAST")
        val allMaterials = values[0] as List<MaterialItem>
        val query = (values[1] as String).trim()
        val category = values[2] as MaterialCategory?
        val fileType = values[3] as MaterialFileType?
        val sortOrder = values[4] as MaterialSortOrder
        @Suppress("UNCHECKED_CAST")
        val favIds = values[5] as Set<String>
        @Suppress("UNCHECKED_CAST")
        val lastPages = values[6] as Map<String, Int>
        @Suppress("UNCHECKED_CAST")
        val offlineIds = values[7] as Set<String>

        // Default library shows document categories (28 items) unless user explicitly picks VIDEO type/category or searches
        val baseList = if (category == null && fileType == null && query.isEmpty()) {
            allMaterials.filter { it.category != MaterialCategory.VIDEO }
        } else {
            allMaterials
        }

        val filtered = baseList.filter { item ->
            val matchesCategory = category == null || item.category == category
            val matchesType = fileType == null || item.fileType == fileType
            val matchesQuery = query.isEmpty() ||
                item.title.contains(query, ignoreCase = true) ||
                item.description.contains(query, ignoreCase = true) ||
                item.category.label.contains(query, ignoreCase = true) ||
                item.fileType.badgeLabel.contains(query, ignoreCase = true)
            matchesCategory && matchesType && matchesQuery
        }

        val sorted = when (sortOrder) {
            MaterialSortOrder.DISPLAY_ORDER -> filtered.sortedBy { it.displayOrder }
            MaterialSortOrder.TITLE_ASC -> filtered.sortedBy { it.title.lowercase() }
        }

        MaterialsUiState(
            searchQuery = values[1] as String,
            selectedCategory = category,
            selectedFileType = fileType,
            sortOrder = sortOrder,
            filteredMaterials = sorted,
            totalDocumentCount = allMaterials.count { it.category != MaterialCategory.VIDEO },
            favoriteIds = favIds,
            lastReadPages = lastPages,
            offlineFileIds = offlineIds
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = MaterialsUiState()
    )

    fun onSearchQueryChange(query: String) {
        _searchQuery.value = query
    }

    fun selectCategory(category: MaterialCategory?) {
        _selectedCategory.value = category
    }

    fun selectFileType(fileType: MaterialFileType?) {
        _selectedFileType.value = fileType
    }

    fun toggleSortOrder() {
        _sortOrder.value = when (_sortOrder.value) {
            MaterialSortOrder.DISPLAY_ORDER -> MaterialSortOrder.TITLE_ASC
            MaterialSortOrder.TITLE_ASC -> MaterialSortOrder.DISPLAY_ORDER
        }
    }

    fun resetFilters() {
        _searchQuery.value = ""
        _selectedCategory.value = null
        _selectedFileType.value = null
    }

    fun toggleFavorite(materialId: String) {
        viewModelScope.launch {
            materialRepository.toggleFavorite(materialId)
        }
    }

    class Factory(private val materialRepository: MaterialRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return MaterialsViewModel(materialRepository) as T
        }
    }
}
