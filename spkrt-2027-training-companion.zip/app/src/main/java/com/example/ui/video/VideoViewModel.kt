package com.example.ui.video

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.auth.AuthRepository
import com.example.data.repository.MaterialRepository
import com.example.domain.model.MaterialCategory
import com.example.domain.model.MaterialItem
import com.example.domain.model.VideoProgress
import com.example.video.VideoStreamResolution
import com.example.video.VideoStreamResolver
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed class VideoPlayerState {
    data object Idle : VideoPlayerState()
    data object Resolving : VideoPlayerState()
    data class ReadyExoPlayer(
        val streamUrl: String,
        val sourceLabel: String,
        val startPositionMs: Long
    ) : VideoPlayerState()

    data class DriveEmbedFallback(
        val previewUrl: String,
        val reason: String
    ) : VideoPlayerState()

    data class Error(val message: String) : VideoPlayerState()
}

data class VideoScreenUiState(
    val videos: List<MaterialItem> = emptyList(),
    val selectedVideo: MaterialItem? = null,
    val playerState: VideoPlayerState = VideoPlayerState.Idle,
    val progressByMaterialId: Map<String, VideoProgress> = emptyMap(),
    val favoriteIds: Set<String> = emptySet(),
    val isFullscreen: Boolean = false
)

class VideoViewModel(
    private val materialRepository: MaterialRepository,
    private val authRepository: AuthRepository,
    private val videoStreamResolver: VideoStreamResolver
) : ViewModel() {

    private val _selectedVideoId = MutableStateFlow<String?>(null)
    private val _playerState = MutableStateFlow<VideoPlayerState>(VideoPlayerState.Idle)
    private val _isFullscreen = MutableStateFlow(false)

    val uiState: StateFlow<VideoScreenUiState> = combine<Any?, VideoScreenUiState>(
        materialRepository.materialsFlow,
        _selectedVideoId,
        _playerState,
        materialRepository.videoProgressFlow,
        materialRepository.favoriteIdsFlow,
        _isFullscreen
    ) { values ->
        @Suppress("UNCHECKED_CAST")
        val all = values[0] as List<MaterialItem>
        val videos = all.filter { it.category == MaterialCategory.VIDEO }.sortedBy { it.displayOrder }
        val selectedId = values[1] as String?
        val selected = videos.firstOrNull { it.id == selectedId || it.fileId == selectedId }
            ?: videos.firstOrNull()
        val playerState = values[2] as VideoPlayerState
        @Suppress("UNCHECKED_CAST")
        val progress = values[3] as Map<String, VideoProgress>
        @Suppress("UNCHECKED_CAST")
        val favs = values[4] as Set<String>
        val fullscreen = values[5] as Boolean

        VideoScreenUiState(
            videos = videos,
            selectedVideo = selected,
            playerState = playerState,
            progressByMaterialId = progress,
            favoriteIds = favs,
            isFullscreen = fullscreen
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = VideoScreenUiState()
    )

    init {
        viewModelScope.launch {
            val firstVideo = materialRepository.materialsFlow.first()
                .filter { it.category == MaterialCategory.VIDEO }
                .minByOrNull { it.displayOrder }
            if (firstVideo != null && _selectedVideoId.value == null) {
                selectVideo(firstVideo)
            }
        }
    }

    fun selectVideoById(materialId: String) {
        viewModelScope.launch {
            val mat = materialRepository.getMaterialById(materialId) ?: return@launch
            selectVideo(mat)
        }
    }

    fun selectVideo(video: MaterialItem) {
        _selectedVideoId.value = video.id
        resolveSelectedVideo(video)
    }

    fun retryCurrentVideo() {
        val current = uiState.value.selectedVideo ?: return
        resolveSelectedVideo(current)
    }

    private fun resolveSelectedVideo(video: MaterialItem) {
        viewModelScope.launch {
            materialRepository.recordMaterialOpened(video.id)
            _playerState.value = VideoPlayerState.Resolving

            val portalUrl = authRepository.getPortalUrl()
            val token = authRepository.getCurrentSession()?.token.orEmpty()
            val savedProgress = materialRepository.videoProgressFlow.first()[video.id]?.positionMs ?: 0L

            when (val resolution = videoStreamResolver.resolveStream(video, portalUrl, token)) {
                is VideoStreamResolution.DirectExoPlayerStream -> {
                    _playerState.value = VideoPlayerState.ReadyExoPlayer(
                        streamUrl = resolution.streamUrl,
                        sourceLabel = resolution.sourceLabel,
                        startPositionMs = savedProgress
                    )
                }
                is VideoStreamResolution.DrivePreviewFallback -> {
                    _playerState.value = VideoPlayerState.DriveEmbedFallback(
                        previewUrl = resolution.previewUrl,
                        reason = resolution.reason
                    )
                }
                is VideoStreamResolution.Error -> {
                    _playerState.value = VideoPlayerState.Error(resolution.message)
                }
            }
        }
    }

    fun fallbackToDrivePreview(reason: String) {
        val current = uiState.value.selectedVideo ?: return
        _playerState.value = VideoPlayerState.DriveEmbedFallback(
            previewUrl = current.previewUrl,
            reason = reason
        )
    }

    fun saveWatchProgress(positionMs: Long, durationMs: Long) {
        val current = uiState.value.selectedVideo ?: return
        if (durationMs <= 0L) return
        viewModelScope.launch {
            materialRepository.saveVideoProgress(current.id, positionMs, durationMs)
        }
    }

    fun setFullscreen(fullscreen: Boolean) {
        _isFullscreen.value = fullscreen
    }

    fun toggleFavorite(materialId: String) {
        viewModelScope.launch {
            materialRepository.toggleFavorite(materialId)
        }
    }

    class Factory(
        private val materialRepository: MaterialRepository,
        private val authRepository: AuthRepository,
        private val videoStreamResolver: VideoStreamResolver
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return VideoViewModel(materialRepository, authRepository, videoStreamResolver) as T
        }
    }
}
