package com.example.ui.reader

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Slideshow
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material.icons.filled.ZoomOut
import androidx.compose.material.icons.outlined.StarOutline
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.ui.theme.BpsBlueDark
import com.example.ui.theme.BpsBluePrimary
import com.example.ui.theme.BpsOrangeAccent
import com.example.ui.theme.BpsOutlineSubtle

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PptxViewerScreen(
    viewModel: PptxViewerViewModel,
    onNavigateBack: () -> Unit
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("pptx_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.cd_navigate_back),
                            tint = Color.White
                        )
                    }
                },
                title = {
                    Column {
                        Text(
                            text = state.material?.safeDisplayTitle ?: stringResource(R.string.pptx_viewer_title),
                            style = MaterialTheme.typography.titleMedium,
                            color = Color.White,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "Presentasi PPTX • Bahan Ajar",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White.copy(alpha = 0.85f)
                        )
                    }
                },
                actions = {
                    IconButton(onClick = viewModel::toggleFavorite) {
                        Icon(
                            imageVector = if (state.isFavorite) Icons.Filled.Star else Icons.Outlined.StarOutline,
                            contentDescription = stringResource(R.string.cd_favorite),
                            tint = if (state.isFavorite) BpsOrangeAccent else Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BpsBluePrimary)
            )
        },
        bottomBar = {
            if (state.viewMode == PptxViewMode.NATIVE_OFFLINE && state.nativeSlides.isNotEmpty()) {
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    shadowElevation = 6.dp
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .navigationBarsPadding()
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(
                                onClick = viewModel::previousSlide,
                                enabled = state.currentSlideIndex > 0,
                                modifier = Modifier.testTag("pptx_prev_slide_button")
                            ) {
                                Icon(Icons.Filled.ChevronLeft, contentDescription = "Slide sebelumnya")
                            }
                            Surface(
                                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text(
                                    text = stringResource(
                                        R.string.pptx_slide_indicator_format,
                                        state.currentSlideIndex + 1,
                                        state.nativeSlides.size
                                    ),
                                    style = MaterialTheme.typography.labelLarge,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
                                )
                            }
                            IconButton(
                                onClick = viewModel::nextSlide,
                                enabled = state.currentSlideIndex < state.nativeSlides.lastIndex,
                                modifier = Modifier.testTag("pptx_next_slide_button")
                            ) {
                                Icon(Icons.Filled.ChevronRight, contentDescription = "Slide berikutnya")
                            }
                        }

                        Row {
                            IconButton(onClick = viewModel::zoomOut) {
                                Icon(Icons.Filled.ZoomOut, contentDescription = stringResource(R.string.cd_zoom_out))
                            }
                            IconButton(onClick = viewModel::zoomIn) {
                                Icon(Icons.Filled.ZoomIn, contentDescription = stringResource(R.string.cd_zoom_in))
                            }
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
                .testTag("pptx_viewer_screen")
        ) {
            // Mode switcher (Visual Drive Slide Viewer vs Native Offline Text Slides)
            Surface(
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 1.dp
            ) {
                SingleChoiceSegmentedButtonRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp)
                ) {
                    PptxViewMode.entries.forEachIndexed { idx, mode ->
                        SegmentedButton(
                            selected = state.viewMode == mode,
                            onClick = { viewModel.selectMode(mode) },
                            shape = SegmentedButtonDefaults.itemShape(
                                index = idx,
                                count = PptxViewMode.entries.size
                            ),
                            modifier = Modifier.testTag("pptx_mode_${mode.name.lowercase()}")
                        ) {
                            Text(mode.label, style = MaterialTheme.typography.labelMedium)
                        }
                    }
                }
            }

            when (state.viewMode) {
                PptxViewMode.DRIVE_VISUAL -> {
                    val previewUrl = state.material?.previewUrl.orEmpty()
                    if (previewUrl.isNotBlank()) {
                        Column(modifier = Modifier.fillMaxSize()) {
                            if (!state.driveWebError.isNullOrBlank()) {
                                Surface(
                                    color = MaterialTheme.colorScheme.errorContainer,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = state.driveWebError.orEmpty(),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onErrorContainer,
                                        modifier = Modifier.padding(12.dp)
                                    )
                                }
                            }
                            ControlledDriveWebView(
                                previewUrl = previewUrl,
                                modifier = Modifier.fillMaxSize(),
                                preferSoftwareLayer = true,
                                onError = viewModel::onDriveWebError,
                                onRendererCrashed = {
                                    viewModel.onDriveWebError(
                                        "Pratinjau visual WebView terhenti. Anda dapat memuat ulang atau menggunakan tab 'Teks Slide (Offline)'."
                                    )
                                }
                            )
                        }
                    }
                }

                PptxViewMode.NATIVE_OFFLINE -> {
                    when {
                        state.isLoadingNative -> {
                            Box(
                                modifier = Modifier.fillMaxSize(),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    CircularProgressIndicator(color = BpsBluePrimary)
                                    Text(
                                        text = "Mengunduh & mengekstrak slide PPTX…",
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                }
                            }
                        }

                        !state.nativeErrorMessage.isNullOrBlank() -> {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(20.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Card(
                                    shape = RoundedCornerShape(18.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    border = BorderStroke(1.dp, BpsOutlineSubtle)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(20.dp),
                                        verticalArrangement = Arrangement.spacedBy(12.dp)
                                    ) {
                                        Text(
                                            text = "Ekstraksi Slide Native Tidak Tersedia",
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = state.nativeErrorMessage.orEmpty(),
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            Button(onClick = { viewModel.selectMode(PptxViewMode.DRIVE_VISUAL) }) {
                                                Text("Buka Visual Slide")
                                            }
                                            Button(onClick = viewModel::loadNativeSlides) {
                                                Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text(stringResource(R.string.action_retry))
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        state.nativeSlides.isNotEmpty() -> {
                            val slide = state.nativeSlides[state.currentSlideIndex]
                            val scale = state.textZoomScale
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .verticalScroll(rememberScrollState())
                                    .padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(20.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    border = BorderStroke(1.dp, BpsOutlineSubtle),
                                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
                                ) {
                                    Column {
                                        // Slide Header Accent Bar
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .background(BpsBlueDark)
                                                .padding(horizontal = 18.dp, vertical = 14.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(
                                                imageVector = Icons.Filled.Slideshow,
                                                contentDescription = null,
                                                tint = BpsOrangeAccent
                                            )
                                            Spacer(modifier = Modifier.width(10.dp))
                                            Text(
                                                text = "Slide ${slide.slideNumber} dari ${state.nativeSlides.size}",
                                                style = MaterialTheme.typography.labelLarge,
                                                color = Color.White
                                            )
                                        }

                                        Column(
                                            modifier = Modifier.padding(20.dp),
                                            verticalArrangement = Arrangement.spacedBy(12.dp)
                                        ) {
                                            Text(
                                                text = slide.title,
                                                fontSize = (20f * scale).sp,
                                                lineHeight = (26f * scale).sp,
                                                fontWeight = FontWeight.Bold,
                                                color = BpsBluePrimary
                                            )

                                            if (slide.bodyParagraphs.isNotEmpty()) {
                                                HorizontalDivider(color = BpsOutlineSubtle)
                                                slide.bodyParagraphs.forEach { para ->
                                                    Row(
                                                        verticalAlignment = Alignment.Top,
                                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                                    ) {
                                                        Text(
                                                            text = "•",
                                                            fontSize = (15f * scale).sp,
                                                            color = BpsOrangeAccent,
                                                            fontWeight = FontWeight.Bold
                                                        )
                                                        Text(
                                                            text = para,
                                                            fontSize = (15f * scale).sp,
                                                            lineHeight = (22f * scale).sp,
                                                            color = MaterialTheme.colorScheme.onSurface
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }

                                if (slide.speakerNotes.isNotBlank()) {
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(16.dp),
                                        colors = CardDefaults.cardColors(
                                            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
                                        )
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(16.dp),
                                            verticalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Text(
                                                text = "Catatan Pemateri",
                                                style = MaterialTheme.typography.labelLarge,
                                                color = BpsBlueDark
                                            )
                                            Text(
                                                text = slide.speakerNotes,
                                                style = MaterialTheme.typography.bodyMedium,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                        }
                                    }
                                }
                                Spacer(modifier = Modifier.height(12.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}
