package com.example.ui.home

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Assignment
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.domain.model.MaterialCategory
import com.example.domain.model.MaterialItem
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.MaterialItemCard
import com.example.ui.components.SyncStatusBanner
import com.example.ui.theme.BadgeDocsBlue
import com.example.ui.theme.BadgeDocsContainer
import com.example.ui.theme.BadgePptxContainer
import com.example.ui.theme.BadgePptxOrange
import com.example.ui.theme.BadgeVideoContainer
import com.example.ui.theme.BadgeVideoRed
import com.example.ui.theme.BpsBlueDark
import com.example.ui.theme.BpsBluePrimary
import com.example.ui.theme.BpsGreenContainer
import com.example.ui.theme.BpsGreenSuccess
import com.example.ui.theme.BpsOrangeAccent
import com.example.ui.theme.BpsOutlineSubtle

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: HomeViewModel,
    onCategoryQuickAccess: (MaterialCategory) -> Unit,
    onVideoQuickAccess: () -> Unit,
    onOpenMaterial: (MaterialItem) -> Unit,
    contentBottomPadding: PaddingValues
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val userName = state.userSession?.name ?: "Peserta SPKRT"
    val userRole = state.userSession?.role ?: "Peserta Pelatihan"
    val userClass = state.userSession?.className ?: "BPS Kabupaten Pinrang"

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = stringResource(R.string.nav_home),
                            style = MaterialTheme.typography.titleLarge,
                            color = Color.White
                        )
                        Text(
                            text = stringResource(R.string.bps_institution),
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White.copy(alpha = 0.85f)
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = viewModel::syncCatalog,
                        modifier = Modifier.testTag("home_refresh_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Refresh,
                            contentDescription = stringResource(R.string.cd_sync),
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = BpsBluePrimary
                )
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = innerPadding.calculateTopPadding())
                .testTag("home_screen"),
            contentAlignment = Alignment.TopCenter
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 720.dp),
                contentPadding = PaddingValues(
                    start = 16.dp,
                    end = 16.dp,
                    top = 16.dp,
                    bottom = contentBottomPadding.calculateBottomPadding() + 24.dp
                ),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Greeting header
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = stringResource(R.string.home_greeting_format, userName),
                            style = MaterialTheme.typography.headlineSmall,
                            color = MaterialTheme.colorScheme.onBackground,
                            fontWeight = FontWeight.Bold
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Surface(
                                color = MaterialTheme.colorScheme.primaryContainer,
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(
                                    text = userRole,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                            Text(
                                text = userClass,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                // Hero Banner Card matching storyboard
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(20.dp))
                            .background(
                                Brush.linearGradient(
                                    colors = listOf(BpsBlueDark, BpsBluePrimary)
                                )
                            )
                            .padding(18.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Surface(
                                    color = BpsOrangeAccent,
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(
                                        text = "SPKRT 2027",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                    )
                                }
                                Text(
                                    text = "${state.totalMaterials} Materi Resmi",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = Color.White.copy(alpha = 0.9f)
                                )
                            }
                            Text(
                                text = "Pelatihan Survei Pola Konsumsi Rumah Tangga",
                                style = MaterialTheme.typography.titleMedium,
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Akses terpusat buku pedoman, kuesioner, bahan ajar, poin penegasan, dan video pembelajaran.",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.White.copy(alpha = 0.88f)
                            )
                        }
                    }
                }

                // Honest Sync Status Banner
                item {
                    SyncStatusBanner(
                        syncState = state.syncState,
                        onSyncClick = viewModel::syncCatalog
                    )
                }

                // Quick Access 2x2 Grid + Video Banner
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = stringResource(R.string.home_quick_access),
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onBackground,
                            fontWeight = FontWeight.Bold
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            QuickCategoryTile(
                                title = "Buku Pedoman",
                                count = state.categoryCounts[MaterialCategory.BUKU_PEDOMAN] ?: 7,
                                subtitle = "Docs & PDF",
                                icon = Icons.AutoMirrored.Filled.MenuBook,
                                iconBg = BadgeDocsContainer,
                                iconTint = BadgeDocsBlue,
                                onClick = { onCategoryQuickAccess(MaterialCategory.BUKU_PEDOMAN) },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("quick_buku_pedoman")
                            )
                            QuickCategoryTile(
                                title = "Kuesioner",
                                count = state.categoryCounts[MaterialCategory.KUESIONER] ?: 8,
                                subtitle = "Instrumen PDF",
                                icon = Icons.AutoMirrored.Filled.Assignment,
                                iconBg = MaterialTheme.colorScheme.primaryContainer,
                                iconTint = BpsBluePrimary,
                                onClick = { onCategoryQuickAccess(MaterialCategory.KUESIONER) },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("quick_kuesioner")
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            QuickCategoryTile(
                                title = "Bahan Ajar",
                                count = state.categoryCounts[MaterialCategory.BAHAN_AJAR] ?: 12,
                                subtitle = "PDF & PPTX",
                                icon = Icons.Filled.School,
                                iconBg = BpsGreenContainer,
                                iconTint = BpsGreenSuccess,
                                onClick = { onCategoryQuickAccess(MaterialCategory.BAHAN_AJAR) },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("quick_bahan_ajar")
                            )
                            QuickCategoryTile(
                                title = "Penegasan",
                                count = state.categoryCounts[MaterialCategory.PENEGASAN] ?: 1,
                                subtitle = "Rekap Innas",
                                icon = Icons.Filled.Campaign,
                                iconBg = BadgePptxContainer,
                                iconTint = BadgePptxOrange,
                                onClick = { onCategoryQuickAccess(MaterialCategory.PENEGASAN) },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("quick_penegasan")
                            )
                        }

                        // Full-width Video Pembelajaran quick access card
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("quick_video")
                                .clickable(onClick = onVideoQuickAccess),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, BpsOutlineSubtle)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(46.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(BadgeVideoContainer),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.PlayCircle,
                                        contentDescription = null,
                                        tint = BadgeVideoRed,
                                        modifier = Modifier.size(26.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Video Pembelajaran (${state.categoryCounts[MaterialCategory.VIDEO] ?: 4})",
                                        style = MaterialTheme.typography.titleSmall,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "Putar 4 materi video pelatihan langsung di aplikasi",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Icon(
                                    imageVector = Icons.Filled.ChevronRight,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }

                // Materi Terakhir Dibuka
                item {
                    Text(
                        text = stringResource(R.string.home_recent_materials),
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onBackground,
                        fontWeight = FontWeight.Bold
                    )
                }

                if (state.recentMaterials.isEmpty()) {
                    item {
                        EmptyStateCard(
                            icon = Icons.Filled.History,
                            title = "Belum Ada Riwayat Baca",
                            subtitle = stringResource(R.string.home_empty_recent)
                        )
                    }
                } else {
                    items(state.recentMaterials, key = { "recent_${it.id}" }) { material ->
                        MaterialItemCard(
                            material = material,
                            isFavorite = material.id in state.favoriteIds,
                            isOfflineAvailable = material.fileId in state.offlineFileIds,
                            lastReadPageIndex = state.lastReadPages[material.id],
                            onOpenClick = { onOpenMaterial(material) },
                            onToggleFavorite = { viewModel.toggleFavorite(material.id) }
                        )
                    }
                }

                // Favorit Anda
                item {
                    Text(
                        text = stringResource(R.string.home_favorites),
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onBackground,
                        fontWeight = FontWeight.Bold
                    )
                }

                if (state.favoriteMaterials.isEmpty()) {
                    item {
                        EmptyStateCard(
                            icon = Icons.Filled.Star,
                            title = "Daftar Favorit Kosong",
                            subtitle = stringResource(R.string.home_empty_favorites)
                        )
                    }
                } else {
                    items(state.favoriteMaterials, key = { "fav_${it.id}" }) { material ->
                        MaterialItemCard(
                            material = material,
                            isFavorite = true,
                            isOfflineAvailable = material.fileId in state.offlineFileIds,
                            lastReadPageIndex = state.lastReadPages[material.id],
                            onOpenClick = { onOpenMaterial(material) },
                            onToggleFavorite = { viewModel.toggleFavorite(material.id) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun QuickCategoryTile(
    title: String,
    count: Int,
    subtitle: String,
    icon: ImageVector,
    iconBg: Color,
    iconTint: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, BpsOutlineSubtle),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(iconBg),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = iconTint,
                        modifier = Modifier.size(22.dp)
                    )
                }
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = "$count",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 9.dp, vertical = 3.dp)
                    )
                }
            }
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onSurface,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
