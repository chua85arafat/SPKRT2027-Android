package com.example.reader

import android.util.Xml
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.xmlpull.v1.XmlPullParser
import java.io.File
import java.io.StringReader
import java.util.zip.ZipFile

data class PptxSlideContent(
    val slideNumber: Int,
    val title: String,
    val bodyParagraphs: List<String>,
    val speakerNotes: String = ""
)

/**
 * Lightweight native PPTX slide parser (OpenXML ZIP -> slide XMLs).
 * Extracts ordered slide titles, bullet paragraphs, and notes without heavy POI bloat,
 * serving as a reliable offline/native slide viewer alongside the controlled Drive Preview.
 */
object PptxSlideParser {

    private val slideEntryRegex = Regex("^ppt/slides/slide(\\d+)\\.xml$")
    private val notesEntryRegex = Regex("^ppt/notesSlides/notesSlide(\\d+)\\.xml$")

    suspend fun parseSlides(pptxFile: File): List<PptxSlideContent> = withContext(Dispatchers.IO) {
        if (!pptxFile.exists() || pptxFile.length() == 0L) return@withContext emptyList()

        val slideParagraphsByNum = sortedMapOf<Int, List<String>>()
        val notesByNum = mutableMapOf<Int, String>()

        ZipFile(pptxFile).use { zip ->
            val entries = zip.entries()
            while (entries.hasMoreElements()) {
                val entry = entries.nextElement()
                val name = entry.name
                val slideMatch = slideEntryRegex.matchEntire(name)
                if (slideMatch != null) {
                    val num = slideMatch.groupValues[1].toIntOrNull() ?: continue
                    val xmlText = zip.getInputStream(entry).bufferedReader(Charsets.UTF_8).use { it.readText() }
                    slideParagraphsByNum[num] = extractParagraphsFromOpenXml(xmlText)
                } else {
                    val notesMatch = notesEntryRegex.matchEntire(name)
                    if (notesMatch != null) {
                        val num = notesMatch.groupValues[1].toIntOrNull() ?: continue
                        val xmlText = zip.getInputStream(entry).bufferedReader(Charsets.UTF_8).use { it.readText() }
                        notesByNum[num] = extractParagraphsFromOpenXml(xmlText).joinToString("\n")
                    }
                }
            }
        }

        slideParagraphsByNum.entries.mapIndexed { idx, (slideNum, paragraphs) ->
            val cleaned = paragraphs.map { it.trim() }.filter { it.isNotEmpty() }
            val title = cleaned.firstOrNull() ?: "Slide ${idx + 1}"
            val body = if (cleaned.size > 1) cleaned.drop(1) else emptyList()
            PptxSlideContent(
                slideNumber = idx + 1,
                title = title,
                bodyParagraphs = body,
                speakerNotes = notesByNum[slideNum].orEmpty()
            )
        }
    }

    private fun extractParagraphsFromOpenXml(xmlContent: String): List<String> {
        val paragraphs = mutableListOf<String>()
        val parser = Xml.newPullParser()
        parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
        parser.setInput(StringReader(xmlContent))

        var currentParagraph = StringBuilder()
        var insideTextRun = false

        var eventType = parser.eventType
        while (eventType != XmlPullParser.END_DOCUMENT) {
            when (eventType) {
                XmlPullParser.START_TAG -> {
                    val tag = parser.name.substringAfter(':')
                    if (tag == "p") {
                        currentParagraph = StringBuilder()
                    } else if (tag == "t") {
                        insideTextRun = true
                    } else if (tag == "br") {
                        currentParagraph.append('\n')
                    }
                }
                XmlPullParser.TEXT -> {
                    if (insideTextRun) {
                        currentParagraph.append(parser.text)
                    }
                }
                XmlPullParser.END_TAG -> {
                    val tag = parser.name.substringAfter(':')
                    if (tag == "t") {
                        insideTextRun = false
                    } else if (tag == "p") {
                        val text = currentParagraph.toString().trim()
                        if (text.isNotEmpty()) {
                            paragraphs.add(text)
                        }
                    }
                }
            }
            eventType = parser.next()
        }
        return paragraphs
    }
}
