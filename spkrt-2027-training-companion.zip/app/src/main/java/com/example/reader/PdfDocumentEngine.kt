package com.example.reader

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import com.tom_roush.pdfbox.text.TextPosition
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import java.io.StringWriter
import kotlin.math.max
import kotlin.math.min

data class NormalizedRect(
    val left: Float,
    val top: Float,
    val right: Float,
    val bottom: Float
)

data class PdfSearchMatch(
    val matchIndex: Int,
    val pageIndex: Int,
    val snippet: String,
    val rects: List<NormalizedRect>
)

private data class PageTextIndex(
    val pageIndex: Int,
    val fullText: String,
    val charBoxes: List<NormalizedRect?>
)

data class PdfLoadSummary(
    val pageCount: Int,
    val isScannedWithoutTextLayer: Boolean
)

/**
 * Native PDF Rendering + Real Text Extraction & Bounding-Box Search Engine.
 *
 * Architecture:
 * - Uses Android SDK `PdfRenderer` for crisp, low-overhead page bitmap rendering.
 * - Uses `PDFBox-Android` (`PDFTextStripper.writeString`) with temp-file-backed memory settings
 *   to build a per-character coordinate index safely on large documents.
 * - Automatically detects scanned image-only PDFs that lack a text layer.
 */
class PdfDocumentEngine {

    private val renderMutex = Mutex()
    private val indexMutex = Mutex()

    private var fileDescriptor: ParcelFileDescriptor? = null
    private var pdfRenderer: PdfRenderer? = null
    private var openedFile: File? = null
    private var indexedPages: List<PageTextIndex> = emptyList()
    private var isIndexed: Boolean = false
    private var scannedWithoutText: Boolean = false

    val pageCount: Int
        get() = pdfRenderer?.pageCount ?: 0

    suspend fun open(file: File): PdfLoadSummary = withContext(Dispatchers.IO) {
        close()
        renderMutex.withLock {
            val pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
            val renderer = PdfRenderer(pfd)
            fileDescriptor = pfd
            pdfRenderer = renderer
            openedFile = file
            indexedPages = emptyList()
            isIndexed = false
            scannedWithoutText = false
            PdfLoadSummary(
                pageCount = renderer.pageCount,
                isScannedWithoutTextLayer = false
            )
        }
    }

    suspend fun renderPage(pageIndex: Int, targetWidthPx: Int): Bitmap? = withContext(Dispatchers.IO) {
        renderMutex.withLock {
            val renderer = pdfRenderer ?: return@withContext null
            if (pageIndex < 0 || pageIndex >= renderer.pageCount) return@withContext null
            runCatching {
                renderer.openPage(pageIndex).use { page ->
                    val clampedWidth = targetWidthPx.coerceIn(360, 2200)
                    val aspectRatio = if (page.width > 0) page.height.toFloat() / page.width.toFloat() else 1.414f
                    val targetHeight = (clampedWidth * aspectRatio).toInt().coerceIn(360, 3200)
                    val bitmap = Bitmap.createBitmap(clampedWidth, targetHeight, Bitmap.Config.ARGB_8888)
                    Canvas(bitmap).drawColor(Color.WHITE)
                    page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    bitmap
                }
            }.getOrNull()
        }
    }

    /**
     * Builds the full-document text and bounding-box index lazily (runs once per opened PDF).
     * Returns true if the PDF appears to be a scanned image without an embedded text layer.
     */
    suspend fun ensureTextIndexed(onPageIndexed: (Int, Int) -> Unit = { _, _ -> }): Boolean =
        withContext(Dispatchers.Default) {
            indexMutex.withLock {
                if (isIndexed) return@withLock scannedWithoutText
                val file = openedFile ?: return@withLock false
                val pages = mutableListOf<PageTextIndex>()
                var nonWhitespaceChars = 0

                runCatching {
                    PDDocument.load(file, MemoryUsageSetting.setupTempFileOnly()).use { document ->
                        val total = document.numberOfPages
                        for (pageIdx in 0 until total) {
                            val pdPage = document.getPage(pageIdx)
                            val cropBox = pdPage.cropBox ?: pdPage.mediaBox
                            val pageWidth = cropBox.width.coerceAtLeast(1f)
                            val pageHeight = cropBox.height.coerceAtLeast(1f)

                            val stripper = CoordinateTextStripper(
                                pageWidth = pageWidth,
                                pageHeight = pageHeight
                            ).apply {
                                startPage = pageIdx + 1
                                endPage = pageIdx + 1
                                sortByPosition = true
                            }

                            val writer = StringWriter()
                            runCatching { stripper.writeText(document, writer) }

                            val text = stripper.extractedText()
                            nonWhitespaceChars += text.count { !it.isWhitespace() }
                            pages.add(
                                PageTextIndex(
                                    pageIndex = pageIdx,
                                    fullText = text,
                                    charBoxes = stripper.charBoxes()
                                )
                            )
                            onPageIndexed(pageIdx + 1, total)
                        }
                    }
                }

                indexedPages = pages
                scannedWithoutText = pages.isNotEmpty() && nonWhitespaceChars < 12
                isIndexed = true
                scannedWithoutText
            }
        }

    suspend fun search(query: String): Pair<List<PdfSearchMatch>, Boolean> =
        withContext(Dispatchers.Default) {
            val cleanQuery = query.trim()
            if (cleanQuery.isEmpty()) return@withContext emptyList<PdfSearchMatch>() to scannedWithoutText

            val isScanned = ensureTextIndexed()
            if (isScanned) return@withContext emptyList<PdfSearchMatch>() to true

            val matches = mutableListOf<PdfSearchMatch>()
            val queryLower = cleanQuery.lowercase()

            for (page in indexedPages) {
                val pageLower = page.fullText.lowercase()
                var startIdx = 0
                while (startIdx < pageLower.length) {
                    val foundAt = pageLower.indexOf(queryLower, startIdx)
                    if (foundAt == -1) break
                    val endAt = foundAt + queryLower.length

                    val rawRects = mutableListOf<NormalizedRect>()
                    for (i in foundAt until min(endAt, page.charBoxes.size)) {
                        page.charBoxes[i]?.let { rawRects.add(it) }
                    }
                    val mergedRects = mergeLineRects(rawRects)
                    val snippetStart = max(0, foundAt - 28)
                    val snippetEnd = min(page.fullText.length, endAt + 36)
                    val snippet = page.fullText
                        .substring(snippetStart, snippetEnd)
                        .replace('\n', ' ')
                        .replace(Regex("\\s+"), " ")
                        .trim()

                    matches.add(
                        PdfSearchMatch(
                            matchIndex = matches.size,
                            pageIndex = page.pageIndex,
                            snippet = snippet,
                            rects = mergedRects
                        )
                    )
                    startIdx = endAt
                }
            }

            matches to false
        }

    private fun mergeLineRects(rects: List<NormalizedRect>): List<NormalizedRect> {
        if (rects.isEmpty()) return emptyList()
        val merged = mutableListOf<NormalizedRect>()
        var current = rects.first()
        for (i in 1 until rects.size) {
            val next = rects[i]
            val sameLine = kotlin.math.abs(next.top - current.top) < 0.018f &&
                kotlin.math.abs(next.bottom - current.bottom) < 0.018f
            val closeHorizontally = next.left <= current.right + 0.035f
            if (sameLine && closeHorizontally) {
                current = NormalizedRect(
                    left = min(current.left, next.left),
                    top = min(current.top, next.top),
                    right = max(current.right, next.right),
                    bottom = max(current.bottom, next.bottom)
                )
            } else {
                merged.add(current)
                current = next
            }
        }
        merged.add(current)
        return merged
    }

    suspend fun close() = withContext(Dispatchers.IO) {
        renderMutex.withLock {
            runCatching { pdfRenderer?.close() }
            runCatching { fileDescriptor?.close() }
            pdfRenderer = null
            fileDescriptor = null
            openedFile = null
            indexedPages = emptyList()
            isIndexed = false
            scannedWithoutText = false
        }
    }
}

private class CoordinateTextStripper(
    private val pageWidth: Float,
    private val pageHeight: Float
) : PDFTextStripper() {

    private val builder = StringBuilder()
    private val boxes = mutableListOf<NormalizedRect?>()

    override fun writeString(text: String?, textPositions: MutableList<TextPosition>?) {
        if (text.isNullOrEmpty()) return
        val positions = textPositions ?: emptyList()

        for (i in text.indices) {
            val ch = text[i]
            builder.append(ch)
            val tp = positions.getOrNull(i) ?: positions.lastOrNull()
            if (tp != null && !ch.isWhitespace()) {
                val left = (tp.xDirAdj / pageWidth).coerceIn(0f, 1f)
                val width = (tp.widthDirAdj / pageWidth).coerceIn(0.002f, 1f)
                val height = ((tp.heightDir.takeIf { it > 0f } ?: tp.fontSizeInPt.coerceAtLeast(8f)) * 1.25f / pageHeight)
                    .coerceIn(0.008f, 0.08f)
                // yDirAdj is baseline from top of page in PDFBox
                val bottom = ((tp.yDirAdj + (tp.heightDir * 0.22f)) / pageHeight).coerceIn(0f, 1f)
                val top = (bottom - height).coerceIn(0f, bottom)
                val right = (left + width).coerceIn(left, 1f)
                boxes.add(NormalizedRect(left = left, top = top, right = right, bottom = bottom))
            } else {
                boxes.add(null)
            }
        }
        // Add space boundary between writeString calls
        builder.append(' ')
        boxes.add(null)
    }

    override fun writeLineSeparator() {
        builder.append('\n')
        boxes.add(null)
    }

    fun extractedText(): String = builder.toString()
    fun charBoxes(): List<NormalizedRect?> = boxes
}
