package com.example.storage

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Manages on-demand temporary cache and user-initiated permanent offline files.
 * Strictly validates Drive file IDs and enforces canonical directory confinement.
 */
class OfflineFileManager(context: Context) {

    private val cacheRoot = File(context.cacheDir, "spkrt_material_cache").apply { mkdirs() }
    private val offlineRoot = File(context.filesDir, "spkrt_offline_materials").apply { mkdirs() }

    private val safeFileIdRegex = Regex("^[A-Za-z0-9_-]{8,100}$")

    private val _offlineFileIds = MutableStateFlow<Set<String>>(scanOfflineFileIds())
    val offlineFileIds: StateFlow<Set<String>> = _offlineFileIds.asStateFlow()

    private fun scanOfflineFileIds(): Set<String> {
        return offlineRoot.listFiles()
            ?.filter { it.isFile && it.length() > 0L }
            ?.map { it.nameWithoutExtension }
            ?.toSet()
            ?: emptySet()
    }

    fun refreshOfflineIndex() {
        _offlineFileIds.value = scanOfflineFileIds()
    }

    private fun resolveConfinedFile(baseDir: File, fileId: String, extension: String): File {
        require(safeFileIdRegex.matches(fileId)) {
            "Identitas file Google Drive tidak valid."
        }
        val cleanExt = extension.lowercase().filter { it.isLetterOrDigit() }.ifBlank { "bin" }
        val candidate = File(baseDir, "$fileId.$cleanExt")
        val baseCanonical = baseDir.canonicalPath
        val candidateCanonical = candidate.canonicalPath
        require(candidateCanonical.startsWith("$baseCanonical${File.separator}")) {
            "Akses jalur file ditolak."
        }
        return candidate
    }

    fun getOfflineFile(fileId: String, extension: String): File? {
        if (!safeFileIdRegex.matches(fileId)) return null
        val file = resolveConfinedFile(offlineRoot, fileId, extension)
        return file.takeIf { it.exists() && it.length() > 0L }
    }

    fun getCachedOrOfflineFile(fileId: String, extension: String): File? {
        getOfflineFile(fileId, extension)?.let { return it }
        if (!safeFileIdRegex.matches(fileId)) return null
        val cached = resolveConfinedFile(cacheRoot, fileId, extension)
        return cached.takeIf { it.exists() && it.length() > 0L }
    }

    fun createCacheTarget(fileId: String, extension: String): File {
        cacheRoot.mkdirs()
        return resolveConfinedFile(cacheRoot, fileId, extension)
    }

    fun createOfflineTarget(fileId: String, extension: String): File {
        offlineRoot.mkdirs()
        return resolveConfinedFile(offlineRoot, fileId, extension)
    }

    suspend fun promoteCacheToOffline(fileId: String, extension: String): Boolean =
        withContext(Dispatchers.IO) {
            val cached = resolveConfinedFile(cacheRoot, fileId, extension)
            val offline = resolveConfinedFile(offlineRoot, fileId, extension)
            if (offline.exists() && offline.length() > 0L) {
                refreshOfflineIndex()
                return@withContext true
            }
            if (!cached.exists() || cached.length() == 0L) {
                return@withContext false
            }
            cached.copyTo(offline, overwrite = true)
            refreshOfflineIndex()
            true
        }

    suspend fun deleteOfflineFile(fileId: String, extension: String): Boolean =
        withContext(Dispatchers.IO) {
            if (!safeFileIdRegex.matches(fileId)) return@withContext false
            val offline = resolveConfinedFile(offlineRoot, fileId, extension)
            val deleted = !offline.exists() || offline.delete()
            refreshOfflineIndex()
            deleted
        }

    suspend fun getTotalStorageBytes(): Pair<Long, Long> = withContext(Dispatchers.IO) {
        val offlineBytes = offlineRoot.listFiles()?.sumOf { it.length() } ?: 0L
        val cacheBytes = cacheRoot.listFiles()?.sumOf { it.length() } ?: 0L
        offlineBytes to cacheBytes
    }

    suspend fun clearTemporaryCache() = withContext(Dispatchers.IO) {
        cacheRoot.listFiles()?.forEach { it.delete() }
    }

    suspend fun clearAllOfflineFiles() = withContext(Dispatchers.IO) {
        offlineRoot.listFiles()?.forEach { it.delete() }
        refreshOfflineIndex()
    }
}
