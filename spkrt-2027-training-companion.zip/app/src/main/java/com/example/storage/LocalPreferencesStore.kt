package com.example.storage

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.BuildConfig
import com.example.domain.model.MaterialItem
import com.example.domain.model.PageBookmark
import com.example.domain.model.RecentMaterialEntry
import com.example.domain.model.UserSession
import com.example.domain.model.VideoProgress
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

private val Context.spkrtDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "spkrt_2027_preferences"
)

class LocalPreferencesStore(private val context: Context) {

    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    private object Keys {
        val USER_SESSION = stringPreferencesKey("user_session_json")
        val PORTAL_URL = stringPreferencesKey("portal_apps_script_url")
        val FAVORITES = stringSetPreferencesKey("favorite_material_ids")
        val RECENT_MATERIALS = stringPreferencesKey("recent_materials_json")
        val LAST_READ_PAGES = stringPreferencesKey("last_read_pages_json")
        val PAGE_BOOKMARKS = stringPreferencesKey("page_bookmarks_json")
        val VIDEO_PROGRESS = stringPreferencesKey("video_progress_json")
        val CACHED_PORTAL_CATALOG = stringPreferencesKey("cached_portal_catalog_json")
        val LAST_CATALOG_SYNC_MS = longPreferencesKey("last_catalog_sync_ms")
    }

    val userSessionFlow: Flow<UserSession?> = context.spkrtDataStore.data.map { prefs ->
        prefs[Keys.USER_SESSION]?.let { raw ->
            runCatching { json.decodeFromString<UserSession>(raw) }.getOrNull()
        }
    }

    val portalUrlFlow: Flow<String> = context.spkrtDataStore.data.map { prefs ->
        prefs[Keys.PORTAL_URL]?.takeIf { it.isNotBlank() } ?: BuildConfig.DEFAULT_APPS_SCRIPT_URL
    }

    val favoriteIdsFlow: Flow<Set<String>> = context.spkrtDataStore.data.map { prefs ->
        prefs[Keys.FAVORITES] ?: emptySet()
    }

    val recentMaterialsFlow: Flow<List<RecentMaterialEntry>> = context.spkrtDataStore.data.map { prefs ->
        prefs[Keys.RECENT_MATERIALS]?.let { raw ->
            runCatching { json.decodeFromString<List<RecentMaterialEntry>>(raw) }.getOrNull()
        } ?: emptyList()
    }

    val lastReadPagesFlow: Flow<Map<String, Int>> = context.spkrtDataStore.data.map { prefs ->
        prefs[Keys.LAST_READ_PAGES]?.let { raw ->
            runCatching { json.decodeFromString<Map<String, Int>>(raw) }.getOrNull()
        } ?: emptyMap()
    }

    val pageBookmarksFlow: Flow<List<PageBookmark>> = context.spkrtDataStore.data.map { prefs ->
        prefs[Keys.PAGE_BOOKMARKS]?.let { raw ->
            runCatching { json.decodeFromString<List<PageBookmark>>(raw) }.getOrNull()
        } ?: emptyList()
    }

    val videoProgressFlow: Flow<Map<String, VideoProgress>> = context.spkrtDataStore.data.map { prefs ->
        prefs[Keys.VIDEO_PROGRESS]?.let { raw ->
            runCatching { json.decodeFromString<Map<String, VideoProgress>>(raw) }.getOrNull()
        } ?: emptyMap()
    }

    val cachedPortalCatalogFlow: Flow<List<MaterialItem>> = context.spkrtDataStore.data.map { prefs ->
        prefs[Keys.CACHED_PORTAL_CATALOG]?.let { raw ->
            runCatching { json.decodeFromString<List<MaterialItem>>(raw) }.getOrNull()
        } ?: emptyList()
    }

    val lastCatalogSyncMillisFlow: Flow<Long?> = context.spkrtDataStore.data.map { prefs ->
        prefs[Keys.LAST_CATALOG_SYNC_MS]
    }

    suspend fun saveSession(session: UserSession) {
        context.spkrtDataStore.edit { prefs ->
            prefs[Keys.USER_SESSION] = json.encodeToString(session)
        }
    }

    suspend fun clearSession() {
        context.spkrtDataStore.edit { prefs ->
            prefs.remove(Keys.USER_SESSION)
        }
    }

    suspend fun savePortalUrl(url: String) {
        context.spkrtDataStore.edit { prefs ->
            val trimmed = url.trim()
            if (trimmed.isEmpty()) {
                prefs.remove(Keys.PORTAL_URL)
            } else {
                prefs[Keys.PORTAL_URL] = trimmed
            }
        }
    }

    suspend fun toggleFavorite(materialId: String) {
        context.spkrtDataStore.edit { prefs ->
            val current = prefs[Keys.FAVORITES]?.toMutableSet() ?: mutableSetOf()
            if (!current.add(materialId)) {
                current.remove(materialId)
            }
            prefs[Keys.FAVORITES] = current
        }
    }

    suspend fun recordRecentMaterial(materialId: String) {
        context.spkrtDataStore.edit { prefs ->
            val current = prefs[Keys.RECENT_MATERIALS]?.let {
                runCatching { json.decodeFromString<List<RecentMaterialEntry>>(it) }.getOrNull()
            }?.toMutableList() ?: mutableListOf()

            current.removeAll { it.materialId == materialId }
            current.add(0, RecentMaterialEntry(materialId, System.currentTimeMillis()))
            val trimmed = current.take(12)
            prefs[Keys.RECENT_MATERIALS] = json.encodeToString(trimmed)
        }
    }

    suspend fun saveLastReadPage(materialId: String, pageIndex: Int) {
        context.spkrtDataStore.edit { prefs ->
            val current = prefs[Keys.LAST_READ_PAGES]?.let {
                runCatching { json.decodeFromString<Map<String, Int>>(it) }.getOrNull()
            }?.toMutableMap() ?: mutableMapOf()
            current[materialId] = pageIndex.coerceAtLeast(0)
            prefs[Keys.LAST_READ_PAGES] = json.encodeToString(current)
        }
    }

    suspend fun togglePageBookmark(
        materialId: String,
        materialTitle: String,
        pageIndex: Int,
        label: String = "Halaman ${pageIndex + 1}"
    ): Boolean {
        var added = false
        context.spkrtDataStore.edit { prefs ->
            val current = prefs[Keys.PAGE_BOOKMARKS]?.let {
                runCatching { json.decodeFromString<List<PageBookmark>>(it) }.getOrNull()
            }?.toMutableList() ?: mutableListOf()

            val existingIdx = current.indexOfFirst {
                it.materialId == materialId && it.pageIndex == pageIndex
            }
            if (existingIdx >= 0) {
                current.removeAt(existingIdx)
                added = false
            } else {
                current.add(
                    0,
                    PageBookmark(
                        materialId = materialId,
                        materialTitle = materialTitle,
                        pageIndex = pageIndex,
                        label = label
                    )
                )
                added = true
            }
            prefs[Keys.PAGE_BOOKMARKS] = json.encodeToString(current)
        }
        return added
    }

    suspend fun removeBookmark(materialId: String, pageIndex: Int) {
        context.spkrtDataStore.edit { prefs ->
            val current = prefs[Keys.PAGE_BOOKMARKS]?.let {
                runCatching { json.decodeFromString<List<PageBookmark>>(it) }.getOrNull()
            }?.filterNot { it.materialId == materialId && it.pageIndex == pageIndex } ?: emptyList()
            prefs[Keys.PAGE_BOOKMARKS] = json.encodeToString(current)
        }
    }

    suspend fun saveVideoProgress(materialId: String, positionMs: Long, durationMs: Long) {
        context.spkrtDataStore.edit { prefs ->
            val current = prefs[Keys.VIDEO_PROGRESS]?.let {
                runCatching { json.decodeFromString<Map<String, VideoProgress>>(it) }.getOrNull()
            }?.toMutableMap() ?: mutableMapOf()
            current[materialId] = VideoProgress(
                materialId = materialId,
                positionMs = positionMs.coerceAtLeast(0L),
                durationMs = durationMs.coerceAtLeast(0L)
            )
            prefs[Keys.VIDEO_PROGRESS] = json.encodeToString(current)
        }
    }

    suspend fun saveCachedPortalCatalog(items: List<MaterialItem>, syncedAtMillis: Long) {
        context.spkrtDataStore.edit { prefs ->
            prefs[Keys.CACHED_PORTAL_CATALOG] = json.encodeToString(items)
            prefs[Keys.LAST_CATALOG_SYNC_MS] = syncedAtMillis
        }
    }
}
