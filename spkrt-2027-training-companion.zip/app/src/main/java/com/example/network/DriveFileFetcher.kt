package com.example.network

import android.util.Base64
import com.example.domain.model.MaterialFileType
import com.example.domain.model.MaterialItem
import com.example.storage.OfflineFileManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream

sealed class DriveFetchResult {
    data class Success(val file: File, val isOfflineSaved: Boolean) : DriveFetchResult()
    data class AccessDenied(
        val fileId: String,
        val title: String,
        val reason: String,
        val previewUrl: String
    ) : DriveFetchResult()

    data class NetworkError(val message: String) : DriveFetchResult()
}

/**
 * Fetches Google Drive materials on-demand (never pre-downloading the entire catalog).
 * Verifies binary headers (%PDF- for PDF/Docs export, PK zip header for PPTX) so Drive HTML
 * login walls or permission pages are detected honestly instead of failing silently.
 */
class DriveFileFetcher(
    private val okHttpClient: OkHttpClient,
    private val portalApiClient: PortalApiClient,
    private val offlineFileManager: OfflineFileManager
) {

    suspend fun fetchDocumentFile(
        material: MaterialItem,
        portalBaseUrl: String,
        sessionToken: String,
        saveForOffline: Boolean = false,
        onProgress: (Float) -> Unit = {}
    ): DriveFetchResult = withContext(Dispatchers.IO) {
        val targetExt = when (material.fileType) {
            MaterialFileType.PPTX -> "pptx"
            else -> "pdf" // PDF and Google Docs exported as PDF
        }

        // 1. Reuse already saved offline file immediately
        offlineFileManager.getOfflineFile(material.fileId, targetExt)?.let { offline ->
            if (verifyBinaryMagicBytes(offline, targetExt)) {
                onProgress(1f)
                return@withContext DriveFetchResult.Success(offline, isOfflineSaved = true)
            } else {
                offline.delete()
            }
        }

        // 2. Reuse verified temporary cache unless user explicitly requested offline promotion
        offlineFileManager.getCachedOrOfflineFile(material.fileId, targetExt)?.let { cached ->
            if (verifyBinaryMagicBytes(cached, targetExt)) {
                if (saveForOffline) {
                    offlineFileManager.promoteCacheToOffline(material.fileId, targetExt)
                    val promoted = offlineFileManager.getOfflineFile(material.fileId, targetExt)
                    if (promoted != null) {
                        onProgress(1f)
                        return@withContext DriveFetchResult.Success(promoted, isOfflineSaved = true)
                    }
                }
                onProgress(1f)
                return@withContext DriveFetchResult.Success(cached, isOfflineSaved = false)
            } else {
                cached.delete()
            }
        }

        val targetFile = if (saveForOffline) {
            offlineFileManager.createOfflineTarget(material.fileId, targetExt)
        } else {
            offlineFileManager.createCacheTarget(material.fileId, targetExt)
        }

        // 3. Try authorized Apps Script portal proxy first if configured and user has portal token
        if (portalBaseUrl.isNotBlank() && sessionToken.isNotBlank()) {
            val portalAccess = portalApiClient.requestAuthorizedFileAccess(
                portalBaseUrl = portalBaseUrl,
                token = sessionToken,
                fileId = material.fileId,
                action = if (material.fileType == MaterialFileType.PPTX) "getPptxPdf" else "getFileAccess"
            )
            portalAccess.getOrNull()?.let { access ->
                if (access.success && !access.base64Pdf.isNullOrBlank()) {
                    val decoded = runCatching { Base64.decode(access.base64Pdf, Base64.DEFAULT) }.getOrNull()
                    if (decoded != null && decoded.isNotEmpty()) {
                        val pdfTarget = if (saveForOffline) {
                            offlineFileManager.createOfflineTarget(material.fileId, "pdf")
                        } else {
                            offlineFileManager.createCacheTarget(material.fileId, "pdf")
                        }
                        pdfTarget.writeBytes(decoded)
                        if (verifyBinaryMagicBytes(pdfTarget, "pdf")) {
                            if (saveForOffline) offlineFileManager.refreshOfflineIndex()
                            onProgress(1f)
                            return@withContext DriveFetchResult.Success(pdfTarget, saveForOffline)
                        } else {
                            pdfTarget.delete()
                        }
                    }
                }
                if (access.success && !access.downloadUrl.isNullOrBlank()) {
                    val fetched = downloadAndVerify(access.downloadUrl, targetFile, targetExt, onProgress)
                    if (fetched is DriveFetchResult.Success) {
                        if (saveForOffline) offlineFileManager.refreshOfflineIndex()
                        return@withContext fetched.copy(isOfflineSaved = saveForOffline)
                    }
                }
            }
        }

        // 4. Direct on-demand Google Drive fetch (handles Docs PDF export and Drive confirm=t download)
        val result = downloadAndVerify(
            url = material.directDownloadUrl,
            targetFile = targetFile,
            expectedExt = targetExt,
            onProgress = onProgress,
            material = material
        )
        if (result is DriveFetchResult.Success && saveForOffline) {
            offlineFileManager.refreshOfflineIndex()
            return@withContext result.copy(isOfflineSaved = true)
        }
        result
    }

    private fun downloadAndVerify(
        url: String,
        targetFile: File,
        expectedExt: String,
        onProgress: (Float) -> Unit,
        material: MaterialItem? = null
    ): DriveFetchResult {
        val tempFile = File(targetFile.parentFile, "${targetFile.name}.tmp")
        return try {
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "SPKRT2027-Android/1.0")
                .build()

            okHttpClient.newCall(request).execute().use { response ->
                val contentType = response.header("Content-Type").orEmpty().lowercase()

                if (response.code == 401 || response.code == 403) {
                    return DriveFetchResult.AccessDenied(
                        fileId = material?.fileId.orEmpty(),
                        title = material?.title.orEmpty(),
                        reason = "Akses ke file Google Drive ini dibatasi (HTTP ${response.code}). " +
                            "Pastikan izin berbagi Google Drive telah diaktifkan untuk peserta atau hubungkan backend Apps Script.",
                        previewUrl = material?.previewUrl.orEmpty()
                    )
                }

                if (!response.isSuccessful) {
                    return DriveFetchResult.NetworkError(
                        "Gagal mengunduh dokumen (HTTP ${response.code}). Periksa koneksi internet Anda."
                    )
                }

                if (contentType.contains("text/html")) {
                    return DriveFetchResult.AccessDenied(
                        fileId = material?.fileId.orEmpty(),
                        title = material?.title.orEmpty(),
                        reason = "Google Drive meminta login akun Google atau izin akses untuk file ID " +
                            "${material?.fileId.orEmpty()}. Anda dapat membuka pratinjau Google Drive terotorisasi di dalam aplikasi.",
                        previewUrl = material?.previewUrl.orEmpty()
                    )
                }

                val body = response.body
                    ?: return DriveFetchResult.NetworkError("Respons unduhan dari Google Drive kosong.")
                val totalBytes = body.contentLength()

                body.byteStream().use { input ->
                    FileOutputStream(tempFile).use { output ->
                        val buffer = ByteArray(16 * 1024)
                        var copied = 0L
                        while (true) {
                            val read = input.read(buffer)
                            if (read == -1) break
                            output.write(buffer, 0, read)
                            copied += read
                            if (totalBytes > 0L) {
                                onProgress((copied.toFloat() / totalBytes.toFloat()).coerceIn(0f, 0.98f))
                            }
                        }
                        output.flush()
                    }
                }
            }

            if (!verifyBinaryMagicBytes(tempFile, expectedExt)) {
                tempFile.delete()
                return DriveFetchResult.AccessDenied(
                    fileId = material?.fileId.orEmpty(),
                    title = material?.title.orEmpty(),
                    reason = "File yang diterima bukan format ${expectedExt.uppercase()} yang valid " +
                        "(kemungkinan halaman pembatasan izin Google Drive). Gunakan Pratinjau Drive atau periksa izin file.",
                    previewUrl = material?.previewUrl.orEmpty()
                )
            }

            if (targetFile.exists()) targetFile.delete()
            if (!tempFile.renameTo(targetFile)) {
                tempFile.copyTo(targetFile, overwrite = true)
                tempFile.delete()
            }
            onProgress(1f)
            DriveFetchResult.Success(targetFile, isOfflineSaved = false)
        } catch (e: Exception) {
            tempFile.delete()
            DriveFetchResult.NetworkError(
                "Koneksi terganggu saat mengambil materi: ${e.localizedMessage ?: "Periksa jaringan internet Anda."}"
            )
        }
    }

    private fun verifyBinaryMagicBytes(file: File, expectedExt: String): Boolean {
        if (!file.exists() || file.length() < 8L) return false
        return runCatching {
            val header = ByteArray(8)
            file.inputStream().use { it.read(header) }
            when (expectedExt.lowercase()) {
                "pdf" -> {
                    val str = String(header, Charsets.US_ASCII)
                    str.startsWith("%PDF-")
                }
                "pptx" -> {
                    // ZIP magic bytes: PK\x03\x04
                    header[0] == 0x50.toByte() && header[1] == 0x4B.toByte()
                }
                else -> true
            }
        }.getOrDefault(false)
    }
}
