package com.example.network

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class PortalLoginResponse(
    @Json(name = "success") val success: Boolean = false,
    @Json(name = "message") val message: String? = null,
    @Json(name = "token") val token: String? = null,
    @Json(name = "user") val user: PortalUserDto? = null
)

@JsonClass(generateAdapter = true)
data class PortalUserDto(
    @Json(name = "email") val email: String? = null,
    @Json(name = "nama") val nama: String? = null,
    @Json(name = "name") val name: String? = null,
    @Json(name = "peran") val peran: String? = null,
    @Json(name = "role") val role: String? = null,
    @Json(name = "kelas") val kelas: String? = null,
    @Json(name = "className") val className: String? = null
)

@JsonClass(generateAdapter = true)
data class PortalMaterialsResponse(
    @Json(name = "success") val success: Boolean = false,
    @Json(name = "message") val message: String? = null,
    @Json(name = "data") val data: List<PortalMaterialDto>? = null,
    @Json(name = "materials") val materials: List<PortalMaterialDto>? = null
)

/**
 * Direct field mapping to existing DATABASE_PORTAL_SPKRT_2027 sheet `MATERI`:
 * ID_MATERI | KATEGORI | JUDUL | DESKRIPSI | DRIVE_FILE_ID | URL_MATERI | URUTAN | STATUS
 */
@JsonClass(generateAdapter = true)
data class PortalMaterialDto(
    @Json(name = "ID_MATERI") val idMateri: String? = null,
    @Json(name = "KATEGORI") val kategori: String? = null,
    @Json(name = "JUDUL") val judul: String? = null,
    @Json(name = "DESKRIPSI") val deskripsi: String? = null,
    @Json(name = "DRIVE_FILE_ID") val driveFileId: String? = null,
    @Json(name = "URL_MATERI") val urlMateri: String? = null,
    @Json(name = "URUTAN") val urutan: Int? = null,
    @Json(name = "STATUS") val status: String? = null,
    @Json(name = "FILE_TYPE") val fileType: String? = null,
    @Json(name = "CREATED_AT") val createdAt: String? = null,
    @Json(name = "UPDATED_AT") val updatedAt: String? = null
)

@JsonClass(generateAdapter = true)
data class PortalFileAccessResponse(
    @Json(name = "success") val success: Boolean = false,
    @Json(name = "message") val message: String? = null,
    @Json(name = "downloadUrl") val downloadUrl: String? = null,
    @Json(name = "streamUrl") val streamUrl: String? = null,
    @Json(name = "mimeType") val mimeType: String? = null,
    @Json(name = "base64Pdf") val base64Pdf: String? = null
)
