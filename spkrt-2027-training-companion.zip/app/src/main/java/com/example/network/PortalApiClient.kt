package com.example.network

import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.net.InetAddress
import java.util.concurrent.TimeUnit

/**
 * Secure HTTP client for the existing SPKRT 2027 Google Apps Script Web App backend.
 *
 * Security & Reliability safeguards:
 * - Enforces HTTPS and rejects private/loopback/metadata addresses.
 * - Follows Apps Script 302 redirects to script.googleusercontent.com cleanly.
 * - Never embeds credentials or logs passwords/tokens.
 */
class PortalApiClient(
    val okHttpClient: OkHttpClient = createDefaultHttpClient(),
    private val moshi: Moshi = Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build()
) {

    companion object {
        private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()

        fun createDefaultHttpClient(): OkHttpClient {
            return OkHttpClient.Builder()
                .connectTimeout(20, TimeUnit.SECONDS)
                .readTimeout(45, TimeUnit.SECONDS)
                .writeTimeout(20, TimeUnit.SECONDS)
                .followRedirects(true)
                .followSslRedirects(true)
                .build()
        }

        fun validatePortalUrl(rawUrl: String): Result<String> {
            val trimmed = rawUrl.trim()
            if (trimmed.isEmpty()) {
                return Result.failure(IllegalArgumentException("URL Portal Apps Script belum diisi."))
            }
            val parsed = trimmed.toHttpUrlOrNull()
                ?: return Result.failure(IllegalArgumentException("Format URL Portal tidak valid."))
            if (!parsed.isHttps) {
                return Result.failure(IllegalArgumentException("URL Portal harus menggunakan protokol HTTPS."))
            }
            val host = parsed.host.lowercase()
            if (host == "localhost" || host == "127.0.0.1" || host == "169.254.169.254" || host.endsWith(".local")) {
                return Result.failure(IllegalArgumentException("Host lokal tidak diizinkan sebagai URL Portal."))
            }
            // Reject raw private IPv4 ranges
            runCatching {
                if (host.all { it.isDigit() || it == '.' }) {
                    val addr = InetAddress.getByName(host)
                    if (addr.isAnyLocalAddress || addr.isLoopbackAddress || addr.isSiteLocalAddress || addr.isLinkLocalAddress) {
                        return Result.failure(IllegalArgumentException("Alamat IP privat tidak diizinkan."))
                    }
                }
            }
            return Result.success(parsed.toString())
        }
    }

    suspend fun login(
        portalBaseUrl: String,
        email: String,
        password: String
    ): Result<PortalLoginResponse> = withContext(Dispatchers.IO) {
        val validUrl = validatePortalUrl(portalBaseUrl).getOrElse { return@withContext Result.failure(it) }
        runCatching {
            val payload = JSONObject().apply {
                put("action", "login")
                put("email", email.trim())
                put("password", password)
            }.toString()

            val request = Request.Builder()
                .url(validUrl)
                .post(payload.toRequestBody(JSON_MEDIA_TYPE))
                .header("Accept", "application/json")
                .build()

            okHttpClient.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    throw IOException("Server portal mengembalikan kode HTTP ${response.code}.")
                }
                if (body.trimStart().startsWith("<")) {
                    throw IOException(
                        "Endpoint Apps Script mengembalikan halaman HTML, bukan JSON. " +
                            "Pastikan Web App dideploy dengan akses yang sesuai dan mendukung action=login."
                    )
                }
                val adapter = moshi.adapter(PortalLoginResponse::class.java)
                adapter.fromJson(body)
                    ?: throw IOException("Respons login dari server portal tidak dapat diparsing.")
            }
        }
    }

    suspend fun getMaterials(
        portalBaseUrl: String,
        token: String
    ): Result<PortalMaterialsResponse> = withContext(Dispatchers.IO) {
        val validUrl = validatePortalUrl(portalBaseUrl).getOrElse { return@withContext Result.failure(it) }
        runCatching {
            val urlBuilder = validUrl.toHttpUrlOrNull()?.newBuilder()
                ?: throw IllegalArgumentException("URL Portal tidak valid.")
            urlBuilder.addQueryParameter("action", "getMaterials")
            if (token.isNotBlank()) {
                urlBuilder.addQueryParameter("token", token)
            }

            val request = Request.Builder()
                .url(urlBuilder.build())
                .get()
                .header("Accept", "application/json")
                .build()

            okHttpClient.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    throw IOException("Gagal mengambil katalog dari portal (HTTP ${response.code}).")
                }
                if (body.trimStart().startsWith("<")) {
                    throw IOException("Respons katalog bukan JSON valid. Periksa deployment Apps Script.")
                }
                val adapter = moshi.adapter(PortalMaterialsResponse::class.java)
                adapter.fromJson(body)
                    ?: throw IOException("Format katalog dari server portal tidak valid.")
            }
        }
    }

    suspend fun requestAuthorizedFileAccess(
        portalBaseUrl: String,
        token: String,
        fileId: String,
        action: String = "getFileAccess"
    ): Result<PortalFileAccessResponse> = withContext(Dispatchers.IO) {
        val validUrl = validatePortalUrl(portalBaseUrl).getOrElse { return@withContext Result.failure(it) }
        runCatching {
            val urlBuilder = validUrl.toHttpUrlOrNull()?.newBuilder()
                ?: throw IllegalArgumentException("URL Portal tidak valid.")
            urlBuilder.addQueryParameter("action", action)
            urlBuilder.addQueryParameter("fileId", fileId)
            if (token.isNotBlank()) {
                urlBuilder.addQueryParameter("token", token)
            }

            val request = Request.Builder()
                .url(urlBuilder.build())
                .get()
                .header("Accept", "application/json")
                .build()

            okHttpClient.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful || body.trimStart().startsWith("<")) {
                    throw IOException("Endpoint akses file portal tidak tersedia (HTTP ${response.code}).")
                }
                val adapter = moshi.adapter(PortalFileAccessResponse::class.java)
                adapter.fromJson(body)
                    ?: throw IOException("Format respons akses file tidak valid.")
            }
        }
    }
}
